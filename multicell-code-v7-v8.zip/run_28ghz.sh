#!/bin/bash
# run_28ghz.sh - sequential driver for the 28 GHz small-cell run.
# Waits for the 10 m v6 run (rt_multicell_10m.py) to finish first, so the
# two Sionna jobs do not compete for the ~2.4 GB free RAM on this VM.
# Then: chunks 0-12 of rt_28ghz_smallcell.py (50 RX each), --post, compare_28.py.
# Chunks were 0-4 at 150 RX each; re-chunked to 50 RX after chunk 0 OOM-killed
# the VM at the 150 RX / 1M-sample settings (2026-11-10 ~03:00 UTC).
# Logs to run_28ghz.log in this folder. Exit non-zero on any failure.
set -u
cd /home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna
PY=/home/hatch/workspace/cbrs-wisp-planner/venv/bin/python
LOG=run_28ghz.log
echo "28 GHz small-cell driver started $(date -u +%FT%TZ)" | tee -a $LOG
# --- wait for the 10 m run: process gone AND all 67 chunks done ---
for i in $(seq 1 240); do
  if ! pgrep -f rt_multicell_10m.py >/dev/null 2>&1; then
    echo "10 m process finished (waited ${i} min) $(date -u +%FT%TZ)" | tee -a $LOG
    break
  fi
  if [ $((i % 10)) -eq 0 ]; then echo "still waiting for 10 m run... ${i} min $(date -u +%FT%TZ)" | tee -a $LOG; fi
  sleep 60
done
if pgrep -f rt_multicell_10m.py >/dev/null 2>&1; then
  echo "ERROR: 10 m run still alive after 4 h wait; aborting 28 GHz run" | tee -a $LOG
  exit 1
fi
# --- chunks ---
for c in $(seq 0 12); do
  echo "=== chunk $c $(date -u +%FT%TZ) ===" | tee -a $LOG
  $PY rt_28ghz_smallcell.py --chunk $c 2>&1 | tee -a $LOG
  rc=${PIPESTATUS[0]}
  if [ $rc -ne 0 ]; then echo "ERROR: chunk $c failed rc=$rc" | tee -a $LOG; exit 1; fi
done
echo "=== post $(date -u +%FT%TZ) ===" | tee -a $LOG
$PY rt_28ghz_smallcell.py --post 2>&1 | tee -a $LOG
rc=${PIPESTATUS[0]}
if [ $rc -ne 0 ]; then echo "ERROR: post failed rc=$rc" | tee -a $LOG; exit 1; fi
echo "=== compare_28.py $(date -u +%FT%TZ) ===" | tee -a $LOG
python3 compare_28.py 2>&1 | tee -a $LOG
rc=${PIPESTATUS[0]}
if [ $rc -ne 0 ]; then echo "ERROR: compare failed rc=$rc" | tee -a $LOG; exit 1; fi
echo "28 GHz small-cell run COMPLETE $(date -u +%FT%TZ)" | tee -a $LOG
