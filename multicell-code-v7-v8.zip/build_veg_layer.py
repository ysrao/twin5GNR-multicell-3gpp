#!/usr/bin/env python3
"""build_veg_layer.py - foliage depth layer for the multicell Sionna artefact v7.

Inputs (read-only):
  ~/workspace/twin5gnr-work/sf-3dep-lidar-try/tile_points_d08.npz  (15.19M pts, depths 0-8)
  ~/workspace/twin5gnr-work/sf-3dep-lidar-try/chm_2m.npz           (dtm5, 5 m, for HAG)
  ~/workspace/sf-twin/scene_sf/height_rasters.npz                 (Vexcel mesh surf/ground, 5 m ENU)
  ~/workspace/twin5gnr-work/twin5GNR-SF-veg-surveyed/sf_trees_tile.json (1,919 surveyed trees)
  ~/workspace/twin5gnr-work/twin5GNR-multicell-sionna/results_multicell_f3600_street.npz (v5, los_tx)

CORRECTION vs the earlier LiDAR note (analyse2.py): that script mapped
Mercator northing to ENU WITHOUT the cos(lat0) factor (ey = y - cy0),
stretching north by 1/cos(37.8 deg) = 1.266, so its mesh building mask
was misaligned in the north half of the tile. Here BOTH axes are
cos-corrected: ex=(x-cx0)*cos(lat0), ey=(y-cy0)*cos(lat0). True metres.

Method:
  1. Vegetation candidates: LAS class 1, HAG 1-20 m (HAG vs 5 m DTM),
     outside Vexcel mesh building cells (surf-ground > 6 m, 5 m ENU grid).
  2. Masked CHM: 2 m ENU raster over [-500,500]^2, CHM(cell) = max HAG of
     candidates in the cell. Canopy = CHM >= 2 m.
  3. Foliage depth per (RX, TX): sample the straight TX->RX line every
     5 m (same convention as the surveyed-tree build); line height above
     ground interpolates linearly 30 m (TX) -> 1.5 m (RX, street); a sample
     counts if the masked CHM at that cell is >= the line height.
     Overlapping canopy counts once per sample.
  4. P.833-10 Eq.(1) at 3.6 GHz, (gamma, Am) = (0.55, 38) — INTERPOLATED /
     ASSUMED, uncalibrated (same pair as v5.1 RB). A_ev = Am*(1-exp(-d*gamma/Am)).
  5. Application to ray-traced power (phi-weighted, v5.1 method):
     veg_adj = 10*log10(1-phi+phi*10^(-A_ev/10)).
     phi (LOS power share) was NOT stored in the v5 npz, so phi is set
     from the measured single-tower SF run (data_sf_f3600_street.npz):
     LOS cells have median phi = 0.968, p10 0.773. We use phi = 1 for
     LOS pairs (median error <0.2 dB, stated) and phi = 0 for non-LOS
     pairs (foliage on reflected/diffracted paths NOT modelled — the veg
     effect is therefore a LOWER BOUND for NLOS cells, stated).
  6. rsrp_veg = rsrp_tilt4 - veg_adj per (rx, tx), all sectors equally.

Outputs: veg_layer_40m.npz, veg_comparison.json. Provenance: ray-traced /
simulated + modelled P.833, never measured.
"""
import json, math
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
LID = '/home/hatch/workspace/twin5gnr-work/sf-3dep-lidar-try'
SF = '/home/hatch/workspace/sf-twin'
LAT0, LON0 = 37.801105, -122.404175
R = 6378137.0
COS = math.cos(math.radians(LAT0))
CX0 = R * math.radians(LON0)
CY0 = R * math.log(math.tan(math.pi / 4 + math.radians(LAT0) / 2))
STEP_M = 5.0
GAMMA, AM = 0.55, 38.0   # P.833 at 3.6 GHz, INTERPOLATED/ASSUMED, uncalibrated
TOWERS = [('A', -250.0, 250.0), ('B', 250.0, 250.0), ('C', 0.0, -250.0)]
TX_AGL, RX_H = 30.0, 1.5


def merc_enu(lat, lon):
    x = (R * math.radians(lon) - CX0) * COS
    y = (R * math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) - CY0) * COS
    return x, y


def main():
    # --- 1. vegetation candidates, correct ENU mapping ---
    d = np.load(f'{LID}/tile_points_d08.npz')
    x, y, z, c = d['x'], d['y'], d['z'], d['cls']
    ch = np.load(f'{LID}/chm_2m.npz')
    dtm5, TX0, TY0 = ch['dtm5'], float(ch['tx0']), float(ch['ty0'])
    # HAG vs 5 m DTM (DTM grid is in 3857 units, 5 per cell)
    gx = ((x - TX0) // 5).astype(int); gy = ((y - TY0) // 5).astype(int)
    hag = z - dtm5[gy, gx]
    # mesh building mask, correct ENU
    hr = np.load(f'{SF}/scene_sf/height_rasters.npz')
    surf, ground = hr['surf'], hr['ground']
    ex = (x - CX0) * COS; ey = (y - CY0) * COS
    mx = ((ex + 485) // 5).astype(int); my = ((ey + 485) // 5).astype(int)
    ok = (mx >= 0) & (mx < 194) & (my >= 0) & (my < 194)
    is_bld = np.zeros(len(z), dtype=bool)
    is_bld[ok] = (surf[my[ok], mx[ok]] - ground[my[ok], mx[ok]]) > 6.0
    veg = (c == 1) & (hag >= 1) & (hag <= 20) & (~is_bld)
    print(f'vegetation candidates (class1, HAG 1-20 m, non-building, correct ENU mask): '
          f'{veg.sum():,} pts ({100 * veg.mean():.2f}% of tile pts)')
    print(f'  class1 HAG 1-20 m inside building cells (excluded): '
          f'{((c == 1) & (hag >= 1) & (hag <= 20) & is_bld).sum():,}')

    # --- 2. masked CHM, 2 m ENU raster over [-500, 500]^2 ---
    CELL = 2.0; N = 500
    chm = np.zeros((N, N), dtype=np.float32)
    vx = ex[veg]; vy = ey[veg]; vh = hag[veg]
    ix = ((vx + 500) // CELL).astype(int); iy = ((vy + 500) // CELL).astype(int)
    good = (ix >= 0) & (ix < N) & (iy >= 0) & (iy < N)
    ix, iy, vh = ix[good], iy[good], vh[good]
    np.maximum.at(chm, (iy, ix), vh.astype(np.float32))
    print(f'masked CHM: cells >=2 m: {(chm >= 2).mean() * 100:.1f}%  max {chm.max():.1f} m  '
          f'mean (canopy cells) {chm[chm >= 2].mean():.1f} m')

    # --- cross-check vs surveyed trees ---
    trees = json.load(open('/home/hatch/workspace/twin5gnr-work/twin5GNR-SF-veg-surveyed/sf_trees_tile.json'))
    tx, ty = [], []
    for t in trees:
        try:
            a, b = merc_enu(float(t['latitude']), float(t['longitude']))
        except (KeyError, TypeError, ValueError):
            continue
        tx.append(a); ty.append(b)
    tx, ty = np.array(tx), np.array(ty)
    def chm_at(px, py, rad):
        # max CHM within rad metres of each point
        best = np.zeros(len(px))
        for k in range(len(px)):
            r = int(math.ceil(rad / CELL))
            cx, cy = int((px[k] + 500) // CELL), int((py[k] + 500) // CELL)
            lo_x, hi_x = max(0, cx - r), min(N, cx + r + 1)
            lo_y, hi_y = max(0, cy - r), min(N, cy + r + 1)
            if lo_x < hi_x and lo_y < hi_y:
                best[k] = chm[lo_y:hi_y, lo_x:hi_x].max()
        return best
    for rad in (2.0, 6.0):
        m = chm_at(tx, ty, rad)
        print(f'surveyed trees with masked CHM >= 2 m within {rad:.0f} m: {(m >= 2).mean() * 100:.1f}% '
              f'({(m >= 2).sum()}/{len(tx)})')

    # --- 3. foliage depth per (RX, TX) on the 40 m grid ---
    D = dict(np.load(f'{ROOT}/results_multicell_f3600_street.npz', allow_pickle=True))
    xs, ys, pts = D['xs'], D['ys'], D['rx_xyz']
    los_tx = D['los_tx']  # (625, 3) bool
    txs = [(nm, float(v[1]), float(v[2]), float(v[3])) for nm, v in
           zip(['A', 'B', 'C'], [tuple(r) for r in D['txs']])]
    depth = np.zeros((625, 3), dtype=np.float32)
    for ti, (nm, tx_, ty_, tz_) in enumerate(txs):
        for i in range(625):
            rx, ry = pts[i, 0], pts[i, 1]
            L = math.hypot(rx - tx_, ry - ty_)
            n = max(2, int(L / STEP_M))
            tt = (np.arange(n) + 0.5) / n
            px = tx_ + (rx - tx_) * tt
            py = ty_ + (ry - ty_) * tt
            hag_line = TX_AGL + (RX_H - TX_AGL) * tt
            cx = ((px + 500) // CELL).astype(int); cy = ((py + 500) // CELL).astype(int)
            okc = (cx >= 0) & (cx < N) & (cy >= 0) & (cy < N)
            hit = np.zeros(n, dtype=bool)
            hit[okc] = (chm[cy[okc], cx[okc]] >= hag_line[okc]) & (chm[cy[okc], cx[okc]] >= 2.0)
            depth[i, ti] = hit.sum() * (L / n)
    print(f'foliage depth (40 m grid, 625 cells x 3 TX): mean {depth.mean():.2f} m  '
          f'median {np.median(depth):.2f} m  p90 {np.percentile(depth, 90):.2f} m  max {depth.max():.2f} m  '
          f'pairs >0: {(depth > 0).mean() * 100:.1f}%')

    # --- 4. P.833 + phi-weighted application ---
    a_ev = np.where(depth > 0, AM * (1.0 - np.exp(-depth * GAMMA / AM)), 0.0)
    phi = np.where(los_tx, 1.0, 0.0)  # stated approx: LOS cells median phi 0.968 in SF single-tower run
    veg_adj = np.where(a_ev > 0, 10 * np.log10(1 - phi + phi * 10 ** (-a_ev / 10)), 0.0)
    print(f'P.833 A_ev: mean {a_ev.mean():.2f} dB  p90 {np.percentile(a_ev, 90):.2f} dB  max {a_ev.max():.2f} dB')
    print(f'veg_adj (phi-weighted): mean {veg_adj.mean():.2f} dB  p90 {np.percentile(veg_adj, 90):.2f} dB  '
          f'max {veg_adj.max():.2f} dB  pairs >1 dB: {(veg_adj > 1).mean() * 100:.1f}%')
    rsrp = D['rsrp_tilt4']  # (625,3,3) tilt 4
    rsrp_veg = rsrp - veg_adj[:, :, None].astype(np.float32)
    rsrp_veg = np.where(np.isnan(rsrp), np.nan, rsrp_veg).astype(np.float32)
    np.savez_compressed(f'{ROOT}/veg_layer_40m.npz',
                        chm=chm, depth=depth, a_ev=a_ev.astype(np.float32),
                        veg_adj=veg_adj.astype(np.float32), phi=phi.astype(np.float32),
                        rsrp_veg_tilt4=rsrp_veg, xs=xs, ys=ys,
                        meta=json.dumps(dict(
                            source='USGS 3DEP CA_SanFrancisco_B23, depths 0-8, 15.19M pts; '
                                   'class 1, HAG 1-20 m, outside Vexcel-mesh building cells (>6 m); '
                                   'masked CHM 2 m ENU; P.833-10 Eq.(1) at 3.6 GHz (gamma,Am)=(0.55,38) '
                                   'INTERPOLATED/ASSUMED, uncalibrated; phi=1 LOS / 0 non-LOS '
                                   '(SF single-tower run: LOS cells median phi 0.968, p10 0.773); '
                                   'line sampled every 5 m, height linear TX 30 m -> RX 1.5 m; '
                                   'EN U mapping cos-corrected on both axes (corrects analyse2.py north stretch); '
                                   'masked canopy is an UPPER BOUND (street clutter included)',
                            grid='25x25, 40 m, street 1.5 m', freq_ghz=3.6, tilt_deg=4)))
    print('wrote veg_layer_40m.npz')
    # quick stats
    best = np.nanmax(np.nanmax(rsrp, axis=2), axis=1)
    best_v = np.nanmax(np.nanmax(rsrp_veg, axis=2), axis=1)
    print(f'best-server RSRP: no-veg median {np.nanmedian(best):.1f} dBm cov>= -90 {np.mean(best >= -90) * 100:.1f}% | '
          f'with-veg median {np.nanmedian(best_v):.1f} dBm cov {np.mean(best_v >= -90) * 100:.1f}% | '
          f'median delta {np.nanmedian(best_v - best):+.1f} dB')


if __name__ == '__main__':
    main()
