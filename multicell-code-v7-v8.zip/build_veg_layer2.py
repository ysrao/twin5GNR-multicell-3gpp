#!/usr/bin/env python3
"""build_veg_layer2.py - foliage depth layer v2 for artefact v7.

Fixes vs build_veg_layer.py:
  1. Building mask: OSM vector building footprints (api.openstreetmap.org,
     1,475 building ways in the tile, fetched 2026-11-10) rasterised to the
     2 m ENU grid — much sharper than the 5 m Vexcel-mesh mask, which
     wrongly masked out ~1/3 of surveyed street trees (trees in sidewalk
     pits share a 5 m cell with the facade). Overpass was still blocked
     (406); the main OSM API map call returned 200.
  2. Sign bug: veg_adj from P.833 phi-weighting is <= 0 dB, so
     rsrp_veg = rsrp + veg_adj (NOT rsrp - veg_adj).
  3. Also computes the surveyed-tree foliage depth for the SAME 3 towers
     (crown-disc method from build_sf_veg_surveyed.py) as the
     apples-to-apples baseline for the LiDAR-CHM depth.

Method otherwise as build_veg_layer.py: candidates = LAS class 1,
HAG 1-20 m, outside building polygons; masked CHM 2 m ENU (max HAG);
depth = straight-line TX->RX sampled every 5 m, line height linear
30 m -> 1.5 m, sample counts if masked CHM >= line height and >= 2 m.
P.833-10 Eq.(1) at 3.6 GHz (gamma,Am)=(0.55,38) INTERPOLATED/ASSUMED,
uncalibrated. phi = 1 for LOS pairs, 0 for non-LOS (SF single-tower run:
LOS cells median phi 0.968, p10 0.773; stated approx).
"""
import json, math
import numpy as np
import xml.etree.ElementTree as ET
from shapely.geometry import Polygon
from shapely.strtree import STRtree

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
LID = '/home/hatch/workspace/twin5gnr-work/sf-3dep-lidar-try'
SF = '/home/hatch/workspace/sf-twin'
LAT0, LON0 = 37.801105, -122.404175
R = 6378137.0
COS = math.cos(math.radians(LAT0))
CX0 = R * math.radians(LON0)
CY0 = R * math.log(math.tan(math.pi / 4 + math.radians(LAT0) / 2))
STEP_M = 5.0
GAMMA, AM = 0.55, 38.0
TX_AGL, RX_H = 30.0, 1.5
CELL, N = 2.0, 500  # 2 m ENU grid over [-500, 500]^2


def merc_enu(lat, lon):
    return ((R * math.radians(lon) - CX0) * COS,
            (R * math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) - CY0) * COS)


def main():
    # --- 1. OSM building polygons -> 2 m ENU raster mask ---
    t = ET.parse(f'{ROOT}/osm_tile.osm')
    r = t.getroot()
    nodes = {n.get('id'): (float(n.get('lat')), float(n.get('lon'))) for n in r.findall('node')}
    polys, n_bld, n_closed = [], 0, 0
    for w in r.findall('way'):
        if not any(tg.get('k') == 'building' for tg in w.findall('tag')):
            continue
        n_bld += 1
        refs = [nd.get('ref') for nd in w.findall('nd')]
        if len(refs) < 4 or refs[0] != refs[-1]:
            continue
        pts = [nodes.get(ref) for ref in refs]
        if any(p is None for p in pts):
            continue
        xy = [merc_enu(la, lo) for la, lo in pts]
        try:
            p = Polygon(xy)
        except Exception:
            continue
        if p.is_valid and not p.is_empty and p.area > 1.0:
            polys.append(p); n_closed += 1
    print(f'OSM: {n_bld} building ways, {n_closed} valid closed polygons, '
          f'total footprint area {sum(p.area for p in polys):.0f} m^2 '
          f'({100 * sum(p.area for p in polys) / 1e6:.1f}% of tile)')
    bld_mask = np.zeros((N, N), dtype=bool)
    tree = STRtree(polys)
    # rasterise: for each polygon, test grid centres in its bbox
    gx = -500 + (np.arange(N) + 0.5) * CELL
    gy = -500 + (np.arange(N) + 0.5) * CELL
    for p in polys:
        minx, miny, maxx, maxy = p.bounds
        ix0 = max(0, int((minx + 500) // CELL)); ix1 = min(N, int((maxx + 500) // CELL) + 1)
        iy0 = max(0, int((miny + 500) // CELL)); iy1 = min(N, int((maxy + 500) // CELL) + 1)
        if ix0 >= ix1 or iy0 >= iy1:
            continue
        xx, yy = np.meshgrid(gx[ix0:ix1], gy[iy0:iy1])
        pts = np.column_stack([xx.ravel(), yy.ravel()])
        from shapely import contains_xy
        inside = contains_xy(p, pts[:, 0], pts[:, 1]).reshape(yy.shape)
        bld_mask[iy0:iy1, ix0:ix1] |= inside
    print(f'OSM building mask: {bld_mask.mean() * 100:.1f}% of 2 m cells are building')

    # --- 2. vegetation candidates with OSM mask ---
    d = np.load(f'{LID}/tile_points_d08.npz')
    x, y, z, c = d['x'], d['y'], d['z'], d['cls']
    ch = np.load(f'{LID}/chm_2m.npz')
    dtm5, TX0, TY0 = ch['dtm5'], float(ch['tx0']), float(ch['ty0'])
    gx5 = ((x - TX0) // 5).astype(int); gy5 = ((y - TY0) // 5).astype(int)
    hag = z - dtm5[gy5, gx5]
    ex = (x - CX0) * COS; ey = (y - CY0) * COS
    ix = ((ex + 500) // CELL).astype(int); iy = ((ey + 500) // CELL).astype(int)
    in_grid = (ix >= 0) & (ix < N) & (iy >= 0) & (iy < N)
    in_bld = np.zeros(len(z), dtype=bool)
    in_bld[in_grid] = bld_mask[iy[in_grid], ix[in_grid]]
    veg = (c == 1) & (hag >= 1) & (hag <= 20) & (~in_bld) & in_grid
    print(f'vegetation candidates (OSM mask): {veg.sum():,} pts ({100 * veg.mean():.2f}% of tile pts)')
    print(f'  class1 HAG 1-20 m inside OSM buildings (excluded): '
          f'{((c == 1) & (hag >= 1) & (hag <= 20) & in_bld).sum():,}')

    # --- 3. masked CHM + surveyed-tree cross-check ---
    chm = np.zeros((N, N), dtype=np.float32)
    np.maximum.at(chm, (iy[veg], ix[veg]), hag[veg].astype(np.float32))
    print(f'masked CHM (OSM): cells >=2 m: {(chm >= 2).mean() * 100:.1f}%  max {chm.max():.1f} m  '
          f'mean (canopy cells) {chm[chm >= 2].mean():.1f} m')
    trees = json.load(open('/home/hatch/workspace/twin5gnr-work/twin5GNR-SF-veg-surveyed/sf_trees_tile.json'))
    tx, ty = [], []
    for tt in trees:
        try:
            a, b = merc_enu(float(tt['latitude']), float(tt['longitude']))
        except (KeyError, TypeError, ValueError):
            continue
        tx.append(a); ty.append(b)
    tx, ty = np.array(tx), np.array(ty)
    for rad in (2.0, 6.0):
        rr = int(math.ceil(rad / CELL))
        hit = np.zeros(len(tx), dtype=bool)
        cx = ((tx + 500) // CELL).astype(int); cy = ((ty + 500) // CELL).astype(int)
        for k in range(len(tx)):
            lo_x, hi_x = max(0, cx[k] - rr), min(N, cx[k] + rr + 1)
            lo_y, hi_y = max(0, cy[k] - rr), min(N, cy[k] + rr + 1)
            if lo_x < hi_x and lo_y < hi_y:
                hit[k] = chm[lo_y:hi_y, lo_x:hi_x].max() >= 2.0
        print(f'surveyed trees with OSM-masked CHM >= 2 m within {rad:.0f} m: {hit.mean() * 100:.1f}% '
              f'({hit.sum()}/{len(tx)})')

    # --- 4. foliage depth per (RX, TX): LiDAR CHM + surveyed-tree baseline ---
    D = dict(np.load(f'{ROOT}/results_multicell_f3600_street.npz', allow_pickle=True))
    xs, ys, pts = D['xs'], D['ys'], D['rx_xyz']
    los_tx = D['los_tx']
    txs = [('A', -250.0, 250.0), ('B', 250.0, 250.0), ('C', 0.0, -250.0)]
    # surveyed crown discs (same allometry as build_sf_veg_surveyed.py)
    def crown_for(tt):
        try:
            v = float(tt.get('mapdbh'))
        except (TypeError, ValueError):
            v = None
        if v is None:
            r = {'1': 2.0, '2': 3.0, '3': 4.0, '4': 5.0}.get(str(tt.get('dbhrange')), 3.0)
            z = {'1': (3.0, 6.0), '2': (2.0, 8.0), '3': (2.0, 10.0), '4': (2.0, 12.0)}.get(
                str(tt.get('dbhrange')), (2.0, 8.0))
            return r, z[0], z[1]
        if v <= 10: return 2.0, 3.0, 6.0
        if v <= 20: return 3.0, 2.0, 8.0
        if v < 40: return 4.0, 2.0, 10.0
        return 5.0, 2.0, 12.0
    s_tx, s_ty, s_tr, s_z0, s_z1 = [], [], [], [], []
    for tt in trees:
        try:
            a, b = merc_enu(float(tt['latitude']), float(tt['longitude']))
        except (KeyError, TypeError, ValueError):
            continue
        rr_, z0, z1 = crown_for(tt)
        s_tx.append(a); s_ty.append(b); s_tr.append(rr_); s_z0.append(z0); s_z1.append(z1)
    s_tx = np.array(s_tx); s_ty = np.array(s_ty); s_tr = np.array(s_tr)
    s_z0 = np.array(s_z0); s_z1 = np.array(s_z1)

    depth = np.zeros((625, 3), dtype=np.float32)
    depth_srv = np.zeros((625, 3), dtype=np.float32)
    for ti, (nm, tx_, ty_) in enumerate(txs):
        for i in range(625):
            rx, ry = pts[i, 0], pts[i, 1]
            L = math.hypot(rx - tx_, ry - ty_)
            n = max(2, int(L / STEP_M))
            tt_ = (np.arange(n) + 0.5) / n
            px = tx_ + (rx - tx_) * tt_; py = ty_ + (ry - ty_) * tt_
            hag_line = TX_AGL + (RX_H - TX_AGL) * tt_
            cx = ((px + 500) // CELL).astype(int); cy = ((py + 500) // CELL).astype(int)
            okc = (cx >= 0) & (cx < N) & (cy >= 0) & (cy < N)
            hit = np.zeros(n, dtype=bool)
            hit[okc] = (chm[cy[okc], cx[okc]] >= hag_line[okc]) & (chm[cy[okc], cx[okc]] >= 2.0)
            depth[i, ti] = hit.sum() * (L / n)
            # surveyed discs
            dx = px[:, None] - s_tx[None, :]
            dy = py[:, None] - s_ty[None, :]
            inside = (dx * dx + dy * dy) <= (s_tr[None, :] ** 2)
            inside &= (hag_line[:, None] >= s_z0[None, :]) & (hag_line[:, None] <= s_z1[None, :])
            depth_srv[i, ti] = inside.any(axis=1).sum() * (L / n)
    print(f'foliage depth LiDAR-CHM: mean {depth.mean():.2f} m median {np.median(depth):.2f} m '
          f'p90 {np.percentile(depth, 90):.2f} m max {depth.max():.2f} m pairs>0 {(depth > 0).mean() * 100:.1f}%')
    print(f'foliage depth surveyed trees (same 3 TX): mean {depth_srv.mean():.2f} m median '
          f'{np.median(depth_srv):.2f} m p90 {np.percentile(depth_srv, 90):.2f} m max {depth_srv.max():.2f} m '
          f'pairs>0 {(depth_srv > 0).mean() * 100:.1f}%')

    # --- 5. P.833 + phi-weighted application (SIGN FIXED: veg_adj <= 0, rsrp_veg = rsrp + veg_adj) ---
    a_ev = np.where(depth > 0, AM * (1.0 - np.exp(-depth * GAMMA / AM)), 0.0)
    phi = np.where(los_tx, 1.0, 0.0)
    veg_adj = np.where(a_ev > 0, 10 * np.log10(1 - phi + phi * 10 ** (-a_ev / 10)), 0.0)
    assert (veg_adj <= 1e-9).all(), 'veg_adj must be <= 0'
    print(f'P.833 A_ev: mean {a_ev.mean():.2f} dB p90 {np.percentile(a_ev, 90):.2f} dB max {a_ev.max():.2f} dB')
    print(f'veg_adj: mean {veg_adj.mean():.2f} dB p90 {np.percentile(veg_adj, 90):.2f} dB '
          f'min {veg_adj.min():.2f} dB pairs <-1 dB {(veg_adj < -1).mean() * 100:.1f}%')
    rsrp = D['rsrp_tilt4']
    rsrp_veg = np.where(np.isnan(rsrp), np.nan, (rsrp + veg_adj[:, :, None]).astype(np.float32))
    np.savez_compressed(f'{ROOT}/veg_layer_40m.npz',
                        chm=chm, bld_mask=bld_mask, depth=depth, depth_surveyed=depth_srv,
                        a_ev=a_ev.astype(np.float32), veg_adj=veg_adj.astype(np.float32),
                        phi=phi.astype(np.float32), rsrp_veg_tilt4=rsrp_veg, xs=xs, ys=ys,
                        meta=json.dumps(dict(
                            source='USGS 3DEP CA_SanFrancisco_B23 depths 0-8; class 1, HAG 1-20 m, '
                                   'outside OSM building footprints (api.openstreetmap.org, 1475 ways, '
                                   '2026-11-10); masked CHM 2 m ENU; P.833-10 Eq.(1) 3.6 GHz '
                                   '(gamma,Am)=(0.55,38) INTERPOLATED/ASSUMED, uncalibrated; '
                                   'phi=1 LOS / 0 non-LOS (SF single-tower: LOS median phi 0.968); '
                                   'line sampled every 5 m, height linear TX 30 m -> RX 1.5 m; '
                                   'ENU cos-corrected both axes; masked canopy is an UPPER BOUND '
                                   '(street clutter included)',
                            grid='25x25, 40 m, street 1.5 m', freq_ghz=3.6, tilt_deg=4)))
    print('wrote veg_layer_40m.npz')
    best = np.nanmax(np.nanmax(rsrp, axis=2), axis=1)
    best_v = np.nanmax(np.nanmax(rsrp_veg, axis=2), axis=1)
    print(f'best-server RSRP: no-veg median {np.nanmedian(best):.1f} dBm cov {np.mean(best >= -90) * 100:.1f}% | '
          f'with-veg median {np.nanmedian(best_v):.1f} dBm cov {np.mean(best_v >= -90) * 100:.1f}% | '
          f'median delta {np.nanmedian(best_v - best):+.1f} dB mean delta {np.nanmean(best_v - best):+.1f} dB')


if __name__ == '__main__':
    main()
