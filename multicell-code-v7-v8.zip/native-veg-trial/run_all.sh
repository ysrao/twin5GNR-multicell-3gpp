#!/bin/bash
# Native-veg trial driver: 4 runs (3.6/28 GHz x veg off/on), tower A only,
# 5 chunks each, resumable. Run in background.
cd "$(dirname "$0")"
PY=/home/hatch/workspace/cbrs-wisp-planner/venv/bin/python
for freq in 3.6 28.0; do
  for veg in 0 1; do
    for c in 0 1 2 3 4; do
      $PY rt_native_veg.py --freq $freq --veg $veg --chunk $c || echo "FAILED freq=$freq veg=$veg chunk=$c"
    done
    $PY rt_native_veg.py --freq $freq --veg $veg --post || echo "POST FAILED freq=$freq veg=$veg"
  done
done
echo "ALL DONE"
