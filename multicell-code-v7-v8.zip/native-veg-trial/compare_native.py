"""Compare native-geometry veg vs no-veg (tower A only, 3.6 + 28 GHz),
and vs the P.833 post-trace method (v7 files, tower A, 3.6 GHz measured;
28 GHz P.833 recomputed from the same depth/phi with 28 GHz (gamma,Am))."""
import json
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
TR = f'{ROOT}/native-veg-trial'


def stats(r):
    ok = ~np.isnan(r)
    return dict(n=int(ok.sum()), no_path_pct=float(np.isnan(r).mean() * 100),
                coverage_ge_minus90_pct=float(np.mean(r[ok] >= -90) * 100) if ok.any() else 0.0,
                median_dbm=float(np.nanmedian(r)) if ok.any() else float('nan'),
                p10_dbm=float(np.nanpercentile(r, 10)) if ok.any() else float('nan'),
                p90_dbm=float(np.nanpercentile(r, 90)) if ok.any() else float('nan'))


def best_sector(rsrp):
    # rsrp (625, sectors) -> best sector per cell
    return np.nanmax(rsrp, axis=1)


out = {}
for f in (3.6, 28.0):
    noveg = np.load(f'{TR}/results_native_noveg_f{int(f * 1000)}.npz')
    veg = np.load(f'{TR}/results_native_veg_f{int(f * 1000)}.npz')
    rn = best_sector(noveg['rsrp_tilt4'])
    rv = best_sector(veg['rsrp_tilt4'])
    d = rv - rn
    both = ~np.isnan(rn) & ~np.isnan(rv)
    out[f'f{f}'] = dict(
        noveg=stats(rn), veg=stats(rv),
        delta=dict(median_db=float(np.nanmedian(d[both])) if both.any() else float('nan'),
                   mean_db=float(np.nanmean(d[both])) if both.any() else float('nan'),
                   cells_below_minus1db_pct=float(np.mean(d[both] < -1) * 100),
                   cells_below_minus5db_pct=float(np.mean(d[both] < -5) * 100),
                   worst_db=float(np.nanmin(d[both])) if both.any() else float('nan'),
                   los_pct=float(np.mean(veg['los']) * 100),
                   los_noveg_pct=float(np.mean(noveg['los']) * 100),
                   paths_median_veg=float(np.median(veg['npath'])),
                   paths_median_noveg=float(np.median(noveg['npath']))))

# P.833 comparison, tower A (TX 0), tilt 4, best sector
v5 = np.load(f'{ROOT}/results_multicell_f3600_street.npz')
v7 = np.load(f'{ROOT}/results_veg_40m.npz')
lay = np.load(f'{ROOT}/veg_layer_40m.npz')
r5 = best_sector(v5['rsrp_tilt4'][:, 0, :])
r7 = best_sector(v7['rsrp_veg_tilt4'][:, 0, :])
d7 = r7 - r5
both = ~np.isnan(r5) & ~np.isnan(r7)
out['p833_3.6_towerA'] = dict(
    noveg=stats(r5), veg=stats(r7),
    delta=dict(median_db=float(np.nanmedian(d7[both])), mean_db=float(np.nanmean(d7[both])),
               cells_below_minus1db_pct=float(np.mean(d7[both] < -1) * 100),
               worst_db=float(np.nanmin(d7[both]))))
# P.833 at 28 GHz on the same geometry: A_ev = Am*(1-exp(-d*gamma/Am)),
# phi-weighted, applied to the NATIVE 28 GHz no-veg tower-A RSRP
depth = lay['depth_surveyed'][:, 0]
phi = lay['phi'][:, 0]
for gamma, am in [(2.20, 50.0)]:
    a_ev = am * (1 - np.exp(-depth * gamma / am))
    adj = -a_ev * phi
    noveg28 = np.load(f'{TR}/results_native_noveg_f28000.npz')
    rn28 = best_sector(noveg28['rsrp_tilt4'])
    r28p = rn28 + adj
    d28 = r28p - rn28
    b28 = ~np.isnan(rn28)
    out['p833_28_towerA_on_native28'] = dict(
        noveg=stats(rn28), veg=stats(r28p),
        delta=dict(median_db=float(np.nanmedian(d28[b28])), mean_db=float(np.nanmean(d28[b28])),
                   cells_below_minus1db_pct=float(np.mean(d28[b28] < -1) * 100),
                   worst_db=float(np.nanmin(d28[b28]))),
        depth_mean_m=float(depth.mean()), a_ev_mean_db=float(a_ev.mean()))

print(json.dumps(out, indent=1))
with open(f'{TR}/comparison_native_veg.json', 'w') as fh:
    json.dump(out, fh, indent=1)
print("wrote comparison_native_veg.json")
