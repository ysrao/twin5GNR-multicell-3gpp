"""Calibrate foliage RadioMaterial sigma so one crown (R=4 m, path 8 m)
loses ~P.833 loss: 3.6 GHz -> 4.2 dB, 28 GHz -> 14.8 dB (targets ASSUMED,
from interpolated P.833 (gamma,Am)). Low-poly icosphere (subdiv=1, 80 faces)
as used in the trial. TX/RX 40 m apart, crown centre midway, z=6 m."""
import os
import mitsuba as mi
mi.set_variant('llvm_ad_mono_polarized')
import sionna.rt as rt
from sionna.rt import RadioMaterial
import numpy as np
import trimesh

ROOT = os.path.dirname(os.path.abspath(__file__))
SPH = os.path.join(ROOT, 'crown_ico1.ply')
if not os.path.exists(SPH):
    trimesh.creation.icosphere(subdivisions=1, radius=1.0).export(SPH)
    print("wrote", SPH, flush=True)


def total_power(p):
    ar, ai = (np.asarray(x) for x in p.a)
    pw = ar[:, 0, :, 0, :] ** 2 + ai[:, 0, :, 0, :] ** 2
    vv = np.asarray(p.valid)
    return 10 * np.log10(max(pw[vv].sum(), 1e-30)), int(vv.sum())


def run(freq_ghz, sigma, scat=0.0, thick=4.0, eps=1.2, samples=200000):
    s = rt.Scene()
    mat = RadioMaterial(name="fol", thickness=thick, relative_permittivity=eps,
                        conductivity=sigma, scattering_coefficient=scat)
    obj = rt.SceneObject(fname=SPH, name="crown", radio_material=mat,
                         position=mi.Point3f(0, 0, 6))
    obj.scaling = mi.Vector3f(4.0, 4.0, 4.0)
    s.add(obj)
    s.frequency = freq_ghz * 1e9
    iso = rt.PlanarArray(num_rows=1, num_cols=1, pattern='iso', polarization='V')
    s.tx_array = iso
    s.rx_array = iso
    s.add(rt.Transmitter('tx', position=[-20, 0, 6]))
    s.add(rt.Receiver('rx', position=[20, 0, 6]))
    p = rt.PathSolver()(s, max_depth=3, los=True, specular_reflection=True,
                        diffuse_reflection=(scat > 0), refraction=True,
                        diffraction=True, edge_diffraction=True,
                        samples_per_src=samples, max_num_paths_per_src=samples)
    return total_power(p)


def free(freq_ghz):
    s = rt.Scene()
    s.frequency = freq_ghz * 1e9
    iso = rt.PlanarArray(num_rows=1, num_cols=1, pattern='iso', polarization='V')
    s.tx_array = iso
    s.rx_array = iso
    s.add(rt.Transmitter('tx', position=[-20, 0, 6]))
    s.add(rt.Receiver('rx', position=[20, 0, 6]))
    p = rt.PathSolver()(s, max_depth=3, los=True, specular_reflection=True,
                        diffuse_reflection=False, refraction=True, diffraction=True,
                        edge_diffraction=True, samples_per_src=200000,
                        max_num_paths_per_src=200000)
    return total_power(p)[0]


for f, target in [(3.6, 4.2), (28.0, 14.8)]:
    ref = free(f)
    print(f"\n{f} GHz free-space: {ref:.2f} dB  (P.833 target loss {target} dB)", flush=True)
    for sig in [0.0, 0.0001, 0.0002, 0.0003, 0.0005, 0.0008, 0.001, 0.0015, 0.002, 0.003]:
        tot, n = run(f, sig)
        print(f"  sigma={sig:<7} npaths={n} total={tot:.2f} dB  loss={ref - tot:.2f} dB", flush=True)
