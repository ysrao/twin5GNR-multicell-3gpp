"""Native-vegetation trial: surveyed trees as REAL GEOMETRY in Sionna 2.2.0.

Finding (checked against installed Sionna 2.2.0 source, NOT from memory):
- Sionna 2.2.0 has NO vegetation material, NO foliage/vegetation flag, NO
  P.833 model, and NO participating medium / volume in sionna.rt.
  grep for vegetat/foliage over the installed package finds nothing in
  sionna.rt (only unrelated hits in channel-model code).
- What it DOES have (the native route Sameer means): ordinary geometry via
  Scene.add([SceneObject(fname=..., radio_material=...)]), with
  RadioMaterial (Fresnel slab: eps_r, conductivity, thickness, scattering)
  or ITURadioMaterial or AbsorberRadioMaterial.
- AbsorberRadioMaterial is unusable here in practice: it kills every path
  through a crown (upper bound only), AND setting scene.frequency after
  adding one raises AttributeError ('AbsorberRadioMaterial' has no
  frequency_update) in 2.2.0.
- So crowns are low-poly icospheres (subdiv=1, 80 faces) with a RadioMaterial
  calibrated in calibrate.py: eps_r=1.2 (ASSUMED), scattering S=0.3 (same as
  buildings), thickness = crown radius, conductivity tuned so ONE crown
  (R=4 m, 8 m path) loses the P.833 amount: sigma=0.0005 S/m at 3.6 GHz
  (4.2 dB) and sigma=0.0012 S/m at 28 GHz (15.2 dB at S=0.3; target 14.8 dB).
  eps_r/sigma are ASSUMED calibrations to interpolated P.833, not measured
  foliage properties. A lossless crown (sigma=0) GAINS ~6 dB (dielectric
  lensing) -- hence sigma>0 is essential.
- Geometry: 1,919 surveyed DataSF trees, exact positions (lat/lon -> ENU,
  same conversion as build_sf_veg_surveyed.py), crown allometry ASSUMED
  from trunk diameter (same as v7): R 2/3/4/5 m, crown 3-6 / 2-8 / 2-10 /
  2-12 m above local ground. Crowns merged into ONE mesh per radius class
  (4 SceneObjects total; the stock sphere.ply has 15,872 faces -- 1,919 of
  them would be 30M faces). Trunks skipped: 0.2-0.6 m diameter, negligible
  vs 8 cm / 1 cm wavelength at these sample counts (stated, not hidden).
- Run: tower A only (-250,+250, 30 m AGL), 25x25 grid at 40 m, street 1.5 m,
  same RX grid / nudge rule as rt_multicell.py, max_depth=3, samples 250k
  (28 GHz small-cell pilot showed 250k matches 1M on median/LOS).
  Bands 3.6 and 28 GHz x veg off/on = 4 runs, resumable by chunk.
"""
import argparse, json, math, os, sys, time
import numpy as np

ROOT = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(ROOT)
sys.path.insert(0, PARENT)
SF = '/home/hatch/workspace/sf-twin'
SCENE = os.path.join(SF, 'scene_sf')
RAST = np.load(os.path.join(SCENE, 'height_rasters.npz'))
SURF, GROUND = RAST['surf'], RAST['ground']
RX0, RY0, CELL = float(RAST['x0']), float(RAST['y0']), float(RAST['cell'])
LAT0, LON0 = 37.801105, -122.404175
TILTS = (0.0, 2.0, 4.0, 6.0, 8.0, 10.0)
SECTORS_DEG = (90.0, 210.0, 330.0)
G_ELEM_MAX_DB = 8.0
G_ARRAY_DB = 10 * np.log10(16)
P_COND_DBM = 47.0 - G_ELEM_MAX_DB - G_ARRAY_DB
S_BLD = 0.3
EPS_R = 1.2
SIGMA = {3.6: 0.0005, 28.0: 0.0012}
SAMPLES = 1_000_000  # match v5 exactly: 250k under-samples diffuse paths
# (chunk-0 test: mean paths/RX 0.9 at 250k vs 3.9 in v5 at 1M)
CHUNK = 125


def crown_for(t):
    dbh = t.get('mapdbh')
    try:
        v = float(dbh) if dbh else None
    except ValueError:
        v = None
    if v is None:
        r = {'1': 2.0, '2': 3.0, '3': 4.0, '4': 5.0}.get(str(t.get('dbhrange')), 3.0)
        z = {'1': (3.0, 6.0), '2': (2.0, 8.0), '3': (2.0, 10.0), '4': (2.0, 12.0)}.get(
            str(t.get('dbhrange')), (2.0, 8.0))
        return r, z[0], z[1]
    if v <= 10:
        return 2.0, 3.0, 6.0
    if v <= 20:
        return 3.0, 2.0, 8.0
    if v < 40:
        return 4.0, 2.0, 10.0
    return 5.0, 2.0, 12.0


def build_crown_meshes():
    """Write one merged PLY per radius class. Returns dict R -> filename."""
    import json as _json
    import trimesh
    trees = _json.load(open('/home/hatch/workspace/twin5gnr-work/'
                            'twin5GNR-SF-veg-surveyed/sf_trees_tile.json'))
    kx = 111320.0 * math.cos(math.radians(LAT0))
    ky = 110574.0
    per_class = {}
    skipped = 0
    for t in trees:
        try:
            lat, lon = float(t['latitude']), float(t['longitude'])
        except (KeyError, TypeError, ValueError):
            skipped += 1
            continue
        x, y = (lon - LON0) * kx, (lat - LAT0) * ky
        if abs(x) > 500 or abs(y) > 500:
            continue
        r, z0, z1 = crown_for(t)
        rr, cc = int(np.clip((y - RY0) / CELL, 0, GROUND.shape[0] - 1)), \
            int(np.clip((x - RX0) / CELL, 0, GROUND.shape[1] - 1))
        gz = float(GROUND[rr, cc])
        zc = gz + (z0 + z1) / 2.0
        zh = (z1 - z0) / 2.0
        per_class.setdefault(r, []).append((x, y, zc, zh))
    out = {}
    for r, lst in sorted(per_class.items()):
        meshes = []
        for (x, y, zc, zh) in lst:
            m = trimesh.creation.icosphere(subdivisions=1, radius=1.0)
            m.apply_scale([r, r, zh])
            m.apply_translation([x, y, zc])
            meshes.append(m)
        merged = trimesh.util.concatenate(meshes)
        fn = os.path.join(ROOT, f'crowns_r{int(r)}.ply')
        merged.export(fn)
        out[r] = (fn, len(lst), len(merged.faces))
        print(f"class R={r} m: {len(lst)} trees, {len(merged.faces)} faces -> {fn}", flush=True)
    print(f"skipped (no coords/out of tile): {skipped}", flush=True)
    return out


def build_rx_grid():
    from rt_multicell import build_rx_grid as _b
    return _b()


def load_scene(freq_ghz, veg):
    import mitsuba as mi
    mi.set_variant('llvm_ad_mono_polarized')
    import sionna.rt as rt
    from sionna.rt import RadioMaterial
    from sionna.rt.radio_materials.itu import itu_material
    import drjit as dr
    s = rt.load_scene(os.path.join(SCENE, 'scene.xml'), merge_shapes=True)
    for m in s.radio_materials.values():
        if type(m).__name__ != 'ITURadioMaterial':
            continue
        t = m.itu_type
        m.scattering_coefficient = S_BLD
        if freq_ghz < 1.0 or freq_ghz > 10.0:
            m.frequency_update_callback = (
                lambda f, _t=t: itu_material(_t, dr.minimum(dr.maximum(f, 1e9), 1e12)))
    if veg:
        objs = []
        for r in (2.0, 3.0, 4.0, 5.0):
            fn = os.path.join(ROOT, f'crowns_r{int(r)}.ply')
            mat = RadioMaterial(name=f"foliage-r{int(r)}", thickness=float(r),
                                relative_permittivity=EPS_R,
                                conductivity=SIGMA[freq_ghz],
                                scattering_coefficient=0.3)
            objs.append(rt.SceneObject(fname=fn, name=f"crowns-r{int(r)}",
                                       radio_material=mat))
        s.add(objs)  # one batch = one scene rebuild
    s.frequency = freq_ghz * 1e9
    iso = rt.PlanarArray(num_rows=1, num_cols=1, pattern='iso', polarization='V')
    s.tx_array = iso
    s.rx_array = iso
    return s, rt


def tr38901_gain_db(theta, phi, tilt_deg, az_deg):
    from rt_multicell import tr38901_gain_db as _g
    return _g(theta, phi, tilt_deg, az_deg)


def solve_chunk(pts, tx, freq_ghz, veg):
    s, rt = load_scene(freq_ghz, veg)
    s.add(rt.Transmitter('txA', position=[tx[0], tx[1], tx[2]]))
    for i, (x, y, z) in enumerate(pts):
        s.add(rt.Receiver(f'r{i}', position=[float(x), float(y), float(z)]))
    t0 = time.time()
    p = rt.PathSolver()(s, max_depth=3, los=True, specular_reflection=True,
                        diffuse_reflection=True, refraction=True, diffraction=True,
                        edge_diffraction=True, samples_per_src=SAMPLES,
                        max_num_paths_per_src=SAMPLES)
    dt = time.time() - t0
    ar, ai = (np.asarray(a) for a in p.a)
    v = np.asarray(p.valid).astype(bool)
    pw = np.where(v, (ar[:, 0, :, 0, :] ** 2 + ai[:, 0, :, 0, :] ** 2), 0.0)
    th = np.asarray(p.theta_t)
    ph = np.asarray(p.phi_t)
    inter = np.asarray(p.interactions)
    is_los = (inter == 0).all(axis=0) & v
    dirpw = np.zeros((len(pts), len(TILTS), len(SECTORS_DEG)))
    for ti, tilt in enumerate(TILTS):
        for si, az in enumerate(SECTORS_DEG):
            g = np.where(v, 10 ** (tr38901_gain_db(th, ph, tilt, az) / 10), 0.0)
            dirpw[:, ti, si] = (pw * g).sum(axis=2)[:, 0]
    iso = pw.sum(axis=2)[:, 0]
    return dict(dirpw=dirpw, iso=iso, los=is_los.any(axis=2)[:, 0],
                npath=v.sum(axis=2)[:, 0]), dt


def fname(freq_ghz, veg):
    tag = 'veg' if veg else 'noveg'
    return os.path.join(ROOT, f'results_native_{tag}_f{int(freq_ghz * 1000)}.npz')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--build-meshes', action='store_true')
    ap.add_argument('--freq', type=float, choices=[3.6, 28.0])
    ap.add_argument('--veg', type=int, choices=[0, 1])
    ap.add_argument('--chunk', type=int)
    ap.add_argument('--post', action='store_true')
    a = ap.parse_args()
    if a.build_meshes:
        build_crown_meshes()
        return
    txs, xs, ys, pts, moved, indoor = build_rx_grid()
    tx = txs[0]  # tower A only
    n = len(pts)
    chunks = [(i, min(i + CHUNK, n)) for i in range(0, n, CHUNK)]
    out = fname(a.freq, bool(a.veg))
    if a.post:
        d = dict(np.load(out, allow_pickle=True))
        assert len(d['done']) == len(chunks), f"chunks {sorted(d['done'])} of {len(chunks)}"
        t4 = TILTS.index(4.0)
        rsrp = np.where(d['dirpw'][:, t4, :] > 0,
                        P_COND_DBM + G_ARRAY_DB + 10 * np.log10(
                            np.maximum(d['dirpw'][:, t4, :], 1e-30)), np.nan)
        d['rsrp_tilt4'] = rsrp.astype(np.float32)
        d['rsrp_best'] = np.nanmax(rsrp, axis=1).astype(np.float32)
        np.savez_compressed(out, **d)
        r = d['rsrp_best']
        print(f"native f{a.freq} veg={a.veg}: n={n} no-path {np.isnan(r).mean()*100:.1f}%  "
              f"LOS {d['los'].mean()*100:.1f}%  RSRP>=-90 {np.mean(r >= -90)*100:.1f}%  "
              f"median {np.nanmedian(r):.1f} dBm", flush=True)
        return
    if a.chunk is None:
        print(f'{len(chunks)} chunks; pass --chunk 0..{len(chunks)-1}; tower A {tx}')
        return
    i0, i1 = chunks[a.chunk]
    res, dt = solve_chunk(pts[i0:i1], (tx[1], tx[2], tx[3]), a.freq, bool(a.veg))
    if os.path.exists(out):
        d = dict(np.load(out, allow_pickle=True))
        done = set(d['done'].tolist())
    else:
        d = dict(dirpw=np.zeros((n, len(TILTS), len(SECTORS_DEG))),
                 iso=np.zeros((n,)), los=np.zeros((n,), bool),
                 npath=np.zeros((n,), np.int32))
        done = set()
    for k, val in res.items():
        d[k][i0:i1] = val
    done.add(a.chunk)
    d.update(xs=xs, ys=ys, rx_xyz=pts, moved=moved, indoor=indoor,
             tilts=np.array(TILTS), sectors=np.array(SECTORS_DEG),
             tx=np.array(tx, dtype=object), done=np.array(sorted(done)),
             meta=json.dumps(dict(freq_ghz=a.freq, veg=bool(a.veg), rx='street',
                                  tx_agl_m=30.0, samples=SAMPLES, max_depth=3,
                                  eps_r=EPS_R, sigma=SIGMA[a.freq],
                                  scattering=0.3, thickness='crown radius',
                                  scene='Vexcel SF L20 + merged crown icospheres',
                                  version='native-veg-trial')))
    np.savez_compressed(out, **d)
    print(f"native f{a.freq} veg={a.veg} chunk {a.chunk}/{len(chunks)-1}: "
          f"{i1-i0} pts in {dt:.0f}s; paths/RX median {np.median(res['npath']):.0f}",
          flush=True)


if __name__ == '__main__':
    main()
