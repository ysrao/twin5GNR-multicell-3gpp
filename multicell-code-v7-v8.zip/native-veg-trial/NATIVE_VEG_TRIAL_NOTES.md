# Native-vegetation trial — trees as real geometry in Sionna 2.2.0

Trial, NOT an artefact version. Tower A only, 25x25 grid at 40 m, street 1.5 m.
All figures ray-traced/simulated, never measured.

## 1. What Sionna 2.2.0 actually supports (checked in the installed package)

- **No vegetation material, no foliage/vegetation flag, no P.833 model, no
  participating medium/volume anywhere in `sionna.rt`.** A grep for
  vegetat/foliage over the installed package finds nothing in `sionna.rt`
  (only unrelated hits in channel-model code). There is no "enable
  vegetation" switch to flip.
- What exists is the generic route: add geometry with
  `Scene.add([SceneObject(fname=..., radio_material=...)])` and give it a
  `RadioMaterial` (Fresnel slab: relative permittivity, conductivity,
  thickness, scattering coefficient), an `ITURadioMaterial` (ITU-R P.2040
  types: concrete, wood, glass, ...), or an `AbsorberRadioMaterial`.
- `AbsorberRadioMaterial` is unusable here in practice: it kills every path
  through a crown (upper bound only), AND setting `scene.frequency` after
  adding one raises `AttributeError` (no `frequency_update`) in 2.2.0.
- So "native vegetation" in Sionna 2.2.0 can only mean: **trees as meshes
  with a lossy RadioMaterial**. That is what this trial built. Sameer's
  "add or enable" is the geometry route, not a built-in veg feature.

## 2. How the trees were added

- 1,919 surveyed DataSF street trees, exact positions (lat/lon -> ENU, same
  conversion as `build_sf_veg_surveyed.py`), crown allometry ASSUMED from
  trunk diameter (same as v7): radius 2/3/4/5 m, crown 3-6 / 2-8 / 2-10 /
  2-12 m above local ground (919 / 821 / 161 / 18 trees per class).
- Crowns are low-poly icospheres (subdiv=1, 80 faces), scaled to ellipsoids
  (R, R, crown half-height), merged into ONE mesh per radius class
  (153,520 faces total; the stock `sphere.ply` has 15,872 faces, so 1,919
  of them would be 30M faces). 4 SceneObjects, added in one batch.
- Trunks skipped: 0.2-0.6 m diameter, negligible at these wavelengths
  (stated, not hidden).
- Foliage material (per radius class, thickness = crown radius):
  `RadioMaterial(eps_r=1.2 ASSUMED, sigma calibrated, S=0.3 same as
  buildings)`. Calibration in `calibrate.py`: a single crown (R=4 m, 8 m
  path) between TX and RX 40 m apart. A lossless crown (sigma=0) GAINS
  ~6 dB (dielectric lensing + scattered paths), so sigma>0 is essential.
  Calibrated sigma: **0.0005 S/m at 3.6 GHz (4.2 dB, P.833 target 4.2 dB),
  0.0012 S/m at 28 GHz (15.2 dB at S=0.3, target 14.8 dB)**. Targets are
  the interpolated/assumed P.833 (gamma,Am) — so the material is calibrated
  TO P.833 for one crown, and the geometry then does the rest. Scattering
  S=0.3 vs 0 changes the single-crown total by <=0.7 dB.
- Behaviour found while calibrating: the solver drops refracted paths when
  they get too weak (sigma=0.005 gives -60 dB through one crown; sigma>=0.01
  gives 0 paths, not a very weak path). A path attenuated ~60 dB+ per crown
  vanishes rather than lingering — a cliff, not a smooth tail.

## 3. Runs

Tower A only (-250,+250, 30 m AGL), 1M samples (250k under-samples diffuse
paths: mean paths/RX 0.9 vs 3.9 in v5 at 1M), max_depth=3, same solver flags
as `rt_multicell.py`. 4 runs x 5 chunks of 125 RX, ~16 min total.
Runtime per run ~4 min; a full 3-tower tile would be ~12 min per band/veg
state (same order as v5's 13 min). 10 m grid (10,000 cells x 3 towers)
would be ~16x the v6 10 m run (~2h10m) with trees — feasible in chunks,
several hours.

## 4. Results — native veg vs no-veg, tower A only, 625 cells

Coverage here is over ALL 625 cells (same convention as v5/v7); median RSRP
is over cells with a path. Deltas are paired (cells with a path in both runs).

| | 3.6 GHz no-veg | 3.6 GHz native veg | 28 GHz no-veg | 28 GHz native veg |
|---|---|---|---|---|
| No-path | 35.7% | 36.3% | 36.2% | 38.2% |
| Coverage >= -90 dBm | 36.2% | 35.4% | 12.8% | 11.8% |
| Median best RSRP | -86.7 dBm | -87.0 dBm | -105.6 dBm | -105.6 dBm |
| LOS to tower A | 8.2% | 7.7% | 8.2% | 7.7% |

Native-veg delta (paired): median **0.00 dB at both bands**; mean **-1.26 dB
(3.6 GHz)** and **-1.06 dB (28 GHz)**; 19.8% / 17.1% of cells lose >1 dB;
7.5% / 6.2% lose >5 dB; worst **-28.9 dB (3.6)** / **-30.9 dB (28)**.
Median paths/RX 7 -> 6 (3.6 GHz), 6 -> 5 (28 GHz). 4 cells (3.6) / 13 cells
(28) lose their path entirely; none gain one.

## 5. Native vs P.833 (tower A)

| | P.833 3.6 GHz | Native 3.6 GHz | P.833 28 GHz* | Native 28 GHz |
|---|---|---|---|---|
| Mean delta | -0.10 dB | -1.26 dB | -0.37 dB | -1.06 dB |
| Median delta | 0.00 dB | 0.00 dB | 0.00 dB | 0.00 dB |
| Cells >1 dB loss | 2.8% | 19.8% | 2.8% | 17.1% |
| Worst cell | -7.5 dB | -28.9 dB | -24.3 dB | -30.9 dB |

\* P.833 at 28 GHz recomputed from the v7 depth/phi layer with (gamma,Am) =
(2.20, 50), applied to the native 28 GHz no-veg baseline (no P.833 28 GHz
tower-A run exists).

## 6. Why they differ — the key finding

The loss is almost entirely on **NLOS** cells, not LOS cells:

- LOS cells (48): mean delta **-0.04 dB at both bands**, worst -2.0 dB.
- NLOS cells (350 at 3.6 GHz, 338 at 28 GHz): mean delta **-1.43 dB /
  -1.21 dB**, 22.3% / 19.2% lose >1 dB, worst -28.9 / -30.9 dB.

P.833 only touches LOS pairs (phi=1 for LOS, 0 for NLOS), so it can only
ever see the small LOS effect. Native geometry attenuates every path that
passes through a crown — and most cells at 500+ m from the tower have no
LOS and live on diffuse/specular paths that thread through street trees.
A crown on the direct line does not just subtract a few dB: it converts
that LOS path into a blocked/diffracted one, and if no good alternative
path exists the cell falls 29-31 dB. That is also why 4 / 13 cells lose
their path entirely.

## 7. Honest caveats — read before quoting either number

- **P.833 LOS-only is a lower bound** (ignores all NLOS paths, which are
  most paths at street level). **Native solid-crown is an upper bound**:
  a crown is modelled as a solid dielectric slab with no gaps, while real
  foliage is sparse — every ray through a crown pays full slab loss. The
  truth is probably between the two.
- The material is calibrated to interpolated/assumed P.833 for ONE crown;
  eps_r=1.2 and sigma are assumptions, not measured foliage properties.
- Crowns are 80-face faceted ellipsoids; crown size/height are assumed
  from trunk diameter, not measured (same allometry as v7).
- Tower A only, 40 m grid, single 30 m macro tower. Small cells at 8 m
  (v8) sit inside the crown band and would see a bigger effect — not run
  natively yet.
- Median delta is 0.00 dB in BOTH methods at BOTH bands: the headline
  "trees don't move the median" is unchanged. The difference is entirely
  in the tail (mean, % of cells >1 dB, worst cell).

## 8. Files (all under `native-veg-trial/`)

- `rt_native_veg.py` — trial driver (mesh build + ray trace, resumable chunks)
- `calibrate.py`, `crown_ico1.ply` — single-crown calibration
- `crowns_r2/3/4/5.ply` — merged crown meshes (1,919 trees, 153,520 faces)
- `results_native_noveg_f3600.npz`, `results_native_veg_f3600.npz`,
  `results_native_noveg_f28000.npz`, `results_native_veg_f28000.npz`
- `compare_native.py`, `comparison_native_veg.json`, `run_all.sh`,
  `run_all.log`
- No v5-v8 HTML files touched, nothing published, nothing sent.
