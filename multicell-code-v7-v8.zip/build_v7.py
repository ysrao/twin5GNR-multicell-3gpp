#!/usr/bin/env python3
"""build_v7.py - build the v7 handoff artefact HTML (Sionna + trees) from v5.

Reads:
  6g-ran-multicell-handoff-v5.html
  results_veg_40m.npz  (rsrp_veg_tilt4, surveyed-tree P.833, (625,3,3))
  comparison_veg.json  (three-way stats)
Writes:
  6g-ran-multicell-handoff-v7.html  (self-contained; 3GPP / Sionna / Sionna+trees)
Model radios: 3gpp | sionna | sionna_veg. The veg grid is the surveyed-tree
P.833 layer (headline); the LiDAR hybrid is sensitivity only and is NOT
embedded (its numbers are in the comparison note).
"""
import json, math, re
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
V = dict(np.load(f'{ROOT}/results_veg_40m.npz', allow_pickle=True))
CMP = json.load(open(f'{ROOT}/comparison_veg.json'))
rsrp = V['rsrp_veg_tilt4']  # (625,3,3)
xs, ys = [float(v) for v in V['xs']], [float(v) for v in V['ys']]

def r(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(v) else round(v, 1)

veg = {'xs': xs, 'ys': ys,
       'rsrp': [[[r(rsrp[i, t, s]) for s in range(3)] for t in range(3)] for i in range(625)]}
veg_json = json.dumps(veg, separators=(',', ':'))

html = open(f'{ROOT}/6g-ran-multicell-handoff-v5.html').read()

# --- 1. title / header / version stamp ---
html = html.replace('<title>6G RAN Multi-Cell Handoff Artefact v5 — 3GPP + Sionna</title>',
                    '<title>6G RAN Multi-Cell Handoff Artefact v7 — 3GPP + Sionna + trees</title>')
html = html.replace('<h1>6G RAN Multi-Cell Handoff Artefact v5 — 9 Nov 2026</h1>',
                    '<h1>6G RAN Multi-Cell Handoff Artefact v7 — 10 Nov 2026</h1>')
html = html.replace('Version inside the file: v5.', 'Version inside the file: v7.')

# --- 2. model radios: add Sionna + trees ---
old_radio = ('<label><input type="radio" name="model" value="sionna"> Sionna ray-traced (simulated, 3.6 GHz)</label> — '
             'toggle to compare the same 3 towers on the real 3D city mesh versus the 3GPP formula.')
new_radio = ('<label><input type="radio" name="model" value="sionna"> Sionna ray-traced (simulated, 3.6 GHz)</label> '
             '<label><input type="radio" name="model" value="sionna_veg"> Sionna + trees (simulated, 3.6 GHz, surveyed trees + ITU-R P.833)</label> — '
             'toggle to compare the same 3 towers on the real 3D city mesh versus the 3GPP formula, with and without vegetation.')
assert old_radio in html
html = html.replace(old_radio, new_radio, 1)

# veg note paragraph after sionnaNote
old_note_end = ('Cell locations are fixed in Sionna mode (they are the ray-traced tower positions).</p>')
new_note_end = (old_note_end +
    '<p id="vegNote" style="display:none" class="note"><b>Sionna + trees mode:</b> same ray-traced RSRP as Sionna mode, '
    'with ITU-R P.833-10 foliage loss applied per tower–receiver path from the 1,919 surveyed DataSF street trees '
    '(exact positions; crown size assumed from trunk diameter, P.833 (gamma, Am) = (0.55, 38) at 3.6 GHz interpolated/assumed, '
    'uncalibrated). Foliage depth is the straight-line path length inside tree crowns, sampled every 5 m. '
    'At 3.6 GHz the effect is small — see the comparison note — because P.833 loss at 3.6 GHz saturates low; '
    'the same trees matter far more at 28 GHz. Free 3DEP LiDAR confirms 97.6% of the surveyed trees within 2 m, '
    'but its canopy-height layer cannot be used as the headline foliage layer: it has no crown bottom and counts '
    'clutter and unmapped buildings, overstating foliage depth ~10× versus the surveyed positions.</p>')
assert old_note_end in html
html = html.replace(old_note_end, new_note_end, 1)

# --- 3. footer ---
old_footer = re.search(r'<p>6G RAN Multi-Cell Handoff Artefact v5.*?</p>', html, flags=re.S).group(0)
new_footer = (
    '<p>6G RAN Multi-Cell Handoff Artefact v7 — 10 Nov 2026 — 3GPP-model version plus Sionna ray-traced version with and without '
    'vegetation, published at https://ysrao.github.io/twin5GNR-multicell-3gpp/. v7: Sionna + trees — ITU-R P.833-10 foliage loss from the '
    '1,919 surveyed DataSF street trees applied to the v5 ray-traced RSRP (3.6 GHz, 25×25 grid at 40 m, street 1.5 m); measured effect at '
    '3.6 GHz is ~0 at the median (see comparison note). v6: 10 m Sionna grid (separate run). v5: Sionna 2.2.0 ray tracing on the Vexcel SF '
    '3D mesh (downtown SF, 1 km², 3 towers at 30 m AGL, 3.6 GHz), with a 3GPP / Sionna toggle. v4: ICI degradation added, DL and UL separate. '
    'v3: 3 towers × 3 sectors = 9 sectors. HO is marked both between sectors on the same tower (intra-tower) and between different towers '
    '(inter-tower). v2 used 3 towers × 1 sector = 3 cells.</p>')
html = html.replace(old_footer, new_footer, 1)

# --- 4. comparison note: replace the v5 note div ---
c = CMP['sionna']; g = CMP['gpp']; v = CMP['sionna_veg']; h = CMP['sionna_hybrid']
note = f'''<div class="note"><b>3GPP vs Sionna vs Sionna + trees — what the toggle shows (ray-traced / simulated, 3.6 GHz, street 1.5 m, 625 cells at 40 m):</b>
<ul>
<li><b>Coverage (RSRP ≥ −90 dBm):</b> 3GPP UMa {g['coverage_ge_minus90_pct']}% vs Sionna {c['coverage_ge_minus90_pct']}% vs Sionna + trees {v['coverage_ge_minus90_pct']}% — trees change nothing at the coverage level.</li>
<li><b>Median best-server RSRP:</b> 3GPP {g['median_rsrp_dbm']} dBm vs Sionna {c['median_rsrp_dbm']} dBm vs Sionna + trees {v['median_rsrp_dbm']} dBm. Trees: median change {v['median_delta_db']:+.1f} dB, mean {v['mean_delta_db']:+.2f} dB.</li>
<li><b>Where trees bite:</b> {v['cells_below_minus1db_pct']}% of cells lose more than 1 dB to foliage; worst cell loses {v['max_loss_db']:.1f} dB. Best server changes on only {(100 - CMP['veg_server_agreement_pct']):.1f}% of cells. Handoff region (&lt;3 dB, sector level): 3GPP {g['ho_region_pct']}% vs Sionna {c['ho_region_pct']}% vs Sionna + trees {v['ho_region_pct']}%.</li>
<li><b>Why so small at 3.6 GHz:</b> P.833 foliage loss at 3.6 GHz saturates at Am = 38 dB but needs long in-canopy paths to build up; mean foliage depth here is {v['depth_mean_m']:.2f} m (mean P.833 loss {v['a_ev_mean_db']:.2f} dB), and most of the ray-traced power at street level is non-LOS, so the LOS-weighted foliage term barely moves the total. The same surveyed trees cut 28 GHz throughput by 15–33% at 100–500 m in the earlier SF vegetation run — at 3.6 GHz they are a tail effect, not a coverage effect. That is a measured result here, not an assumption.</li>
<li><b>LiDAR sensitivity (not in the toggle):</b> free USGS 3DEP LiDAR independently confirms 97.6% of the surveyed trees within 2 m, and adds park/private canopy the street survey misses. But its canopy-height layer, used directly, gives mean foliage depth 43.5 m versus 4.07 m from the surveyed positions — ~10× — because it has no crown bottom and counts clutter and buildings OSM misses. Even after roof-exclusion and a 6 m crown thickness it stays ~14–20 m. A hybrid (surveyed + non-street LiDAR canopy) gives mean depth {h['depth_mean_m']:.2f} m, median RSRP change {h['median_delta_db']:+.1f} dB, mean {h['mean_delta_db']:+.2f} dB, {h['cells_below_minus1db_pct']}% of cells below −1 dB — still small at 3.6 GHz, and still an upper bound. So the toggle uses the surveyed trees only; the LiDAR layer is reported here, not embedded.</li>
</ul>
Assumptions, stated: Sionna sectors 90°/210°/330° in ENU; 3GPP sectors 0°/120°/240° in artefact grid coordinates. Foliage: P.833-10 Eq.(1), (gamma, Am) = (0.55, 38) at 3.6 GHz interpolated/assumed and uncalibrated; crown size assumed from trunk diameter; phi-weighted (LOS share 1 for LOS pairs, 0 for non-LOS — the SF single-tower run measured median LOS phi 0.968). Sionna is a simulation on a 1 m-facet mesh with one material (ITU concrete) — it is not a measurement, and it does not include vehicles or indoor loss.</div>'''
m = re.search(r'<div class="note"><b>3GPP vs Sionna — what the toggle shows.*?</div>\n<table id="uetable">',
              html, flags=re.S)
assert m, 'v5 comparison note not found'
html = html[:m.start()] + note + '\n<table id="uetable">' + html[m.end():]

# --- 5. embed SIONNA_VEG data ---
m = re.search(r'const SIONNA=\{.*?\};', html, flags=re.S)
assert m, 'SIONNA const not found'
html = html[:m.end()] + '\nconst SIONNA_VEG=' + veg_json + ';' + html[m.end():]

# --- 6. JS: generalise Sionna mode to the veg grid ---
old_cell = '''function sionnaCell(x,y){
 // artefact grid (north-up) -> ENU -> nearest 40 m grid point
 const ex=x-500, ey=500-y;
 let ci=0,ri=0,bd=1e9;
 for(let i=0;i<SIONNA.xs.length;i++){ const d=Math.abs(SIONNA.xs[i]-ex); if(d<bd){bd=d;ci=i;} }
 bd=1e9;
 for(let i=0;i<SIONNA.ys.length;i++){ const d=Math.abs(SIONNA.ys[i]-ey); if(d<bd){bd=d;ri=i;} }
 return SIONNA.rsrp[ri*25+ci];
}'''
new_cell = '''function sionnaCell(x,y,grid){
 // artefact grid (north-up) -> ENU -> nearest 40 m grid point
 const ex=x-500, ey=500-y;
 let ci=0,ri=0,bd=1e9;
 for(let i=0;i<grid.xs.length;i++){ const d=Math.abs(grid.xs[i]-ex); if(d<bd){bd=d;ci=i;} }
 bd=1e9;
 for(let i=0;i<grid.ys.length;i++){ const d=Math.abs(grid.ys[i]-ey); if(d<bd){bd=d;ri=i;} }
 return grid.rsrp[ri*25+ci];
}
function isSionna(){ return model()==='sionna'||model()==='sionna_veg'; }'''
assert old_cell in html
html = html.replace(old_cell, new_cell, 1)

old_rsrps = """ if(model()==='sionna'){
  const cell=SIONNA.rsrp ? sionnaCell(x,y) : null;"""
new_rsrps = """ if(isSionna()){
  const grid=(model()==='sionna_veg')?SIONNA_VEG:SIONNA;
  const cell=grid.rsrp ? sionnaCell(x,y,grid) : null;"""
assert old_rsrps in html
html = html.replace(old_rsrps, new_rsrps, 1)

html = html.replace("if(model()==='sionna' && r[0].rsrp<=-999){",
                    "if(isSionna() && r[0].rsrp<=-999){", 1)
html = html.replace("const fEff=(model()==='sionna')?3.6:f;",
                    "const fEff=isSionna()?3.6:f;", 1)
html = html.replace("const ulRsrp = (model()==='sionna') ? (r[0].rsrp - 47 + 23) : (23 + sectorGain(r[0].cell, u.x, u.y) - plServ);",
                    "const ulRsrp = isSionna() ? (r[0].rsrp - 47 + 23) : (23 + sectorGain(r[0].cell, u.x, u.y) - plServ);", 1)
html = html.replace("(model()==='sionna'?'Sionna ray-traced 3.6 GHz':'3GPP '+f+' GHz')",
                    "(model()==='sionna'?'Sionna ray-traced 3.6 GHz':model()==='sionna_veg'?'Sionna + trees 3.6 GHz':'3GPP '+f+' GHz')", 1)
old_list = """ document.getElementById('sionnaNote').style.display=(model()==='sionna')?'block':'none';
 ['ax','ay','bx','by','cx','cy'].forEach(id=>document.getElementById(id).disabled=(model()==='sionna'));"""
new_list = """ document.getElementById('sionnaNote').style.display=isSionna()?'block':'none';
 document.getElementById('vegNote').style.display=(model()==='sionna_veg')?'block':'none';
 ['ax','ay','bx','by','cx','cy'].forEach(id=>document.getElementById(id).disabled=isSionna());"""
assert old_list in html
html = html.replace(old_list, new_list, 1)

assert 'Version inside the file: v7.' in html
assert 'SIONNA_VEG' in html and 'sionna_veg' in html
assert 'Version inside the file: v5.' not in html
open(f'{ROOT}/6g-ran-multicell-handoff-v7.html', 'w').write(html)
print('wrote 6g-ran-multicell-handoff-v7.html', len(html), 'bytes; veg JSON', len(veg_json), 'bytes')
