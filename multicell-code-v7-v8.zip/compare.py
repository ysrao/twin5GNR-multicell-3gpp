#!/usr/bin/env python3
"""compare.py - 3GPP (UMa) vs Sionna ray-traced RSRP on the same 25x25 grid.
Reads results_multicell_f3600_street.npz (post-processed: rsrp_tilt4).
3GPP: UMa 28+22log10(d)+20log10(3.6), EIRP 47 dBm, sector pattern
15 - min(12*(diff/65)^2, 25) dBi, sectors 0/120/240 deg in artefact grid
coords, d>=10 m -- exactly the v4 artefact formula at 3.6 GHz.
Grid mapping (artefact, north-up): gx = enu_x + 500, gy = 500 - enu_y.
Outputs comparison.json + prints the numbers for the v5 note.
Provenance: Sionna = ray-traced/simulated on Vexcel mesh; 3GPP = modelled.
"""
import json, math
import numpy as np

D = dict(np.load('results_multicell_f3600_street.npz', allow_pickle=True))
xs, ys = D['xs'], D['ys']          # ENU, 25 each, ascending
rsrp = D['rsrp_tilt4']             # (625, 3 TX, 3 sectors), tilt 4 deg
los = D['los_tx']                  # (625, 3 TX)
pts = D['rx_xyz']                  # (625, 3) ENU
moved = D['moved']
# grid index: pts are row-major over ys then xs
sion_best_tx = np.nanmax(rsrp, axis=2)            # (625,3) best sector per TX
sion_best = np.nanmax(sion_best_tx, axis=1)       # (625,)
sion_best_tx_idx = np.where(np.isnan(sion_best_tx).all(axis=1), -1,
                          np.nanargmax(np.where(np.isnan(sion_best_tx), -np.inf, sion_best_tx), axis=1))

# --- 3GPP on the same points, artefact grid coords ---
gx = pts[:, 0] + 500.0
gy = 500.0 - pts[:, 1]
TOWERS = {'A': (250., 250.), 'B': (750., 250.), 'C': (500., 750.)}
def sector_gain(az_deg, x, y, tx, ty):
    ang = math.degrees(math.atan2(y - ty, x - tx))
    diff = abs((ang - az_deg + 180) % 360 - 180)
    return 15 - min(12 * (diff / 65.0) ** 2, 25)
def pl_uma(d):
    return 28.0 + 22 * math.log10(max(d, 10.0)) + 20 * math.log10(3.6)
g3 = np.zeros((625, 3, 3))
for ti, (nm, (tx, ty)) in enumerate(TOWERS.items()):
    for si, az in enumerate((0, 120, 240)):
        for i in range(625):
            d = math.hypot(gx[i] - tx, gy[i] - ty)
            g3[i, ti, si] = 47 + sector_gain(az, gx[i], gy[i], tx, ty) - pl_uma(d)
g3_best_tx = g3.max(axis=2)
g3_best = g3_best_tx.max(axis=1)
g3_best_tx_idx = g3_best_tx.argmax(axis=1)

def stats(name, best, best_tx_idx, los_frac=None):
    cov = np.mean(best >= -90) * 100
    print(f"{name}: coverage RSRP>=-90 {cov:.1f}%  median {np.nanmedian(best):.1f} dBm  "
          f"p10 {np.nanpercentile(best, 10):.1f}  p90 {np.nanpercentile(best, 90):.1f}")
    return cov
print("=== best-tower RSRP, 625 cells, 3.6 GHz, street 1.5 m, tilt 4 deg ===")
c_s = stats('Sionna ray-traced', sion_best, sion_best_tx_idx)
c_g = stats('3GPP UMa modelled', g3_best, g3_best_tx_idx)
print(f"no-path (Sionna, no ray to any TX): {np.isnan(sion_best).mean()*100:.1f}%")
print(f"LOS to >=1 TX (Sionna): {los.any(axis=1).mean()*100:.1f}%  "
      f"per TX: {[round(float(los[:, t].mean()*100), 1) for t in range(3)]}")
print(f"moved (nudged out of building footprint): {np.mean(moved == 1)*100:.1f}%  "
      f"still indoor: {np.mean(moved == -1)*100:.1f}%")
diff = sion_best - g3_best
print(f"RSRP diff Sionna-3GPP: median {np.nanmedian(diff):.1f} dB  mean {np.nanmean(diff):.1f} dB  "
      f"p10 {np.nanpercentile(diff, 10):.1f}  p90 {np.nanpercentile(diff, 90):.1f}")
print(f"best-server agreement: {(sion_best_tx_idx == g3_best_tx_idx).mean()*100:.1f}% of cells")
# HO region: best-second < 3 dB, sector level
def ho_frac(rsrp_sector):
    flat = np.sort(rsrp_sector.reshape(625, -1), axis=1)
    return float(np.mean((flat[:, -1] - flat[:, -2]) < 3.0) * 100)
print(f"HO region (<3 dB, sector level): Sionna {ho_frac(rsrp):.1f}%  3GPP {ho_frac(g3):.1f}%")
# where Sionna is much weaker: shadow cells
shadow = (diff < -15)
print(f"cells where Sionna is >15 dB below 3GPP (building shadow): {shadow.mean()*100:.1f}%")
print(f"cells where Sionna is >10 dB above 3GPP: {(diff > 10).mean()*100:.1f}%")
# per-TX coverage
for ti, nm in enumerate('ABC'):
    print(f"  TX {nm}: Sionna cov {np.mean(sion_best_tx[:, ti] >= -90)*100:.1f}%  "
          f"3GPP cov {np.mean(g3_best_tx[:, ti] >= -90)*100:.1f}%  "
          f"median Sionna {np.nanmedian(sion_best_tx[:, ti]):.1f} vs 3GPP {np.median(g3_best_tx[:, ti]):.1f} dBm")
# UE positions (v4 defaults, artefact grid coords)
UES = [(300, 400), (200, 600), (600, 500), (400, 200), (800, 700), (100, 100)]
print("=== UEs (nearest Sionna grid cell) ===")
for ui, (ux, uy) in enumerate(UES):
    enu_x, enu_y = ux - 500, 500 - uy
    ci = int(np.argmin(np.abs(xs - enu_x))); ri = int(np.argmin(np.abs(ys - enu_y)))
    idx = ri * 25 + ci
    s_best = sion_best[idx]; g_best = g3_best[idx]
    s_tx = 'ABC'[sion_best_tx_idx[idx]]; g_tx = 'ABC'[g3_best_tx_idx[idx]]
    print(f"  UE{ui+1} ({ux},{uy}) cell ({xs[ci]:.0f},{ys[ri]:.0f}): Sionna {s_best:.1f} dBm TX{s_tx}  "
          f"3GPP {g_best:.1f} dBm TX{g_tx}  diff {s_best-g_best:+.1f} dB  LOS {los[idx].any()}")
out = dict(
    n_cells=625, grid='25x25, 40 m, street 1.5 m', freq_ghz=3.6, tilt_deg=4,
    sionna=dict(coverage_ge_minus90_pct=round(float(c_s), 1),
                median_rsrp_dbm=round(float(np.nanmedian(sion_best)), 1),
                no_path_pct=round(float(np.isnan(sion_best).mean() * 100), 1),
                los_any_tx_pct=round(float(los.any(axis=1).mean() * 100), 1),
                ho_region_pct=round(float(ho_frac(rsrp)), 1)),
    gpp=dict(coverage_ge_minus90_pct=round(float(c_g), 1),
             median_rsrp_dbm=round(float(np.nanmedian(g3_best)), 1),
             ho_region_pct=round(float(ho_frac(g3)), 1)),
    diff_median_db=round(float(np.nanmedian(diff)), 1),
    diff_mean_db=round(float(np.nanmean(diff)), 1),
    best_server_agreement_pct=round(float((sion_best_tx_idx == g3_best_tx_idx).mean() * 100), 1),
    shadow_gt15db_pct=round(float(shadow.mean() * 100), 1),
    sionna_above10db_pct=round(float((diff > 10).mean() * 100), 1),
)
json.dump(out, open('comparison.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
