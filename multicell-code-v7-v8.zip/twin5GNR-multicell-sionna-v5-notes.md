# twin5GNR multicell — Sionna version (v5) — build notes, 9 Nov 2026

## What was built
Artefact v5: same handoff/UE behaviour as v4, plus a 3GPP / Sionna toggle.
Live: https://ysrao.github.io/twin5GNR-multicell-3gpp/ (repo ysrao/twin5GNR-multicell-3gpp).

## Ray trace (Sionna 2.2.0, ~/workspace/cbrs-wisp-planner/venv/bin/python)
- Script: `rt_multicell.py` (adapted from ~/workspace/sf-twin/rt_sf.py).
- Scene: Vexcel SF 1 km² mesh, scene_sf/scene.xml, ITU concrete, scattering
  coefficient 0.3 (stated assumption), max depth 3, LOS + specular + diffuse
  + diffraction + edge diffraction, samples_per_src 1,000,000.
- Towers (ENU, origin tile centre 37.801105, −122.404175):
  A (−250, +250), B (+250, +250), C (0, −250); 30 m above local ground
  (stated assumption, as in rt_sf.py). After the artefact's north-up flip
  (grid_x = enu_x + 500, grid_y = 500 − enu_y) these land on the v4 positions
  A(250,250), B(750,250), C(500,750). Spacing 500–559 m (assumption).
  All three towers clear their local roof by 18–29 m (checked from rasters).
- Sectors 90°/210°/330° in ENU (as in the SF single-tower run); TR 38.901
  element gain, 4×4 array (12.04 dB), tilts 0–10°, results at tilt 4°.
  EIRP 47 dBm at boresight (conducted 26.96 dBm + element 8 + array 12.04).
- RX grid: 25×25 at 40 m, street level (ground + 1.5 m); points inside a
  building footprint nudged to the nearest open cell within 30 m (rt_sf rule);
  62.7% of points nudged, 0% still indoor.
- Runtime: 5 chunks, ~121–202 s each, ~13 min total. Output:
  `results_multicell_f3600_street.npz` (625 pts × 3 TX × 6 tilts × 3 sectors).
- RSRP convention: total DL reference power at 47 dBm EIRP (rt_sf.py --post
  convention), NOT per-RE RSRP as in summary_sf.json (which subtracts ~29 dB
  for the resource elements). Same convention as the v4 artefact
  (RSRP = EIRP − path loss), so the two modes are comparable.

## Results (3.6 GHz, street 1.5 m, tilt 4°, 625 cells) — comparison.json
- Sionna (ray-traced/simulated): coverage RSRP ≥ −90 dBm 80.5%, median
  best-server RSRP −72.7 dBm, no-path (no ray to any tower) 10.1%,
  LOS to ≥1 tower 23.7% (per TX 8.2 / 15.4 / 8.0%), HO region (<3 dB,
  sector level) 3.4%.
- 3GPP UMa (v4 formula, LOS-only, no shadowing): coverage 100%, median
  −31.9 dBm, HO region 20.5%. Cross-checked against v4's own JS:
  median −31.8 dBm, 100% — compare.py is faithful to v4.
- Difference (Sionna − 3GPP): median −40.9 dB, mean −38.3 dB; 79.7% of
  cells >15 dB weaker in Sionna; 0% of cells >10 dB stronger in Sionna.
  Best-server agreement 73.6% of cells.
- Reading: the gap is expected — v4's 3GPP side is a simplified LOS-only
  formula with no building shadowing and near-boresight sector gain, while
  Sionna sees the real mesh. The ray-traced map is the honest one for
  street level; the 3GPP map is the planning-sketch upper bound.
- Sanity checks done: LOS-point RSRP vs free-space prediction (gain
  ~0 dBi off-boresight, consistent); per-TX medians vs stored single-tower
  SF run (rsrp_tilt median −79.0 dBm single tower vs −72.7 dBm best-of-3);
  UE table in the artefact matches compare.py cell values exactly.

## Artefact v5 (6g-ran-multicell-handoff-v5.html, 55,672 B)
- Built by build_v5.py from v4 + embedded Sionna grids (25×25×3 TX×3 sectors,
  0.1 dB, null = no ray). Version stamped v5 inside the file.
- 3GPP mode is byte-identical logic to v4 (same defaults, same table).
  Sionna mode: nearest-cell lookup, hatched no-coverage cells, cell
  locations disabled (fixed ray-traced positions), frequency/morphology/MIMO
  selectors apply to 3GPP only (Sionna data are 3.6 GHz), Doppler/ICI use
  3.6 GHz in Sionna mode, UL RSRP derived from grid RSRP.
- Comparison note in the file carries the numbers above, labelled
  ray-traced/simulated, never measured.
- Node smoke test (test_v5.js, DOM stub): both modes render, 6 UE rows each;
  Sionna UE RSRPs −76.9/−66.5/−48.2/−72.8/−83.8/−81.7 dBm, matching
  compare.py. Bug found and fixed in testing: numpy float32 NaN was not
  caught by the None check, so no-path cells embedded as literal NaN and
  produced a NaN UE row (UE5) — fixed by float()/isnan conversion in
  build_v5.py and an isNaN guard in the JS.

## Files in this folder
- rt_multicell.py, probe_shapes.py, compare.py, comparison.json,
  build_v5.py, test_v5.js, results_multicell_f3600_street.npz,
  6g-ran-multicell-handoff-v5.html, twin5GNR-multicell-sionna-v5-notes.md

## Not done / limitations
- Sionna data are 3.6 GHz only; other frequencies stay 3GPP-only.
- 40 m grid (not the 10 m artefact canvas) — Sionna map is nearest-cell
  upsampled; fine structure inside a 40 m cell is not resolved.
- One material (ITU concrete) for the whole mesh; no vegetation, vehicles,
  or indoor loss — stated in the artefact note.
- Live-browser verification: as a subagent I could not drive the real
  browser; verified by curl fetch + Node smoke test. Parent to confirm
  Run re-renders and the toggle switches maps in a real browser.

## Publish status (9 Nov 2026, subagent session)
- NOT YET PUBLISHED. Live page still serves v4 (curl 200, "Version inside
  the file: v4", checked 9 Nov 2026).
- v5 file ready: twin5GNR-multicell-sionna/6g-ran-multicell-handoff-v5.html
  (55,672 B). Publish = replace index.html in ysrao/twin5GNR-multicell-3gpp
  with this file (same as the v4 publish on 2 Nov 2026: GitHub website,
  delete old index.html, upload v5 file, rename to index.html).
- Push blocked in this session, both routes tried and failed:
  (a) SSH: proxy refuses with "Outbound SSH is turned off for this
  assistant. To allow it, ask the user to open Muse settings ->
  Permissions -> Direct network protocols and switch ssh from Deny to Ask."
  (b) Stored custom.github token: gh_api.py GET on the repo returns
  401 "Bad credentials" even with the credential properly attached.
  GitHub MCP is also not connected.
- After publishing, the parent must verify live in a real browser (Run
  re-renders, toggle switches 3GPP/Sionna maps, UE table updates) — the
  subagent could only curl-fetch + Node smoke-test. Hub card needs no
  change (same repo/link).
- Do NOT send the link to anyone; the user forwards it himself.
