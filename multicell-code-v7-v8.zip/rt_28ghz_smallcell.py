#!/usr/bin/env python3
"""rt_28ghz_smallcell.py - 16 small cells at 28 GHz over the Vexcel SF mesh,
for the 6G multi-cell handoff artefact v8 (draft).

Adapted from rt_multicell.py (v5, 3 macro towers at 3.6 GHz). Changes:
  * 16 small cells, 4x4 grid, 250 m spacing, ENU positions
    {-375,-125,125,375}^2, 8 m AGL (lamppost assumption, stated).
  * 28 GHz, EIRP 40 dBm (conducted 19.96 dBm + element 8 dB + array
    12.04 dB, 4x4). Stated assumptions: 3 sectors/cell (90/210/330 deg
    ENU, as in v5, for comparability -- real lamppost cells are often
    omni); 4x4 array (real 28 GHz arrays are often 8x8 -- 4x4 keeps the
    EIRP comparable to the v5 macro run); tilt 4 deg results.
  * RX grid identical to v5: 25x25, 40 m, street 1.5 m, same nudge rule.
  * Scene/materials identical to v5: Vexcel SF L20 mesh, ITU concrete,
    scattering 0.3, max depth 3, LOS + specular + diffuse + diffraction
    + edge diffraction, samples_per_src 250,000, max_num_paths_per_src
    100,000, 50 RX per chunk. (First attempt: 150 RX/chunk, 1M samples,
    1M max paths OOM-killed the 7.7 GB VM on chunk 0, 2026-11-10 ~03:00 UTC;
    re-chunked. LOS/specular are deterministic and unaffected by the
    sample cap; diffuse is slightly noisier. Pilot re-run at the new
    settings before the full run as a sanity check.)
  * RSRP convention identical to v5: total DL reference power at the
    stated EIRP (NOT per-RE RSRP).
Output: results_28ghz_smallcell_street.npz (resumable by chunk).
--pilot: 1 TX (S00) x first 25 RX only, to a separate pilot file.
Provenance: ray-traced / simulated on the Vexcel L20 mesh -- never measured.
Vegetation is NOT in the Sionna scene (as in v5); trees are applied
post-trace with P.833-10 Eq.(1) in compare_28.py (see veg_depth_28.py).
"""
import argparse, json, math, os, sys, time
import numpy as np

ROOT = os.path.dirname(os.path.abspath(__file__))
SF = '/home/hatch/workspace/sf-twin'
SCENE = os.path.join(SF, 'scene_sf')
RAST = np.load(os.path.join(SCENE, 'height_rasters.npz'))
SURF, GROUND = RAST['surf'], RAST['ground']
RX0, RY0, CELL = float(RAST['x0']), float(RAST['y0']), float(RAST['cell'])
GRID_POS = (-375.0, -125.0, 125.0, 375.0)
TOWERS = [(f'S{r}{c}', x, y) for r, y in enumerate(GRID_POS) for c, x in enumerate(GRID_POS)]
TX_AGL_M = 8.0
RX_H = 1.5
STEP = 40.0
CHUNK = 50
SECTORS_DEG = (90.0, 210.0, 330.0)
TILTS = (0.0, 2.0, 4.0, 6.0, 8.0, 10.0)
G_ELEM_MAX_DB = 8.0
G_ARRAY_DB = 10 * np.log10(16)
EIRP_DBM = 40.0
P_COND_DBM = EIRP_DBM - G_ELEM_MAX_DB - G_ARRAY_DB
S_BLD = 0.3
NUDGE_CELLS = 6
FREQ_GHZ = 28.0


def tr38901_gain_db(theta, phi, tilt_deg, az_deg):
    th = theta - np.deg2rad(tilt_deg)
    ph = (phi - np.deg2rad(az_deg) + np.pi) % (2 * np.pi) - np.pi
    th3 = ph3 = np.deg2rad(65.0)
    a_v = -np.minimum(12.0 * ((th - np.pi / 2) / th3) ** 2, 30.0)
    a_h = -np.minimum(12.0 * (ph / ph3) ** 2, 30.0)
    return -np.minimum(-(a_v + a_h), 30.0) + G_ELEM_MAX_DB


def rc_of(x, y):
    c = int(np.clip((x - RX0) / CELL, 0, SURF.shape[1] - 1))
    r = int(np.clip((y - RY0) / CELL, 0, SURF.shape[0] - 1))
    return r, c


def xy_of(r, c):
    return RX0 + (c + 0.5) * CELL, RY0 + (r + 0.5) * CELL


def build_rx_grid():
    xs = np.arange(-480.0, 480.0 + 1, STEP)
    ys = np.arange(-480.0, 480.0 + 1, STEP)
    pts, moved, indoor = [], [], []
    for yy in ys:
        for xx in xs:
            r, c = rc_of(xx, yy)
            inside = (SURF[r, c] - GROUND[r, c]) > 3.0
            indoor.append(inside)
            px, py, mv = float(xx), float(yy), 0
            if inside:
                best = None
                for dr in range(-NUDGE_CELLS, NUDGE_CELLS + 1):
                    for dc in range(-NUDGE_CELLS, NUDGE_CELLS + 1):
                        rr, cc = r + dr, c + dc
                        if 0 <= rr < SURF.shape[0] and 0 <= cc < SURF.shape[1] \
                           and (SURF[rr, cc] - GROUND[rr, cc]) <= 3.0:
                            d = dr * dr + dc * dc
                            if best is None or d < best[0]:
                                best = (d, rr, cc)
                if best is not None:
                    px, py = xy_of(best[1], best[2]); mv = 1
                    r, c = best[1], best[2]
                else:
                    mv = -1
            pts.append((px, py, float(GROUND[r, c] + RX_H)))
            moved.append(mv)
    txs = []
    for name, tx, ty in TOWERS:
        r, c = rc_of(tx, ty)
        txs.append((name, tx, ty, float(GROUND[r, c] + TX_AGL_M)))
    return txs, xs, ys, np.array(pts), np.array(moved), np.array(indoor)


def load_scene(freq_ghz):
    import mitsuba as mi
    mi.set_variant('llvm_ad_mono_polarized')
    import sionna.rt as rt
    from sionna.rt.radio_materials.itu import itu_material
    import drjit as dr
    s = rt.load_scene(os.path.join(SCENE, 'scene.xml'), merge_shapes=True)
    for m in s.radio_materials.values():
        if type(m).__name__ != 'ITURadioMaterial':
            continue
        t = m.itu_type
        m.scattering_coefficient = S_BLD
        if freq_ghz < 1.0 or freq_ghz > 10.0:
            m.frequency_update_callback = (
                lambda f, _t=t: itu_material(_t, dr.minimum(dr.maximum(f, 1e9), 1e12)))
    s.frequency = freq_ghz * 1e9
    iso = rt.PlanarArray(num_rows=1, num_cols=1, pattern='iso', polarization='V')
    s.tx_array = iso; s.rx_array = iso
    return s, rt


def solve_chunk(pts, txs, freq_ghz):
    s, rt = load_scene(freq_ghz)
    for name, tx, ty, tz in txs:
        s.add(rt.Transmitter('tx' + name, position=[tx, ty, tz]))
    for i, (x, y, z) in enumerate(pts):
        s.add(rt.Receiver(f'r{i}', position=[float(x), float(y), float(z)]))
    t0 = time.time()
    p = rt.PathSolver()(s, max_depth=3, los=True, specular_reflection=True,
                        diffuse_reflection=True, refraction=False, diffraction=True,
                        edge_diffraction=True, samples_per_src=250_000,
                        max_num_paths_per_src=100_000)
    dt = time.time() - t0
    ar, ai = (np.asarray(a) for a in p.a)
    v = np.asarray(p.valid).astype(bool)
    pw = np.where(v, (ar[:, 0, :, 0, :] ** 2 + ai[:, 0, :, 0, :] ** 2), 0.0)
    th = np.asarray(p.theta_t)
    ph = np.asarray(p.phi_t)
    inter = np.asarray(p.interactions)
    is_los = (inter == 0).all(axis=0) & v
    los_tx = is_los.any(axis=2)
    n = len(pts)
    dirpw = np.zeros((n, len(txs), len(TILTS), len(SECTORS_DEG)))
    for ti, tilt in enumerate(TILTS):
        for si, az in enumerate(SECTORS_DEG):
            g = np.where(v, 10 ** (tr38901_gain_db(th, ph, tilt, az) / 10), 0.0)
            dirpw[:, :, ti, si] = (pw * g).sum(axis=2)
    iso = pw.sum(axis=2)
    return dict(dirpw=dirpw, iso=iso, los=los_tx,
                los_tx=los_tx, npath=v.sum(axis=2)), dt


def fname(pilot=False):
    return os.path.join(ROOT, 'results_28ghz_smallcell_pilot.npz' if pilot
                        else 'results_28ghz_smallcell_street.npz')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--chunk', type=int)
    ap.add_argument('--post', action='store_true')
    ap.add_argument('--pilot', action='store_true')
    a = ap.parse_args()
    txs_all, xs, ys, pts_all, moved, indoor = build_rx_grid()
    if a.pilot:
        txs, pts = txs_all[:1], pts_all[:25]
        n = len(pts)
        out = fname(pilot=True)
        res, dt = solve_chunk(pts, txs, FREQ_GHZ)
        t4 = TILTS.index(4.0)
        rsrp = np.where(res['dirpw'][:, :, t4, :] > 0,
                        P_COND_DBM + G_ARRAY_DB + 10 * np.log10(np.maximum(res['dirpw'][:, :, t4, :], 1e-30)),
                        np.nan)
        np.savez_compressed(out, dirpw=res['dirpw'], iso=res['iso'], los=res['los_tx'],
                            npath=res['npath'], rsrp_tilt4=rsrp.astype(np.float32),
                            xs=xs, ys=ys, rx_xyz=pts, txs=np.array([(nm, x, y, z) for nm, x, y, z in txs], dtype=object))
        print(f"PILOT 28 GHz small cell: {n} pts x 1 TX in {dt:.0f}s; "
              f"paths/RX median {np.median(res['npath']):.0f}  "
              f"RSRP>=-90 {np.mean(np.nanmax(rsrp, axis=(1, 2)) >= -90)*100:.1f}%  "
              f"median best {np.nanmedian(np.nanmax(rsrp, axis=(1, 2))):.1f} dBm  "
              f"LOS {res['los_tx'][:, 0].mean()*100:.1f}%")
        return
    txs, pts = txs_all, pts_all
    n = len(pts)
    out = fname()
    chunks = [(i, min(i + CHUNK, n)) for i in range(0, n, CHUNK)]
    if a.post:
        d = dict(np.load(out, allow_pickle=True))
        assert len(d['done']) == len(chunks), f"chunks done {sorted(d['done'])} of {len(chunks)}"
        t4 = TILTS.index(4.0)
        rsrp = np.where(d['dirpw'][:, :, t4, :] > 0,
                        P_COND_DBM + G_ARRAY_DB + 10 * np.log10(np.maximum(d['dirpw'][:, :, t4, :], 1e-30)),
                        np.nan)
        d['rsrp_tilt4'] = rsrp.astype(np.float32)
        d['rsrp_best_tx'] = np.nanmax(rsrp, axis=(1, 2)).astype(np.float32)
        best_tx_max = np.nanmax(rsrp, axis=2)
        d['best_tx'] = np.where(np.isnan(best_tx_max).all(axis=1), -1,
                                np.nanargmax(np.where(np.isnan(best_tx_max), -np.inf, best_tx_max),
                                             axis=1)).astype(np.int8)
        d['pl'] = np.where(d['iso'] > 0, -10 * np.log10(np.maximum(d['iso'], 1e-30)), np.nan).astype(np.float32)
        np.savez_compressed(out, **d)
        r = d['rsrp_best_tx']
        print(f"28 GHz small cells street: n={n} no-path {np.isnan(r).mean()*100:.1f}%  "
              f"LOS(any TX) {d['los'].any(axis=1).mean()*100:.1f}%  "
              f"RSRP>=-90 (best TX, tilt 4) {np.mean(r >= -90)*100:.1f}%  median {np.nanmedian(r):.1f} dBm")
        for ti, (name, _, _, _) in enumerate(txs):
            rt_ = rsrp[:, ti, :]
            best = np.nanmax(rt_, axis=1)
            print(f"  TX {name}: best-sector RSRP>=-90 {np.mean(best >= -90)*100:.1f}%  "
                  f"median {np.nanmedian(best):.1f} dBm  LOS {d['los_tx'][:, ti].mean()*100:.1f}%")
        return
    if a.chunk is None or a.chunk >= len(chunks):
        print(f'{len(chunks)} chunks; pass --chunk 0..{len(chunks)-1}; txs={len(txs)}'); return
    i0, i1 = chunks[a.chunk]
    res, dt = solve_chunk(pts[i0:i1], txs, FREQ_GHZ)
    if os.path.exists(out):
        d = dict(np.load(out, allow_pickle=True)); done = set(d['done'].tolist())
    else:
        d = dict(dirpw=np.zeros((n, len(txs), len(TILTS), len(SECTORS_DEG))),
                 iso=np.zeros((n, len(txs))), los=np.zeros((n, len(txs)), bool),
                 los_tx=np.zeros((n, len(txs)), bool), npath=np.zeros((n, len(txs)), np.int32))
        done = set()
    for k, val in res.items():
        d[k][i0:i1] = val
    done.add(a.chunk)
    d.update(xs=xs, ys=ys, rx_xyz=pts, moved=moved, indoor=indoor, tilts=np.array(TILTS),
             sectors=np.array(SECTORS_DEG),
             txs=np.array([(nm, x, y, z) for nm, x, y, z in txs], dtype=object),
             done=np.array(sorted(done)),
             meta=json.dumps(dict(freq_ghz=FREQ_GHZ, rx='street', rx_h_m=RX_H, tx_agl_m=TX_AGL_M,
                                  eirp_dbm=EIRP_DBM, p_cond_dbm=P_COND_DBM, g_array_db=float(G_ARRAY_DB),
                                  s_bld=S_BLD, max_depth=3, samples_per_src=250_000,
                                  max_num_paths_per_src=100_000,
                                  diffuse=True, sectors=SECTORS_DEG, n_tx=len(txs),
                                  tx_grid='4x4, 250 m spacing, 8 m AGL',
                                  scene='Vexcel SF L20 fused mesh, ITU concrete',
                                  version='multicell-v8-28ghz-smallcell')))
    np.savez_compressed(out, **d)
    print(f"28 GHz smallcell chunk {a.chunk}/{len(chunks)-1}: {i1-i0} pts x {len(txs)} TX in {dt:.0f}s; "
          f"paths/RX/TX median {np.median(res['npath']):.0f}")


if __name__ == '__main__':
    main()
