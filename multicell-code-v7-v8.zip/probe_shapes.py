#!/usr/bin/env python3
"""Probe: learn Sionna 2.2.0 PathSolver array shapes for 3 TX x N RX."""
import os, sys, time
import numpy as np
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, '/home/hatch/workspace/sf-twin')
import mitsuba as mi
mi.set_variant('llvm_ad_mono_polarized')
import sionna.rt as rt

s = rt.load_scene('/home/hatch/workspace/sf-twin/scene_sf/scene.xml', merge_shapes=True)
s.frequency = 3.6e9
iso = rt.PlanarArray(num_rows=1, num_cols=1, pattern='iso', polarization='V')
s.tx_array = iso; s.rx_array = iso
for i, (x, y) in enumerate([(-250., 250.), (250., 250.), (0., -250.)]):
    s.add(rt.Transmitter(f'tx{i}', position=[x, y, 60.0]))
for i, (x, y) in enumerate([(0., 0.), (100., 100.), (-100., 0.), (0., -100.)]):
    s.add(rt.Receiver(f'r{i}', position=[x, y, 10.0]))
t0 = time.time()
p = rt.PathSolver()(s, max_depth=3, los=True, specular_reflection=True,
                    diffuse_reflection=True, refraction=False, diffraction=True,
                    edge_diffraction=True, samples_per_src=1_000_000,
                    max_num_paths_per_src=1_000_000)
print('solve s', round(time.time() - t0, 1))
for name, arr in [('a0', p.a[0]), ('a1', p.a[1]), ('valid', p.valid),
                  ('theta_t', p.theta_t), ('phi_t', p.phi_t),
                  ('interactions', p.interactions)]:
    a = np.asarray(arr)
    print(name, a.shape, a.dtype)
print('a0 sample', np.asarray(p.a[0]).flatten()[:4])
print('valid sample', np.asarray(p.valid).reshape(4, 3, -1)[:, :, :3])
