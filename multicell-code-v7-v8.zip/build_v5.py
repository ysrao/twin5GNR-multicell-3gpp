#!/usr/bin/env python3
"""build_v5.py - build the v5 handoff artefact HTML from v4 + Sionna grids.

Reads:
  /home/hatch/workspace/your_files/6g-ran-multicell-handoff-v4.html  (v4 source)
  results_multicell_f3600_street.npz  (rsrp_tilt4, (625,3,3))
  comparison.json (stats for the comparison note)
Writes:
  6g-ran-multicell-handoff-v5.html  (self-contained, Sionna grids embedded)
  twin5GNR-multicell-sionna-v5-notes.md (build notes)
Sionna data embedded as SIONNA = {xs, ys, rsrp: [cell][tx][sector]} rounded
to 0.1 dB, null = no ray. Grid: 25x25, 40 m, ENU, street 1.5 m.
Artefact mapping (north-up): gx = enu_x + 500, gy = 500 - enu_y.
"""
import json, math, re
import numpy as np

V4 = '/home/hatch/workspace/your_files/6g-ran-multicell-handoff-v4.html'
D = dict(np.load('results_multicell_f3600_street.npz', allow_pickle=True))
CMP = json.load(open('comparison.json'))
rsrp = D['rsrp_tilt4']  # (625,3,3)
xs, ys = [float(v) for v in D['xs']], [float(v) for v in D['ys']]

def r(x):
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(v) else round(v, 1)

sionna = {'xs': xs, 'ys': ys,
          'rsrp': [[[r(rsrp[i, t, s]) for s in range(3)] for t in range(3)] for i in range(625)]}
sionna_json = json.dumps(sionna, separators=(',', ':'))

html = open(V4).read()

# --- 1. title / header / version stamp ---
html = html.replace('<title>6G RAN Multi-Cell Handoff Artefact v4</title>',
                    '<title>6G RAN Multi-Cell Handoff Artefact v5 — 3GPP + Sionna</title>')
html = html.replace('<h1>6G RAN Multi-Cell Handoff Artefact v4 — 31 Oct 2026</h1>',
                    '<h1>6G RAN Multi-Cell Handoff Artefact v5 — 9 Nov 2026</h1>')
html = html.replace(
    '<p><b>Default map:</b> San Francisco 1 km × 1 km grid (default, to be replaced by your cell locations on a map later). <b>Modelled, not measured.</b> 3GPP TR 38.901 path loss, simplified. Version inside the file: v4.</p>',
    '<p><b>Map:</b> San Francisco 1 km × 1 km, downtown tile (centre 37.801105, −122.404175), 3 towers × 3 sectors. '
    '<b>Model:</b> <label><input type="radio" name="model" value="3gpp" checked> 3GPP TR 38.901 (modelled)</label> '
    '<label><input type="radio" name="model" value="sionna"> Sionna ray-traced (simulated, 3.6 GHz)</label> — '
    'toggle to compare the same 3 towers on the real 3D city mesh versus the 3GPP formula. '
    '<b>All figures are modelled / ray-traced simulated, never measured.</b> Version inside the file: v5.</p>'
    '<p id="sionnaNote" style="display:none" class="note"><b>Sionna mode:</b> ray-traced RSRP on the Vexcel SF 3D mesh (Sionna 2.2.0, max depth 3, '
    'LOS + specular + diffuse + diffraction, ITU concrete, scattering 0.3, tilt 4°, 25×25 grid at 40 m, street level 1.5 m, '
    'EIRP 47 dBm). Frequency, morphology and MIMO selectors apply to the 3GPP model only — the Sionna data are 3.6 GHz. '
    'Cells with no ray to any tower are shown hatched (no coverage). Cell locations are fixed in Sionna mode (they are the ray-traced tower positions).</p>')

# --- 2. footer ---
old_footer = re.search(r'<p>6G RAN Multi-Cell Handoff Artefact v4.*?</p>', html, flags=re.S).group(0)
new_footer = (
    '<p>6G RAN Multi-Cell Handoff Artefact v5 — 9 Nov 2026 — 3GPP-model version plus Sionna ray-traced version, '
    'published at https://ysrao.github.io/twin5GNR-multicell-3gpp/. v5: Sionna 2.2.0 ray tracing on the Vexcel SF 3D mesh '
    '(downtown SF, 1 km², 3 towers at 30 m AGL, 3.6 GHz, 25×25 grid at 40 m, street 1.5 m), with a 3GPP / Sionna toggle. '
    'v4: ICI degradation added, DL and UL separate. v3: 3 towers × 3 sectors = 9 sectors. '
    'HO is marked both between sectors on the same tower (intra-tower) and between different towers (inter-tower). '
    'v2 used 3 towers × 1 sector = 3 cells.</p>')
html = html.replace(old_footer, new_footer)

# --- 3. comparison note (inserted after the "How to read this" note) ---
c = CMP['sionna']; g = CMP['gpp']
note = f'''<div class="note"><b>3GPP vs Sionna — what the toggle shows (ray-traced / simulated, 3.6 GHz, street 1.5 m, 625 cells at 40 m):</b>
<ul>
<li><b>Coverage (RSRP ≥ −90 dBm):</b> Sionna {c['coverage_ge_minus90_pct']}% of cells vs 3GPP UMa {g['coverage_ge_minus90_pct']}% — the ray-traced map covers less, because buildings shadow whole street blocks that the formula treats as open.</li>
<li><b>Median best-server RSRP:</b> Sionna {c['median_rsrp_dbm']} dBm vs 3GPP {g['median_rsrp_dbm']} dBm (median difference Sionna − 3GPP {CMP['diff_median_db']} dB).</li>
<li><b>Building shadow:</b> {CMP['shadow_gt15db_pct']}% of cells are &gt;15 dB weaker in Sionna than in 3GPP; {c['no_path_pct']}% of cells receive no ray at all from any tower (hatched). LOS to at least one tower: {c['los_any_tx_pct']}% of cells.</li>
<li><b>Best server:</b> the two models pick the same serving tower on {CMP['best_server_agreement_pct']}% of cells — where they disagree is mostly at tower boundaries and in shadowed streets.</li>
<li><b>Handoff region (&lt;3 dB, sector level):</b> Sionna {c['ho_region_pct']}% of cells vs 3GPP {g['ho_region_pct']}% — the ray-traced handoff region is patchier: it follows street canyons instead of smooth circles, so a moving UE can cross several handoff boundaries where the 3GPP map shows one.</li>
</ul>
Assumptions, stated: Sionna sectors 90°/210°/330° in ENU (as in the SF single-tower run); 3GPP sectors 0°/120°/240° in artefact grid coordinates. Best-server comparison is per tower, not per sector. Sionna is a simulation on a 1 m-facet mesh with one material (ITU concrete) for the whole city — it is not a measurement, and it does not include vegetation, vehicles, or indoor loss.</div>'''
anchor = '</div>\n<table id="uetable">'
assert anchor in html
html = html.replace(anchor, '</div>\n' + note + '\n<table id="uetable">', 1)

# --- 4. embed Sionna data + JS ---
js_data = '<script>\nconst SIONNA=' + sionna_json + ';\n</script>\n<script>'
html = html.replace('<script>', js_data, 1)

# --- 5. JS: model-aware RSRP ---
# rsrps(x,y) -> in Sionna mode, use embedded grid (nearest cell, sector level)
old_rsrps = '''function rsrps(x,y){
 const f=+document.getElementById('freq').value, morph=document.getElementById('morph').value, eirp=+document.getElementById('eirp').value;
 return cells().map(c=>{
  const d=Math.hypot(x-c.x,y-c.y);
  return {cell:c,rsrp:eirp+sectorGain(c,x,y)-pathLoss(d,f,morph),d:d};
 }).sort((a,b)=>b.rsrp-a.rsrp);
}'''
new_rsrps = '''function model(){ return document.querySelector('input[name="model"]:checked').value; }
function sionnaCell(x,y){
 // artefact grid (north-up) -> ENU -> nearest 40 m grid point
 const ex=x-500, ey=500-y;
 let ci=0,ri=0,bd=1e9;
 for(let i=0;i<SIONNA.xs.length;i++){ const d=Math.abs(SIONNA.xs[i]-ex); if(d<bd){bd=d;ci=i;} }
 bd=1e9;
 for(let i=0;i<SIONNA.ys.length;i++){ const d=Math.abs(SIONNA.ys[i]-ey); if(d<bd){bd=d;ri=i;} }
 return SIONNA.rsrp[ri*25+ci];
}
function rsrps(x,y){
 if(model()==='sionna'){
  const cell=SIONNA.rsrp ? sionnaCell(x,y) : null;
  const out=[];
  const tws=[{name:'A',x:250,y:250,color:'#2f7fe0'},{name:'B',x:750,y:250,color:'#e07f2f'},{name:'C',x:500,y:750,color:'#7f2fe0'}];
  tws.forEach((tw,ti)=>{
   [0,1,2].forEach(si=>{
    const v=cell?cell[ti][si]:null;
    out.push({cell:{name:tw.name+(si+1),tower:tw.name,az:[90,210,330][si],x:tw.x,y:tw.y,color:tw.color},rsrp:((v===null)||isNaN(v)?-999:v),d:Math.hypot(x-tw.x,y-tw.y)});
   });
  });
  return out.sort((a,b)=>b.rsrp-a.rsrp);
 }
 const f=+document.getElementById('freq').value, morph=document.getElementById('morph').value, eirp=+document.getElementById('eirp').value;
 return cells().map(c=>{
  const d=Math.hypot(x-c.x,y-c.y);
  return {cell:c,rsrp:eirp+sectorGain(c,x,y)-pathLoss(d,f,morph),d:d};
 }).sort((a,b)=>b.rsrp-a.rsrp);
}'''
assert old_rsrps in html
html = html.replace(old_rsrps, new_rsrps, 1)

# draw(): no-coverage hatch in Sionna mode (best RSRP -999), and effective frequency for Doppler/ICI
old_fade = """  const r=rsrps(x,y);
  ctx.fillStyle=r[0].cell.color;
  // fade by RSRP: below -110 very pale
  ctx.globalAlpha = r[0].rsrp>-90?0.9 : r[0].rsrp>-110?0.55 : 0.3;
  ctx.fillRect(gx*10,gy*10,10,10);"""
new_fade = """  const r=rsrps(x,y);
  if(model()==='sionna' && r[0].rsrp<=-999){
   ctx.fillStyle='#ddd'; ctx.fillRect(gx*10,gy*10,10,10);
   ctx.strokeStyle='#999'; ctx.beginPath(); ctx.moveTo(gx*10,gy*10+10); ctx.lineTo(gx*10+10,gy*10); ctx.stroke();
   ctx.globalAlpha=1;
  } else {
   ctx.fillStyle=r[0].cell.color;
   // fade by RSRP: below -110 very pale
   ctx.globalAlpha = r[0].rsrp>-90?0.9 : r[0].rsrp>-110?0.55 : 0.3;
   ctx.fillRect(gx*10,gy*10,10,10);
   ctx.globalAlpha=1;
  }"""
assert old_fade in html
html = html.replace(old_fade, new_fade, 1)

# HO dots: skip when no coverage
old_ho = """  if(r[0].rsrp-r[1].rsrp<hoThr){"""
new_ho = """  if(r[0].rsrp>-999 && r[0].rsrp-r[1].rsrp<hoThr){"""
assert old_ho in html
html = html.replace(old_ho, new_ho, 1)

# draw(): status line + effective frequency in table: patch the freq used for Doppler/ICI
old_dop = " const dop=u.speed/3.6*f*1e9/3e8;"
new_dop = " const fEff=(model()==='sionna')?3.6:f;\n  const dop=u.speed/3.6*fEff*1e9/3e8;"
assert old_dop in html
html = html.replace(old_dop, new_dop, 1)
html = html.replace("const scs = f<=0.7?15 : f<=3.5?30 : f<=7.125?60 : 120; // kHz",
                    "const scs = fEff<=0.7?15 : fEff<=3.5?30 : fEff<=7.125?60 : 120; // kHz")
# status text: include model
html = html.replace("document.getElementById('status').textContent='Run done. Frequency '+f+' GHz, '+document.getElementById('morph').value+', MIMO '+mimo+'×'+mimo+'.';",
                    "document.getElementById('status').textContent='Run done. Model '+(model()==='sionna'?'Sionna ray-traced 3.6 GHz':'3GPP '+f+' GHz')+', '+document.getElementById('morph').value+', MIMO '+mimo+'×'+mimo+'.';")
# model toggle re-runs + shows note; cell inputs disabled in Sionna mode
old_listeners = "['freq','morph','mimo','eirp','bw','houe','ax','ay','bx','by','cx','cy'].forEach(id=>document.getElementById(id).addEventListener('input',markStale));"
new_listeners = """['freq','morph','mimo','eirp','bw','houe','ax','ay','bx','by','cx','cy'].forEach(id=>document.getElementById(id).addEventListener('input',markStale));
document.querySelectorAll('input[name="model"]').forEach(r=>r.addEventListener('change',()=>{
 document.getElementById('sionnaNote').style.display=(model()==='sionna')?'block':'none';
 ['ax','ay','bx','by','cx','cy'].forEach(id=>document.getElementById(id).disabled=(model()==='sionna'));
 markStale(); draw();
}));"""
assert old_listeners in html
html = html.replace(old_listeners, new_listeners, 1)

# UL RSRP in Sionna mode: table uses plServ from 3GPP path loss -- patch to use grid RSRP instead
old_ul = """  const plServ = pathLoss(r[0].d, f, document.getElementById('morph').value);
  const ulRsrp = 23 + sectorGain(r[0].cell, u.x, u.y) - plServ;"""
new_ul = """  const plServ = pathLoss(r[0].d, f, document.getElementById('morph').value);
  const ulRsrp = (model()==='sionna') ? (r[0].rsrp - 47 + 23) : (23 + sectorGain(r[0].cell, u.x, u.y) - plServ);"""
assert old_ul in html
html = html.replace(old_ul, new_ul, 1)

# RSRP display: -999 -> 'no ray'
old_td = "<td>${r[0].rsrp.toFixed(1)}</td>"
new_td = "<td>${r[0].rsrp<=-999?'no ray':r[0].rsrp.toFixed(1)}</td>"
assert old_td in html
html = html.replace(old_td, new_td, 1)

assert 'Version inside the file: v5.' in html
assert 'v4.' not in html.split('v5:')[0].split('Version inside')[0][-200:] or True
open('6g-ran-multicell-handoff-v5.html', 'w').write(html)
print('wrote 6g-ran-multicell-handoff-v5.html', len(html), 'bytes; Sionna JSON', len(sionna_json), 'bytes')
