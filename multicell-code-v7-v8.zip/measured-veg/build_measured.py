#!/usr/bin/env python3
"""Measured-vegetation layer (Mubanga 4-step proposal, 2026-11-10).

Step 1 (measured crowns): NAIP 2022 4-band 0.6 m aerial imagery (Microsoft
Planetary Computer, tile ca_m_3712213_se_10_060_20220518) over the 1 km SF
tile. NDVI = (NIR-R)/(NIR+R); NDVI gate tuned per tile (see NDVI stats
below). SAM 3 via samgeo was NOT usable here: PyPI has no samgeo in this
VM's index and SAM-class ViT encoders need GPU / multi-GB weights on a
4-CPU, 6 GB VM. Measured footprints here are NDVI segmentation seeded at
the 1,919 surveyed tree coordinates, with the DBH rule as fallback for
trees with no measured footprint (few pixels / no NDVI signal).
Step 2 (LiDAR in footprints only): 3DEP LiDAR CHM (OSM-masked, 2 m) sampled
ONLY inside the NDVI footprints, giving crown-top heights without the
clutter/unmapped-building counts that made the raw CHM overstate depth ~10x.
Step 3 (common geometry): the same measured crown volumes (NDVI footprint +
LiDAR crown top + stated crown base) feed BOTH the P.833 depth and the
solid-crown geometry meshes, so the gap between bounds is method, not
spatial assumptions.
Step 4 (crown base height, CBH): crown base parameterised; sensitivity over
CBH = 3 m clearance, CBH = 0.35 x tree height, and the old assumed base
(2-3 m). Rays pass through open trunk space below CBH.
P.833 (gamma,Am) = (0.55,38) at 3.6 GHz and (2.20,50) at 28 GHz remain
INTERPOLATED/ASSUMED, uncalibrated — flagged, not hidden.
"""
import json, math
import numpy as np
from scipy import ndimage

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
MEAS = ROOT + '/measured-veg'
LID = '/home/hatch/workspace/twin5gnr-work/sf-3dep-lidar-try'
LAT0, LON0 = 37.801105, -122.404175
R = 6378137.0
COS = math.cos(math.radians(LAT0))
CX0 = R * math.radians(LON0)
CY0 = R * math.log(math.tan(math.pi / 4 + math.radians(LAT0) / 2))
CELL, N = 2.0, 500


def merc_enu(lat, lon):
    return ((R * math.radians(lon) - CX0) * COS,
            (R * math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) - CY0) * COS)


def main():
    # --- NAIP tile: NDVI on the 0.6 m grid, then aggregate to the 2 m ENU grid ---
    d = np.load(f'{MEAS}/naip_2022_tile.npz')
    arr = d['arr'].astype(np.float32)  # R,G,B,NIR
    utm = d['utm_bounds']
    H, W = arr.shape[1], arr.shape[2]
    nir, red = arr[3], arr[0]
    ndvi = (nir - red) / np.maximum(nir + red, 1.0)
    print(f'NAIP {arr.shape} NDVI: mean {ndvi.mean():.3f} p50 {np.median(ndvi):.3f} '
          f'p90 {np.percentile(ndvi,90):.3f} p99 {np.percentile(ndvi,99):.3f}')
    # pixel centres in UTM -> lon/lat -> ENU (vectorised, Mercator inverse)
    eu = utm[0] + (np.arange(W) + 0.5) * 0.6
    nu = utm[3] - (np.arange(H) + 0.5) * 0.6
    E, Nu = np.meshgrid(eu, nu)
    # UTM zone 10N -> lon/lat (approx, spherical): use pyproj-free iterative mercator
    # UTM: lon = lon0_utm + E'/ (k0*a*cos(lat)) ... use rasterio transform instead:
    # simpler: convert via Web-Mercator from UTM using standard formulae
    import math as _m
    k0, a, e2 = 0.9996, 6378137.0, 0.00669438
    x_ = E - 500000.0
    y_ = Nu
    M = y_ / k0
    mu = M / (a * (1 - e2 / 4 - 3 * e2**2 / 64 - 5 * e2**3 / 256))
    e1 = (1 - _m.sqrt(1 - e2)) / (1 + _m.sqrt(1 - e2))
    J1 = 3 * e1 / 2 - 27 * e1**3 / 32
    J2 = 21 * e1**2 / 16 - 55 * e1**4 / 32
    J3 = 151 * e1**3 / 96
    J4 = 1097 * e1**4 / 512
    fp = mu + J1 * np.sin(2 * mu) + J2 * np.sin(4 * mu) + J3 * np.sin(6 * mu) + J4 * np.sin(8 * mu)
    C1 = e2 * np.cos(fp) ** 2
    T1 = np.tan(fp) ** 2
    N1 = a / np.sqrt(1 - e2 * np.sin(fp) ** 2)
    R1 = a * (1 - e2) / (1 - e2 * np.sin(fp) ** 2) ** 1.5
    D = x_ / (N1 * k0)
    lat = fp - (N1 * np.tan(fp) / R1) * (D**2 / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1**2 - 9 * e2) * D**4 / 24)
    lon = np.radians(-123.0) + (D - (1 + 2 * T1 + C1) * D**3 / 6) / np.cos(fp)
    lat = np.degrees(lat); lon = np.degrees(lon)
    ex = (R * np.radians(lon) - CX0) * COS
    ey = (R * np.log(np.tan(np.pi / 4 + np.radians(lat) / 2)) - CY0) * COS
    print(f'ENU range x {ex.min():.0f}..{ex.max():.0f} y {ey.min():.0f}..{ey.max():.0f} '
          f'(tile should be about -500..500)')
    ix = ((ex + 500) // CELL).astype(int)
    iy = ((ey + 500) // CELL).astype(int)
    ok = (ix >= 0) & (ix < N) & (iy >= 0) & (iy < N)
    # per 2 m cell: max NDVI and fraction of pixels above each threshold
    npix = np.zeros((N, N), dtype=np.int32)
    np.add.at(npix, (iy[ok], ix[ok]), 1)
    maxnd = np.full((N, N), -1.0, dtype=np.float32)
    np.maximum.at(maxnd, (iy[ok], ix[ok]), ndvi[ok].astype(np.float32))
    print(f'2 m cells covered by NAIP: {(npix>0).mean()*100:.1f}%  mean pixels/cell {npix[npix>0].mean():.1f}')
    np.savez_compressed(f'{MEAS}/naip_2m.npz', maxndvi=maxnd, npix=npix,
                        ndvi_mean=np.array([ndvi.mean()]))
    # --- NDVI threshold tuning: NDVI at surveyed tree points vs elsewhere ---
    trees = json.load(open('/home/hatch/workspace/twin5gnr-work/twin5GNR-SF-veg-surveyed/sf_trees_tile.json'))
    tx, ty = [], []
    for tt in trees:
        try:
            a, b = merc_enu(float(tt['latitude']), float(tt['longitude']))
        except (KeyError, TypeError, ValueError):
            continue
        tx.append(a); ty.append(b)
    tx, ty = np.array(tx), np.array(ty)
    cx = ((tx + 500) // CELL).astype(int); cy = ((ty + 500) // CELL).astype(int)
    tree_nd = maxnd[cy, cx]
    print('NDVI (max in 2 m cell) at surveyed tree points: '
          f'median {np.median(tree_nd):.3f} p10 {np.percentile(tree_nd,10):.3f} '
          f'p25 {np.percentile(tree_nd,25):.3f} frac>0.2 {(tree_nd>0.2).mean()*100:.1f}% '
          f'>0.3 {(tree_nd>0.3).mean()*100:.1f}% >0.4 {(tree_nd>0.4).mean()*100:.1f}%')
    print(f'NDVI max over all cells: frac>0.2 {(maxnd>0.2).mean()*100:.1f}% >0.3 {(maxnd>0.3).mean()*100:.1f}% '
          f'>0.4 {(maxnd>0.4).mean()*100:.1f}%')

    # --- measured footprints: NDVI gate + OSM-masked LiDAR CHM >= 2 m + not building ---
    V = dict(np.load(f'{ROOT}/veg_layer_40m.npz', allow_pickle=True))
    chm, bld = V['chm'], V['bld_mask']
    for thr in (0.2, 0.25, 0.3, 0.35):
        fp_mask = (maxnd > thr) & (chm >= 2.0) & (~bld)
        # trees with any footprint cell within 6 m
        hit = np.zeros(len(tx), dtype=bool)
        for k in range(len(tx)):
            lo_x, hi_x = max(0, cx[k]-3), min(N, cx[k]+4)
            lo_y, hi_y = max(0, cy[k]-3), min(N, cy[k]+4)
            hit[k] = fp_mask[lo_y:hi_y, lo_x:hi_x].any()
        print(f'thr {thr}: footprint cells {(fp_mask).mean()*100:.2f}% of tile; '
              f'trees with footprint within 6 m: {hit.mean()*100:.1f}% ({hit.sum()}/{len(tx)})')
    THR = 0.15  # tuned per tile: 0.3 unusable here (DN NDVI max ~0.27 across tile; tree-point median 0.168)
    fp_mask = (maxnd > THR) & (chm >= 2.0) & (~bld)
    np.savez_compressed(f'{MEAS}/footprint_2m.npz', footprint=fp_mask, chm=chm, bld_mask=bld, thr=THR)
    print(f'chosen NDVI gate {THR}: footprint {(fp_mask).mean()*100:.2f}% of tile cells')

    # --- per-tree measured crowns: footprint cells assigned to their NEAREST
    # surveyed tree (within 8 m). Connected components merge whole street rows,
    # so they are NOT used for per-tree area (they overstated radius ~1.8x).
    # This partitions the footprint: each cell belongs to at most one tree. ---
    def crown_for(tt):
        try:
            v = float(tt.get('mapdbh'))
        except (TypeError, ValueError):
            v = None
        if v is None:
            r = {'1': 2.0, '2': 3.0, '3': 4.0, '4': 5.0}.get(str(tt.get('dbhrange')), 3.0)
            z = {'1': (3.0, 6.0), '2': (2.0, 8.0), '3': (2.0, 10.0), '4': (2.0, 12.0)}.get(
                str(tt.get('dbhrange')), (2.0, 8.0))
            return r, z[0], z[1]
        if v <= 10: return 2.0, 3.0, 6.0
        if v <= 20: return 3.0, 2.0, 8.0
        if v < 40: return 4.0, 2.0, 10.0
        return 5.0, 2.0, 12.0
    G = np.load('/home/hatch/workspace/sf-twin/scene_sf/height_rasters.npz')
    ground, gx0, gy0, gcell = G['ground'], float(G['x0']), float(G['y0']), float(G['cell'])
    def ground_at(x, y):
        ci = int(np.clip((x - gx0) // gcell, 0, ground.shape[1]-1))
        ri = int(np.clip((y - gy0) // gcell, 0, ground.shape[0]-1))
        return float(ground[ri, ci])
    from scipy.spatial import cKDTree
    tree_xy = np.column_stack([tx, ty])
    kd = cKDTree(tree_xy)
    fy, fx = np.where(fp_mask)
    fpts = np.column_stack([fx * CELL - 500 + CELL / 2, fy * CELL - 500 + CELL / 2])
    dist, nearest = kd.query(fpts, k=1)
    keep = dist <= 8.0
    cell_tree = np.full((N, N), -1, dtype=np.int32)
    cell_tree[fy[keep], fx[keep]] = nearest[keep]
    top_grid = np.zeros((N, N), dtype=np.float32)
    top_grid[fy[keep], fx[keep]] = chm[fy[keep], fx[keep]]
    rows = []
    n_fallback = 0
    for k, tt in enumerate(trees):
        try:
            x, y = merc_enu(float(tt['latitude']), float(tt['longitude']))
        except (KeyError, TypeError, ValueError):
            continue
        r_old, z0_old, z1_old = crown_for(tt)
        cells = (cell_tree == k)
        area = float(cells.sum()) * CELL * CELL
        if area < 4.0:  # fewer than one 2 m cell: no measured footprint
            n_fallback += 1
            rows.append(dict(treeid=tt.get('treeid'), x=float(x), y=float(y),
                             r_old=r_old, z0_old=z0_old, z1_old=z1_old,
                             r_meas=None, area_m2=None, top_m=None, fallback=True))
            continue
        top = float(top_grid[cells].max())
        r_meas = float(math.sqrt(area / math.pi))
        rows.append(dict(treeid=tt.get('treeid'), x=float(x), y=float(y),
                         r_old=r_old, z0_old=z0_old, z1_old=z1_old,
                         r_meas=r_meas, area_m2=area, top_m=top, fallback=False,
                         ground_m=ground_at(x, y)))
    meas = [r for r in rows if not r['fallback']]
    r_meas = np.array([r['r_meas'] for r in meas])
    tops = np.array([r['top_m'] for r in meas])
    areas = np.array([r['area_m2'] for r in meas])
    print(f'measured crowns: {len(meas)}/{len(rows)} trees ({len(meas)/len(rows)*100:.1f}%), '
          f'fallback to DBH: {n_fallback} ({n_fallback/len(rows)*100:.1f}%)')
    print(f'crown radius measured: median {np.median(r_meas):.2f} m mean {r_meas.mean():.2f} m '
          f'p10 {np.percentile(r_meas,10):.2f} p90 {np.percentile(r_meas,90):.2f} max {r_meas.max():.2f}')
    print(f'crown area: median {np.median(areas):.1f} m2 mean {areas.mean():.1f} m2')
    print(f'crown top (LiDAR CHM in footprint): median {np.median(tops):.1f} m mean {tops.mean():.1f} m '
          f'p10 {np.percentile(tops,10):.1f} p90 {np.percentile(tops,90):.1f} max {tops.max():.1f}')
    r_old = np.array([r['r_old'] for r in rows])
    print(f'old DBH radius: median {np.median(r_old):.2f} m mean {r_old.mean():.2f} m')
    print(f'radius measured vs DBH: median ratio {np.median(r_meas/np.array([r["r_old"] for r in meas])):.2f}')
    json.dump(rows, open(f'{MEAS}/measured_trees.json', 'w'), indent=1)
    print('wrote measured_trees.json')
    # per-cell top / CBH grids for the depth computation (reuse cell_tree/top_grid
    # from the nearest-tree assignment above; fallback trees get their DBH disc)
    for idx, r in enumerate(rows):
        if not r['fallback']:
            continue
        kx, ky = int(round((r['x'] + 500) // CELL)), int(round((r['y'] + 500) // CELL))
        rr = int(math.ceil(r['r_old'] / CELL))
        for dy in range(-rr, rr+1):
            for dx in range(-rr, rr+1):
                if dx*dx+dy*dy > (r['r_old']/CELL)**2:
                    continue
                jx, jy = kx+dx, ky+dy
                if 0 <= jx < N and 0 <= jy < N and cell_tree[jy, jx] < 0:
                    cell_tree[jy, jx] = idx
                    top_grid[jy, jx] = r['z1_old']
    np.savez_compressed(f'{MEAS}/measured_grids.npz', footprint=fp_mask, top=top_grid,
                        cell_tree=cell_tree, chm=chm, bld_mask=bld,
                        measured=json.dumps(rows))
    print(f'cells with a tree assigned: {(cell_tree>=0).mean()*100:.2f}% of tile')


if __name__ == '__main__':
    main()
