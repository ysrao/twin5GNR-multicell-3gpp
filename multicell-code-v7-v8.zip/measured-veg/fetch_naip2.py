import numpy as np, rasterio, math
from rasterio.windows import from_bounds
from rasterio.warp import transform_bounds
URL="naip_2022_full.tif"
lon0, lat0 = -122.404175, 37.801105
dlat = 500/110574.0; dlon = 500/(111320.0*np.cos(np.radians(lat0)))
w, s, e, n = lon0-dlon, lat0-dlat, lon0+dlon, lat0+dlat
with rasterio.open(URL) as src:
    print('crs', src.crs, 'res', src.res, 'count', src.count)
    wb, sb, eb, nb = transform_bounds('EPSG:4326', src.crs, w, s, e, n)
    print('utm bounds', wb, sb, eb, nb)
    win = from_bounds(wb, sb, eb, nb, src.transform)
    print('window', win)
    arr = src.read(window=win)
    print('arr', arr.shape, arr.dtype)
    np.savez_compressed('naip_2022_tile.npz', arr=arr, transform=np.array(src.window_transform(win)),
                        crs=str(src.crs), utm_bounds=np.array([wb,sb,eb,nb]))
    print('saved')
