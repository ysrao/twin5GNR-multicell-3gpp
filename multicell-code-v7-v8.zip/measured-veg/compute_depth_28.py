#!/usr/bin/env python3
"""P.833 at 28 GHz on measured crowns, v8 small-cell baseline (16 cells, 8 m AGL).
Line height 8 m -> 1.5 m. (gamma,Am)=(2.20,50) INTERPOLATED/ASSUMED.
phi=1 LOS / 0 non-LOS, as in v7."""
import json, math
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
MEAS = ROOT + '/measured-veg'
CELL, N = 2.0, 500
STEP_M = 5.0


def main():
    G = dict(np.load(f'{MEAS}/measured_grids.npz', allow_pickle=True))
    top = G['top'].astype(float)
    ctree = G['cell_tree']
    rows = json.loads(str(G['measured']))
    D = dict(np.load(f'{ROOT}/results_28ghz_smallcell_street.npz', allow_pickle=True))
    pts, los, rsrp = D['rx_xyz'], D['los_tx'], D['rsrp_tilt4']
    txs = D['txs']
    print('txs', txs.shape, txs[0])
    # TX positions: check format
    tx_xy = []
    for t in txs:
        # txs rows: (name, x, y, z) or similar — print first
        tx_xy.append((float(t[1]), float(t[2])))
    z0 = np.array([r['z0_old'] for r in rows])
    cbh = {
        'A_3m': np.where(ctree >= 0, 3.0, np.nan),
        'B_0.35H': np.where(ctree >= 0, 0.35 * top, np.nan),
        'C_oldbase': np.where(ctree >= 0, z0[np.maximum(ctree, 0)], np.nan),
    }
    # old surveyed depth at 28 GHz (from veg_depth_28ghz.npz if present)
    try:
        V28 = dict(np.load(f'{ROOT}/veg_depth_28ghz.npz', allow_pickle=True))
        print('veg_depth_28 keys', list(V28.keys()))
    except Exception as e:
        V28 = None
        print('no veg_depth_28ghz:', e)
    for var, cb in cbh.items():
        depth = np.zeros((625, 16), dtype=np.float32)
        for ti, (tx_, ty_) in enumerate(tx_xy):
            for i in range(625):
                rx, ry = pts[i, 0], pts[i, 1]
                L = math.hypot(rx - tx_, ry - ty_)
                n = max(2, int(L / STEP_M))
                tt = (np.arange(n) + 0.5) / n
                px = tx_ + (rx - tx_) * tt
                py = ty_ + (ry - ty_) * tt
                lh = 8.0 + (1.5 - 8.0) * tt
                cx = ((px + 500) // CELL).astype(int)
                cy = ((py + 500) // CELL).astype(int)
                okc = (cx >= 0) & (cx < N) & (cy >= 0) & (cy < N)
                hit = np.zeros(n, dtype=bool)
                hit[okc] = (ctree[cy[okc], cx[okc]] >= 0) & \
                           (lh[okc] >= cb[cy[okc], cx[okc]]) & \
                           (lh[okc] <= top[cy[okc], cx[okc]])
                depth[i, ti] = hit.sum() * (L / n)
        gamma, am = 2.20, 50.0
        a = np.where(depth > 0, am * (1 - np.exp(-depth * gamma / am)), 0.0)
        phi = np.where(los, 1.0, 0.0)
        adj = np.where(a > 0, 10 * np.log10(1 - phi + phi * 10 ** (-a / 10)), 0.0)
        rv = np.where(np.isnan(rsrp), np.nan, (rsrp + adj[:, :, None]).astype(np.float32))
        best = np.nanmax(np.nanmax(rv, axis=2), axis=1)
        base = np.nanmax(np.nanmax(rsrp, axis=2), axis=1)
        dlt = best - base
        print(f"28 GHz P.833 {var}: depth mean {depth.mean():.2f} m pairs>0 {(depth>0).mean()*100:.1f}% | "
              f"A_ev mean {a.mean():.2f} dB | cov {np.mean(best>=-90)*100:.1f}% "
              f"median {np.nanmedian(best):.1f} dBm | delta median {np.nanmedian(dlt):+.2f} "
              f"mean {np.nanmean(dlt):+.2f} cells<-1dB {np.mean(dlt<-1)*100:.1f}% "
              f"worst {np.nanmin(dlt):.1f} dB")
        np.savez_compressed(f'{MEAS}/p833_28ghz_measured_{var}.npz', depth=depth, a_ev=a,
                            veg_adj=adj, rsrp_veg=rv)
    # old v8 veg numbers for comparison (from results_28ghz_veg.npz)
    try:
        V8 = dict(np.load(f'{ROOT}/results_28ghz_veg.npz', allow_pickle=True))
        print('v8 veg keys', list(V8.keys()))
        if 'rsrp_veg_tilt4' in V8:
            rv = V8['rsrp_veg_tilt4']
            best = np.nanmax(np.nanmax(rv, axis=2), axis=1)
            base = np.nanmax(np.nanmax(rsrp, axis=2), axis=1)
            dlt = best - base
            print(f"28 GHz P.833 OLD surveyed: cov {np.mean(best>=-90)*100:.1f}% "
                  f"median {np.nanmedian(best):.1f} | delta median {np.nanmedian(dlt):+.2f} "
                  f"mean {np.nanmean(dlt):+.2f} cells<-1dB {np.mean(dlt<-1)*100:.1f}% "
                  f"worst {np.nanmin(dlt):.1f} dB")
    except Exception as e:
        print('v8 veg compare failed:', e)


if __name__ == '__main__':
    main()
