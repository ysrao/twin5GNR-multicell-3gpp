#!/bin/bash
cd "$(dirname "$0")"
PY=/home/hatch/workspace/cbrs-wisp-planner/venv/bin/python
for spec in "3.6 B" "28.0 B" "3.6 A"; do
  set -- $spec; freq=$1; var=$2
  for c in 0 1 2 3 4; do
    $PY rt_measured_veg.py --freq $freq --variant $var --chunk $c || echo "FAILED freq=$freq var=$var chunk=$c"
  done
  $PY rt_measured_veg.py --freq $freq --variant $var --post || echo "POST FAILED freq=$freq var=$var"
done
echo "ALL DONE"
