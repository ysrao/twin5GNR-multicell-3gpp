# Measured vegetation — Mubanga's 4-step proposal, implemented 10 Nov 2026

All figures ray-traced / simulated / modelled, never measured.
Tower A only for the solid-crown runs; 3-tower for the P.833 runs.
Nothing published, nothing sent, no v5–v8 file touched.

## Verdict first: the gap did NOT narrow — it stayed the same at 3.6 GHz and widened at 28 GHz

The measured crowns are **taller and wider** than the assumed DBH discs, so
*both* bounds moved up in loss. The gap that remains is now mostly **method**
(LOS-only P.833 vs all-paths solid crown), not spatial assumptions — which is
what step 3 was meant to isolate, just not in the direction hoped for.

| Tower A, paired vs no-veg | P.833 lower bound (mean) | Solid-crown upper bound (mean) | Gap |
|---|---|---|---|
| 3.6 GHz, OLD (DBH discs) | −0.10 dB, 2.8% cells >1 dB | −1.26 dB, 19.8% >1 dB | **1.16 dB** |
| 3.6 GHz, MEASURED (CBH B, 0.35H) | −0.22 dB, 3.2% >1 dB | −1.30 dB, 26.6% >1 dB | **1.08 dB** |
| 3.6 GHz, MEASURED (CBH A, 3 m) | −0.24 dB, 3.2% >1 dB | −1.43 dB, 28.5% >1 dB | **1.19 dB** |
| 28 GHz, OLD (DBH discs) | −0.37 dB, 2.8% >1 dB | −1.06 dB, 17.1% >1 dB | **0.69 dB** |
| 28 GHz, MEASURED (CBH B) | −0.78 dB, 3.2% >1 dB | −1.99 dB, 26.4% >1 dB | **1.21 dB** |

Worst cell: 3.6 GHz old −28.9 dB → measured B −38.2 dB; 28 GHz old −30.9 dB →
measured B −40.7 dB. Cells losing their path entirely: old 4 / 13 (3.6 / 28 GHz)
→ measured B 15 / 12. Median delta is still ~0.00 dB in both methods at both
bands — the change is entirely in the tail, as before.

## Step 1 — measured crown boundaries (SAM 3 NOT run; NDVI fallback used)

- **SAM 3 / samgeo could not run here.** PyPI in this VM has no `samgeo`
  (`pip install samgeo`: "No matching distribution found"; `pypi.org/pypi/samgeo`
  returns 404), and SAM-class ViT encoders need GPU and multi-GB weights on a
  4-CPU, 6 GB RAM VM. `segment-anything` (SAM 1) does install, but running
  its ViT-H encoder over a 1,679×1,683 image with 1,919 point prompts on CPU
  was not attempted — it would take hours and risk OOM for a marginal gain
  over NDVI segmentation. This is a stated limitation, not a silent swap.
- **What was done instead (measured, not assumed):** NAIP 2022 4-band 0.6 m
  aerial imagery (Microsoft Planetary Computer, tile
  `ca_m_3712213_se_10_060_20220518`, 2022-05-18), downloaded as COG
  (388 MB; `naip_2022_tile.npz` kept, 1,679×1,683 window over the tile).
  NDVI = (NIR−R)/(NIR+R), aggregated to the 2 m ENU grid as max NDVI per cell.
- **NDVI gate had to be tuned down: 0.15, not 0.3.** Mubanga's "starting
  around 0.3" is unusable on this tile: DN-based NDVI maxes at ~0.27 across
  the whole tile, tree-point median is 0.168 (p10 −0.071, p90 0.254). NAIP is
  not calibrated reflectance, and May 2022 DN values are compressed. At 0.15
  the gate is at ~p75 of tree points; the LiDAR CHM≥2 m double gate (step 2)
  is what keeps asphalt/shadow out. NDVI alone is a weak discriminator here —
  background cells reach p90 0.167, barely below the tree median.
- **Measured crowns (footprint cells assigned to their nearest surveyed tree
  within 8 m; connected components were tried first and rejected — they merge
  whole street rows and overstated radius ~1.8×):**
  - 1,503 / 1,919 trees measured (78.3%); **416 fallback to DBH (21.7%)**
    — no NDVI footprint cell within 8 m (tree removed, coordinates off, or
    crown too small to register).
  - Crown radius measured: **median 2.99 m, mean 3.04 m, p10 1.60, p90 4.62,
    max 7.82** (old DBH: median 3.00 m, mean 2.62 m; median ratio 1.13).
  - Crown area: median 28.0 m², mean 33.3 m².
  - Crown top (LiDAR CHM inside footprint): **median 11.5 m, mean 11.7 m,
    p10 7.0, p90 17.2, max 20.0** (old DBH tops: median 8 m). The old
    allometry **underestimated tree height** — SF street trees are genuinely
    taller than the DBH rule said. Top is capped at 20 m by the CHM HAG
    1–20 m filter, and is a max over the footprint, so it can overstate
    where a neighbour's canopy overhangs.
  - Footprint (NDVI>0.15 + CHM≥2 m + not OSM building): 9.35% of tile cells,
    vs ~5.4% for the surveyed discs — some non-tree vegetation is included.

## Step 2 — LiDAR sampled only inside the footprints

3DEP LiDAR CHM (OSM-masked, 2 m) sampled only inside the NDVI footprints,
per tree, for crown-top height. This is what killed the old 10× overstatement:
the raw masked CHM gave mean foliage depth 43.5 m; with footprint + crown
base the measured depth mean is **7.5 m (3.6 GHz, 3 towers)** vs 4.07 m for
the old surveyed discs — deeper, but now because crowns are genuinely
taller/wider, not because of clutter and no crown bottom.

## Step 3 — common geometry for both bounds

The same measured crown volumes (NDVI footprint + LiDAR crown top + stated
crown base) feed both models: P.833 foliage depth per tower–receiver path,
and the solid-crown geometry meshes (`crowns_measured_{A,B}_r*.ply`, 7 radius
classes, ~153k faces, same lossy RadioMaterial calibration as the native
trial: eps_r=1.2, sigma 0.0005 @3.6 GHz / 0.0012 @28 GHz, S=0.3).
P.833 (γ,Am) = (0.55,38) at 3.6 GHz, (2.20,50) at 28 GHz — still
**interpolated/assumed, uncalibrated**, as flagged before.

### P.833, 3 towers, 3.6 GHz (full artefact baseline)

| | Depth mean | A_ev mean | Delta mean | Cells >1 dB | Worst | Coverage | Median | HO (nudged pts) |
|---|---|---|---|---|---|---|---|---|
| OLD surveyed discs | 4.07 m | 2.02 dB | −0.18 dB | 4.0% | −11.7 dB | 80.5% | −72.7 dBm | 11.2% |
| MEASURED A (CBH 3 m) | 7.51 m | 3.56 dB | −0.35 dB | 6.1% | −16.9 dB | 80.5% | −72.7 dBm | 11.2% |
| MEASURED B (CBH 0.35H) | 7.18 m | 3.43 dB | −0.34 dB | 6.1% | −18.4 dB | 80.5% | −72.7 dBm | 11.2% |
| MEASURED C (old base) | 8.20 m | 3.86 dB | −0.38 dB | 6.4% | −18.4 dB | 80.5% | −72.7 dBm | 11.2% |

Pairs with depth >0: 41.8% old → 54.6–57.5% measured. Coverage and median
RSRP are unchanged by trees in every variant. Handoff here is on the nudged
RX points; the artefact's grid-centre fixed-definition values (verified from
the live v7 file) are 3GPP 19.4%, Sionna 10.6%, SionnaRT-Veg 10.7% — the
measured-veg grid-centre HO was not recomputed, and is not claimed.

### P.833, 28 GHz, v8 small cells (16 cells, 8 m AGL)

| | Depth mean | Delta mean | Cells >1 dB | Worst | Coverage | Median |
|---|---|---|---|---|---|---|
| OLD surveyed discs | 20.46 m | −1.35 dB | 7.2% | −41.4 dB | 29.9% | −98.1 dBm |
| MEASURED A (CBH 3 m) | 25.90 m | −1.55 dB | 8.2% | −39.3 dB | 29.6% | −98.5 dBm |
| MEASURED B (CBH 0.35H) | 23.34 m | −1.62 dB | 8.2% | −39.3 dB | 29.8% | −98.6 dBm |
| MEASURED C (old base) | 29.28 m | −1.64 dB | 8.6% | −39.3 dB | 29.3% | −98.5 dBm |

### Solid crown, tower A only (same setup as the native trial)

| | No-path | Coverage | Median | LOS |
|---|---|---|---|---|
| OLD noveg 3.6 / 28 GHz | 35.7% / 36.2% | 36.2% / 12.8% | −86.7 / −105.6 dBm | 8.2% |
| OLD veg 3.6 / 28 GHz | 36.3% / 38.2% | 35.4% / 11.8% | −87.0 / −105.6 dBm | 7.7% |
| MEASURED A 3.6 GHz | 37.4% | 35.0% | −87.3 dBm | 7.4% |
| MEASURED B 3.6 / 28 GHz | 38.1% / 37.9% | 35.7% / 11.5% | −86.8 / −106.3 dBm | 7.4% |

## Step 4 — crown base height sensitivity

CBH variants: **A = 3 m clearance; B = 0.35 × tree height (median 3.55 m,
mean 3.75 m); C = old assumed base (2–3 m).** The sensitivity is **small**:
P.833 mean delta −0.35 / −0.34 / −0.38 dB at 3.6 GHz and −1.55 / −1.62 /
−1.64 dB at 28 GHz; native 3.6 GHz −1.43 (A) vs −1.30 dB (B). CBH is **not**
the lever at 30 m macro height — the lines mostly pass above the crowns or
through their upper part, and the 3 m vs 3.55 m bases barely differ. CBH
would matter more at 8 m small-cell height (v8), where the antennas sit
inside the crown band — not tested natively here.

## New finding: with measured (taller) crowns, LOS cells now lose more than NLOS

Old trial: LOS mean −0.04 dB, NLOS −1.43 dB at 3.6 GHz — the loss was almost
entirely NLOS. Measured B: **LOS −2.23 dB (9.8% >1 dB, worst −38.2 dB),
NLOS −1.16 dB (29.2% >1 dB)** at 3.6 GHz; at 28 GHz LOS −2.62 dB, NLOS
−1.90 dB. The taller measured crowns (median top 11.5 m vs 8 m assumed)
now intercept direct LOS paths that the old discs missed. A single tall
crown on a LOS path converts it to blocked/diffracted — the same cliff the
old trial found, now on LOS cells too.

## Why the gap didn't narrow (honest reading)

1. Measured crowns are taller and the footprint wider than the DBH discs, so
   the lower bound roughly doubled (−0.18 → −0.35 dB at 3.6 GHz, 3-tower;
   −0.37 → −0.78 dB at 28 GHz, tower A) **and** the upper bound grew
   (−1.26 → −1.30 dB at 3.6 GHz; −1.06 → −1.99 dB at 28 GHz).
2. The remaining gap is now attributable to **method**: P.833 touches LOS
   pairs only (phi=1/0), while solid-crown geometry attenuates every path
   through a crown, including diffuse/specular paths — and, with taller
   crowns, LOS paths too. Narrowing it further needs a method change (e.g.
   P.833 with a measured phi per pair, or a sparse-foliage material instead
   of a solid slab), not better crown outlines.
3. The solid crown is still an upper bound (solid dielectric, no gaps in
   real foliage) and P.833 LOS-only is still a lower bound. Truth remains
   between them; the bounds are now **−0.35 to −1.30 dB mean at 3.6 GHz
   (tower A: −0.22 to −1.30 dB)** and **−0.78 to −1.99 dB at 28 GHz**.

## Caveats

- SAM 3 not run (see step 1); footprints are NDVI segmentation, not SAM
  polygons. Re-running with SAM 3 on a GPU machine is the obvious next step
  and would sharpen footprints, but is unlikely to change the headline:
  crown *height* (LiDAR) is what moved the numbers, and SAM only measures
  2D outlines.
- NAIP 2022 vs LiDAR spring 2023 vs DataSF survey — dates differ; trees
  planted/removed between them add noise. 21.7% of trees fell back to DBH.
- NDVI is weak on this tile (see step 1); the footprint leans on the
  CHM≥2 m double gate. 9.35% footprint vs ~5.4% surveyed discs — some
  non-tree vegetation is in the measured crowns.
- Crown top = max CHM in the footprint (capped 20 m); can overstate where a
  neighbour's canopy overhangs. Crown radius = sqrt(area/π) of cells
  assigned to the nearest tree — a partition, not a per-tree outline.
- P.833 (γ,Am) still interpolated/uncalibrated at both bands.
- Native runs are tower A only, 40 m grid, 1M samples, max_depth 3, same
  material calibration to interpolated P.833 as the old trial.
- Handoff figures: fixed definition (grid centres, NaN-safe) verified from
  the live v7 file — 3GPP 19.4%, Sionna 10.6%, SionnaRT-Veg 10.7%. The
  nudged-point values in the tables above (20.5 / 11.0 / 11.2%) differ only
  because the RX points are nudged, not grid centres.

## Files (all under `measured-veg/`)

- `NOTE.md` (this file), `build_measured.py`, `compute_depth.py`,
  `compute_depth_28.py`, `rt_measured_veg.py`, `run_measured.sh`,
  `run_measured.log`
- `naip_2022_tile.npz` (NAIP window, 0.6 m, R/G/B/NIR), `naip_2m.npz`
  (max NDVI per 2 m cell), `footprint_2m.npz`, `measured_trees.json`
  (per-tree measured radius/top/fallback), `measured_grids.npz`
  (footprint, top, cell_tree)
- `p833_measured_{A_3m,B_0.35H,C_oldbase}.npz`,
  `p833_28ghz_measured_{A_3m,B_0.35H,C_oldbase}.npz`,
  `p833_measured_results.json`
- `crowns_measured_{A,B}_r*.ply` (7 radius classes each),
  `meshes_measured_{A,B}.json`
- `results_native_measured_B_f3600.npz`, `results_native_measured_B_f28000.npz`,
  `results_native_measured_A_f3600.npz`
- The 388 MB full NAIP COG was deleted after the window was extracted.
