#!/usr/bin/env python3
"""P.833 on measured crowns (steps 3+4) + CBH sensitivity + fixed handoff.

Common geometry: measured footprints (NDVI gate 0.15 + OSM-masked LiDAR
CHM>=2 m), LiDAR crown top per cell, crown base per variant:
  A: CBH = 3.0 m AGL (minimum clearance)
  B: CBH = 0.35 x tree height (height = LiDAR crown top, AGL)
  C: old assumed base (2-3 m per DBH class) on measured footprint+top
P.833 (gamma,Am): 3.6 GHz (0.55,38), 28 GHz (2.20,50) — INTERPOLATED/
ASSUMED, uncalibrated. phi = 1 LOS / 0 non-LOS, as in v7 (lower bound).
Handoff: FIXED definition — grid cells, NaN-safe (NaN sector = -inf;
a cell needs >=2 valid sectors to count as handoff region).
"""
import json, math
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
MEAS = ROOT + '/measured-veg'
STEP_M = 5.0
TXS = [('A', -250.0, 250.0), ('B', 250.0, 250.0), ('C', 0.0, -250.0)]
CELL, N = 2.0, 500


def ho_fixed(r):
    """r: (625, nsec) or (625,3,3). NaN-safe handoff fraction, % of all cells."""
    flat = r.reshape(r.shape[0], -1).astype(float)
    valid = ~np.isnan(flat)
    f = np.where(valid, flat, -np.inf)
    s = np.sort(f, axis=1)
    best, second = s[:, -1], s[:, -2]
    ok = valid.sum(axis=1) >= 2
    return float(np.mean(ok & ((best - second) < 3.0)) * 100)


def ho_buggy(r):
    flat = np.sort(r.reshape(r.shape[0], -1), axis=1)
    return float(np.mean((flat[:, -1] - flat[:, -2]) < 3.0) * 100)


def apply_p833(depth, los, rsrp, gamma, am):
    a = np.where(depth > 0, am * (1.0 - np.exp(-depth * gamma / am)), 0.0)
    phi = np.where(los, 1.0, 0.0)
    adj = np.where(a > 0, 10 * np.log10(1 - phi + phi * 10 ** (-a / 10)), 0.0)
    rv = np.where(np.isnan(rsrp), np.nan, (rsrp + adj[:, :, None]).astype(np.float32))
    return rv, a, adj


def stats(name, r):
    best = np.nanmax(np.nanmax(r, axis=2), axis=1)
    return dict(name=name, cov=float(np.mean(best >= -90) * 100),
                median=float(np.nanmedian(best)), ho_fixed=ho_fixed(r),
                ho_buggy=ho_buggy(r), nopath=float(np.isnan(best).mean() * 100))


def main():
    G = dict(np.load(f'{MEAS}/measured_grids.npz', allow_pickle=True))
    top = G['top'].astype(float)
    ctree = G['cell_tree']
    rows = json.loads(str(G['measured']))
    D = dict(np.load(f'{ROOT}/results_multicell_f3600_street.npz', allow_pickle=True))
    pts, los, rsrp = D['rx_xyz'], D['los_tx'], D['rsrp_tilt4']
    # CBH grids per variant
    cbh = {}
    cbh['A_3m'] = np.where(ctree >= 0, 3.0, np.nan)
    h = np.where(ctree >= 0, top, np.nan)
    cbh['B_0.35H'] = np.where(ctree >= 0, 0.35 * top, np.nan)
    z0 = np.zeros(len(rows))
    for i, r in enumerate(rows):
        z0[i] = r['z0_old']
    cbh['C_oldbase'] = np.where(ctree >= 0, z0[np.maximum(ctree, 0)], np.nan)
    # foliage depth per variant
    out = {}
    for var, cb in cbh.items():
        depth = np.zeros((625, 3), dtype=np.float32)
        for ti, (nm, tx_, ty_) in enumerate(TXS):
            for i in range(625):
                rx, ry = pts[i, 0], pts[i, 1]
                L = math.hypot(rx - tx_, ry - ty_)
                n = max(2, int(L / STEP_M))
                tt = (np.arange(n) + 0.5) / n
                px = tx_ + (rx - tx_) * tt
                py = ty_ + (ry - ty_) * tt
                lh = 30.0 + (1.5 - 30.0) * tt
                cx = ((px + 500) // CELL).astype(int)
                cy = ((py + 500) // CELL).astype(int)
                okc = (cx >= 0) & (cx < N) & (cy >= 0) & (cy < N)
                hit = np.zeros(n, dtype=bool)
                hit[okc] = (ctree[cy[okc], cx[okc]] >= 0) & \
                           (lh[okc] >= cb[cy[okc], cx[okc]]) & \
                           (lh[okc] <= top[cy[okc], cx[okc]])
                depth[i, ti] = hit.sum() * (L / n)
        out[var] = depth
        print(f"depth {var}: mean {depth.mean():.2f} m median {np.median(depth):.2f} "
              f"p90 {np.percentile(depth,90):.2f} max {depth.max():.2f} "
              f"pairs>0 {(depth>0).mean()*100:.1f}%")
    V = dict(np.load(f'{ROOT}/veg_layer_40m.npz', allow_pickle=True))
    print(f"depth OLD surveyed discs: mean {V['depth_surveyed'].mean():.2f} m median "
          f"{np.median(V['depth_surveyed']):.2f} p90 {np.percentile(V['depth_surveyed'],90):.2f} "
          f"max {V['depth_surveyed'].max():.2f} pairs>0 {(V['depth_surveyed']>0).mean()*100:.1f}%")
    print(f"depth OLD LiDAR CHM (no CBH): mean {V['depth'].mean():.2f} m "
          f"pairs>0 {(V['depth']>0).mean()*100:.1f}%")
    # 3.6 GHz P.833 on each variant + old
    res = {}
    for var, depth in out.items():
        rv, a, adj = apply_p833(depth, los, rsrp, 0.55, 38.0)
        best = np.nanmax(np.nanmax(rv, axis=2), axis=1)
        base = np.nanmax(np.nanmax(rsrp, axis=2), axis=1)
        dlt = best - base
        s = stats(f'measured {var}', rv)
        print(f"P.833 3.6 {var}: A_ev mean {a.mean():.2f} dB max {a.max():.2f} | "
              f"cov {s['cov']:.1f}% median {s['median']:.1f} dBm HO_fixed {s['ho_fixed']:.1f}% "
              f"(buggy {s['ho_buggy']:.1f}%) | delta median {np.nanmedian(dlt):+.2f} "
              f"mean {np.nanmean(dlt):+.2f} cells<-1dB {np.mean(dlt<-1)*100:.1f}% "
              f"worst {np.nanmin(dlt):.1f} dB")
        res[var] = dict(depth_mean=float(depth.mean()), a_ev_mean=float(a.mean()),
                        cov=s['cov'], median=s['median'], ho_fixed=s['ho_fixed'],
                        delta_median=float(np.nanmedian(dlt)), delta_mean=float(np.nanmean(dlt)),
                        cells_below_minus1=float(np.mean(dlt < -1) * 100),
                        worst=float(np.nanmin(dlt)))
        np.savez_compressed(f'{MEAS}/p833_measured_{var}.npz', depth=depth, a_ev=a,
                            veg_adj=adj, rsrp_veg=rv)
    rv_old, a_old, adj_old = apply_p833(V['depth_surveyed'], los, rsrp, 0.55, 38.0)
    best = np.nanmax(np.nanmax(rv_old, axis=2), axis=1)
    base = np.nanmax(np.nanmax(rsrp, axis=2), axis=1)
    dlt = best - base
    s = stats('old surveyed', rv_old)
    print(f"P.833 3.6 OLD surveyed: A_ev mean {a_old.mean():.2f} dB | cov {s['cov']:.1f}% "
          f"median {s['median']:.1f} HO_fixed {s['ho_fixed']:.1f}% (buggy {s['ho_buggy']:.1f}%) | "
          f"delta median {np.nanmedian(dlt):+.2f} mean {np.nanmean(dlt):+.2f} "
          f"cells<-1dB {np.mean(dlt<-1)*100:.1f}% worst {np.nanmin(dlt):.1f} dB")
    res['OLD_surveyed'] = dict(depth_mean=float(V['depth_surveyed'].mean()),
                               a_ev_mean=float(a_old.mean()), cov=s['cov'], median=s['median'],
                               ho_fixed=s['ho_fixed'],
                               delta_median=float(np.nanmedian(dlt)),
                               delta_mean=float(np.nanmean(dlt)),
                               cells_below_minus1=float(np.mean(dlt < -1) * 100),
                               worst=float(np.nanmin(dlt)))
    # baselines (no veg) + 3GPP for HO reference
    s0 = stats('Sionna no-veg', rsrp)
    print(f"no-veg baseline: cov {s0['cov']:.1f}% median {s0['median']:.1f} "
          f"HO_fixed {s0['ho_fixed']:.1f}% (buggy {s0['ho_buggy']:.1f}%) no-path {s0['nopath']:.1f}%")
    # 3GPP grid (same formula as compare_veg.py)
    gx = pts[:, 0] + 500.0; gy = 500.0 - pts[:, 1]
    TOWERS = {'A': (250., 250.), 'B': (750., 250.), 'C': (500., 750.)}
    def sector_gain(az_deg, x, y, tx, ty):
        ang = math.degrees(math.atan2(y - ty, x - tx))
        diff = abs((ang - az_deg + 180) % 360 - 180)
        return 15 - min(12 * (diff / 65.0) ** 2, 25)
    def pl_uma(dd):
        return 28.0 + 22 * math.log10(max(dd, 10.0)) + 20 * math.log10(3.6)
    g3 = np.zeros((625, 3, 3))
    for ti, (nm, (tx, ty)) in enumerate(TOWERS.items()):
        for si, az in enumerate((0, 120, 240)):
            for i in range(625):
                dd = math.hypot(gx[i] - tx, gy[i] - ty)
                g3[i, ti, si] = 47 + sector_gain(az, gx[i], gy[i], tx, ty) - pl_uma(dd)
    sg = stats('3GPP', g3)
    print(f"3GPP: cov {sg['cov']:.1f}% median {sg['median']:.1f} HO_fixed {sg['ho_fixed']:.1f}% "
          f"(buggy {sg['ho_buggy']:.1f}%)")
    res['baseline'] = dict(sionna_noveg=s0, gpp=sg)
    json.dump(res, open(f'{MEAS}/p833_measured_results.json', 'w'), indent=1)
    print('wrote p833_measured_results.json')


if __name__ == '__main__':
    main()
