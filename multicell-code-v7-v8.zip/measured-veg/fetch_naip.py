"""Fetch NAIP 2022 4-band tile for the 1 km SF tile from Planetary Computer COG."""
import numpy as np, rasterio
from rasterio.windows import from_bounds
URL="naip_2022_full.tif"
# tile bounds in lon/lat (approx 1 km around centre)
lon0, lat0 = -122.404175, 37.801105
# ~500 m in degrees
dlat = 500/110574.0; dlon = 500/(111320.0*np.cos(np.radians(lat0)))
w, s, e, n = lon0-dlon, lat0-dlat, lon0+dlon, lat0+dlat
with rasterio.open(URL) as src:
    print('crs', src.crs, 'res', src.res, 'count', src.count, 'dtype', src.dtypes, 'bounds', src.bounds)
    win = from_bounds(w, s, e, n, src.transform)
    print('window', win)
    arr = src.read(window=win)  # (4, H, W) R,G,B,NIR
    print('arr', arr.shape)
    np.savez_compressed('naip_2022_tile.npz', arr=arr, transform=np.array(src.window_transform(win)),
                        crs=str(src.crs), lon0=lon0, lat0=lat0, bounds=np.array([w,s,e,n]))
    print('saved', arr.shape)
