#!/usr/bin/env python3
"""Build measured_veg_rsrp_B_0.35H_28GHz.json from p833_28ghz_measured_B_0.35H.npz.

Same format as measured_veg_rsrp_B_0.35H_3.6GHz.json, but for the v8
28 GHz small-cell layout: 16 small cells x 3 sectors = 48 columns.
The npz already contains the finished grid rsrp_veg (625,16,3) =
rsrp_tilt4 + veg_adj broadcast over each cell's 3 sectors; this script
verifies that identity, flattens cell-major (ti*3+si, ti in S00..S33
order, si = sectors 90/210/330 deg) to [625][48] at 1 d.p., and
recomputes the headline stats from the JSON itself.
"""
import json
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
MEAS = ROOT + '/measured-veg'
OUT = MEAS + '/measured_veg_rsrp_B_0.35H_28GHz.json'

M = np.load(f'{MEAS}/p833_28ghz_measured_B_0.35H.npz')
depth, a_ev, adj, rv = M['depth'], M['a_ev'], M['veg_adj'], M['rsrp_veg']
D = dict(np.load(f'{ROOT}/results_28ghz_smallcell_street.npz', allow_pickle=True))
src = D['rsrp_tilt4']          # (625,16,3) no-veg, same cell order
txs = D['txs']                 # (16,4) name, x_ENU, y_ENU, z
xs = [float(v) for v in D['xs']]
ys = [float(v) for v in D['ys']]
assert src.shape == (625, 16, 3) and rv.shape == (625, 16, 3)
# 1. verify npz grid = source + veg_adj broadcast (exact, <1e-4 dB)
recon = np.where(np.isnan(src), np.nan, (src + adj[:, :, None]).astype(np.float32))
assert (np.isnan(rv) == np.isnan(src)).all(), 'NaN pattern mismatch'
assert float(np.nanmax(np.abs(rv - recon))) < 1e-4, 'rsrp_veg != rsrp_tilt4 + veg_adj'
# 2. verify against the v8 page's embedded SIONNA28 (1 d.p. rounding, max 0.05 dB)
h = open(f'{ROOT}/6g-ran-multicell-handoff-v8.html').read()
i = h.find('SIONNA28={'); j = h.find('};', i)
emb = np.array(json.loads(h[i + len('SIONNA28='):j + 1])['rsrp'], dtype=float)
assert emb.shape == (625, 16, 3)
assert (np.isnan(emb) == np.isnan(src)).all()
assert float(np.nanmax(np.abs(emb - src))) <= 0.05 + 1e-9

sectors = []
for ti, t in enumerate(txs):
    name = str(t[0])
    for si, az in enumerate([90, 210, 330]):
        sectors.append({'cell': name, 'sector': si + 1, 'azimuth_deg': az,
                        'x_m': float(t[1]), 'y_m': float(t[2])})

def r1(a):
    return [[None if np.isnan(v) else round(float(v), 1) for v in row]
            for row in a]

rsrp_flat = rv.reshape(625, 48)          # cell-major: ti*3+si
src_flat = src.reshape(625, 48)
rsrp_dbm = r1(rsrp_flat)

def best(a):
    with np.errstate(all='ignore'):
        return np.nanmax(a, axis=1)

best_veg = best(rsrp_flat)
best_noveg = best(src_flat)
best_sector = [None if np.isnan(best_veg[c]) else
               f"{sectors[int(np.nanargmax(rsrp_flat[c]))]['cell']}-"
               f"{sectors[int(np.nanargmax(rsrp_flat[c]))]['sector']}"
               for c in range(625)]
loss = best_veg - best_noveg            # <=0 where defined, NaN where no path
foliage_loss = (-adj).astype(float)      # positive dB per (cell, small cell)

def pct(x):
    return round(float(np.mean(x)) * 100, 2)

cov = pct(best_veg >= -90)
med = round(float(np.nanmedian(best_veg)), 1)
nopath = pct(np.isnan(best_veg))
dmean = round(float(np.nanmean(loss)), 3)
dmed = round(float(np.nanmedian(loss)), 1)
gt1 = pct((loss < -1))
worst = round(float(np.nanmin(loss)), 1)

def handoff(a):
    # best vs second-best < 3 dB, share of all 625 cells (page definition).
    # NaN-aware: sort only the finite values in each row; rows with <2
    # finite sectors cannot be in a handoff region.
    out = []
    for row in a:
        fin = np.sort(row[np.isfinite(row)])[::-1]
        out.append(len(fin) >= 2 and (fin[0] - fin[1]) < 3)
    return round(float(np.mean(out)) * 100, 2)

ho_page = handoff(np.array([[np.nan if v is None else v for v in row]
                            for row in rsrp_dbm], dtype=float))
ho_src = handoff(rsrp_flat)
ho_noveg = handoff(src_flat)

data = {
    'title': '5G NR Multicell Twin — SionnaRT-Veg, MEASURED crowns (CBH B), 28 GHz',
    'variant': 'P.833 measured crowns, CBH B = 0.35 x tree height (LiDAR crown top)',
    'band_ghz': 28,
    'grid': {'n_rows': 25, 'n_cols': 25, 'n_cells': 625, 'cell_size_m': 40,
             'xs_m': xs, 'ys_m': ys,
             'cell_order': 'row-major, index = ri*25+ci; ri indexes ys (-480 -> +480), '
                           'ci indexes xs (-480 -> +480), ENU metres about tile centre '
                           '37.801105, -122.404175. Identical to the v8 page SIONNA28 order.'},
    'sectors': sectors,
    'sector_order': '[625][48] columns are cell-major: S00-1,S00-2,S00-3, S01-1,S01-2,S01-3, '
                    '... S33-1,S33-2,S33-3 — 16 small cells in TWS28 order (S00..S03 south row, '
                    'S10..S13, S20..S23, S30..S33 north row) x sectors 90/210/330 deg, matching '
                    'the v8 page rsrps() order (TWS28 ti, then si 0,1,2).',
    'small_cells': [{'name': str(t[0]), 'x_m': float(t[1]), 'y_m': float(t[2]),
                     'height_m_agl': 8, 'eirp_dbm': 40, 'tilt_deg': 4,
                     'spacing_m': 250, 'sectors_per_cell': 3} for t in txs],
    'rsrp_dbm': rsrp_dbm,
    'best_server_rsrp_dbm': [None if np.isnan(v) else round(float(v), 1) for v in best_veg],
    'best_server_sector': best_sector,
    'best_server_rsrp_dbm_no_veg': [None if np.isnan(v) else round(float(v), 1)
                                    for v in best_noveg],
    'best_server_loss_db': [None if np.isnan(v) else round(float(v), 1) for v in loss],
    'foliage_loss_per_cell_db': r1(foliage_loss),
    'foliage_depth_per_cell_m': r1(depth),
    'verification_stats': {
        'coverage_pct_ge_minus90': cov,
        'median_best_server_rsrp_dbm': med,
        'no_path_pct': nopath,
        'best_server_delta_mean_db': dmean,
        'best_server_delta_median_db': dmed,
        'cells_losing_more_than_1db_pct_of_all_625': gt1,
        'worst_best_server_delta_db': worst,
        'handoff_region_lt3db_pct_of_all_625_page_rounded_grid': ho_page,
        'handoff_region_lt3db_pct_unrounded_source': ho_src,
        'handoff_region_lt3db_pct_no_veg_unrounded': ho_noveg,
        'best_server_cell_changes_vs_no_veg': int(np.sum(
            [best_sector[c] is not None and
             f"{sectors[int(np.nanargmax(src_flat[c]))]['cell']}-"
             f"{sectors[int(np.nanargmax(src_flat[c]))]['sector']}" != best_sector[c]
             for c in range(625) if not np.isnan(best_veg[c])])),
    },
    'provenance': {
        'method': 'ITU-R P.833-10 Eq.(1) foliage loss applied post-trace to the Sionna '
                  '28 GHz ray-traced small-cell grid. Loss per small-cell-receiver pair, '
                  'applied equally to all 3 sectors of that cell. phi = 1 for LOS pairs, '
                  '0 for non-LOS (lower bound).',
        'p833_gamma_Am_28GHz': [2.20, 50],
        'p833_gamma_Am_note': 'INTERPOLATED / ASSUMED, uncalibrated at 28 GHz.',
        'crowns': 'Measured: NAIP 2022 4-band 0.6 m imagery, NDVI gate 0.15 seeded at the '
                  '1,919 DataSF surveyed tree points; LiDAR crown top from OSM-masked 3DEP '
                  'CHM sampled only inside the NDVI footprints; 1,503/1,919 trees measured, '
                  '416 fell back to the DBH rule. Crown base CBH B = 0.35 x LiDAR tree height.',
        'source_files': ['results_28ghz_smallcell_street.npz (rsrp_tilt4, 16 cells x 3 sectors, '
                         '8 m AGL, EIRP 40 dBm, tilt 4 deg)',
                         'measured-veg/p833_28ghz_measured_B_0.35H.npz (depth, a_ev, veg_adj, rsrp_veg)',
                         'measured-veg/measured_grids.npz (footprint, crown top, cell_tree)',
                         '6g-ran-multicell-handoff-v8.html (SIONNA28 embedded grid, verified identical '
                         'to rsrp_tilt4 to 1 d.p. rounding, max 0.05 dB, NaN pattern identical)'],
        'checks': 'rsrp_veg verified = rsrp_tilt4 + veg_adj broadcast over sectors (max diff <1e-4 dB); '
                  'NaN pattern identical to no-veg grid (23,415 nulls of 30,000 entries).',
    },
    'notes_for_claude': 'Load rsrp_dbm as the new SIONNA28V (same xs/ys, same [625][16][3] layout '
                        'after reshaping each row to [16][3] cell-major). Update the v8 comparison '
                        'note: trees mean -1.62 dB (was -1.35), 8.2% cells >1 dB (was 7.2%), worst '
                        '-39.3 dB (was -41.4); coverage 29.8% (was 29.9%) and median -98.6 dBm '
                        '(was -98.1 dBm). Keep the P.833 lower-bound wording and the (gamma,Am) '
                        'interpolated caveat. This is the measured-crown P.833 run only, NOT the '
                        'native solid-crown run (tower-A-only, separate).',
}
with open(OUT, 'w') as f:
    json.dump(data, f)
print('wrote', OUT)
print(json.dumps(data['verification_stats'], indent=1))
print('sectors', len(sectors), 'rows', len(rsrp_dbm), 'cols', len(rsrp_dbm[0]))
