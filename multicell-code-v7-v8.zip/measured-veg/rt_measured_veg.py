#!/usr/bin/env python3
"""Solid-crown geometry ray trace on MEASURED crowns (Mubanga step 3).

Crowns from measured_trees.json: radius = measured NDVI/LiDAR footprint
radius (fallback: DBH radius), top = LiDAR crown top in footprint
(fallback: old z1), base = CBH variant (A: 3 m; B: 0.35 x height).
Same lossy RadioMaterial calibration as the native trial (eps_r=1.2,
sigma 0.0005 @3.6 GHz / 0.0012 @28 GHz, S=0.3, thickness=crown radius),
same tower-A-only 40 m setup, 1M samples, max_depth=3. Only veg=1 runs
are needed: the no-veg baselines already exist in native-veg-trial/.
"""
import argparse, json, math, os, sys, time
import numpy as np

MEAS = os.path.dirname(os.path.abspath(__file__))
NATIVE = os.path.join(os.path.dirname(MEAS), 'native-veg-trial')
PARENT = os.path.dirname(MEAS)
sys.path.insert(0, PARENT)
sys.path.insert(0, NATIVE)
from rt_native_veg import load_scene, solve_chunk, build_rx_grid, TILTS, P_COND_DBM, G_ARRAY_DB  # noqa
import rt_native_veg as _nv

SF = '/home/hatch/workspace/sf-twin'
SCENE = os.path.join(SF, 'scene_sf')
RAST = np.load(os.path.join(SCENE, 'height_rasters.npz'))
GROUND = RAST['ground']
RX0, RY0, CELL = float(RAST['x0']), float(RAST['y0']), float(RAST['cell'])
LAT0, LON0 = 37.801105, -122.404175
CHUNK = 125


def cbh_of(r, variant):
    top = r['top_m'] if not r['fallback'] else r['z1_old']
    if variant == 'A':
        return 3.0
    return 0.35 * top


def build_measured_meshes(variant):
    import trimesh
    rows = json.load(open(os.path.join(MEAS, 'measured_trees.json')))
    per_class = {}
    for r in rows:
        rad = r['r_meas'] if not r['fallback'] else r['r_old']
        top = r['top_m'] if not r['fallback'] else r['z1_old']
        z0 = cbh_of(r, variant)
        if top <= z0 + 0.5:
            continue
        x, y = r['x'], r['y']
        rr, cc = int(np.clip((y - RY0) / CELL, 0, GROUND.shape[0] - 1)), \
            int(np.clip((x - RX0) / CELL, 0, GROUND.shape[1] - 1))
        gz = float(GROUND[rr, cc])
        zc = gz + (z0 + top) / 2.0
        zh = (top - z0) / 2.0
        per_class.setdefault(float(int(round(rad))), []).append((x, y, zc, zh, rad))
    out = {}
    total_faces = 0
    for rad, lst in sorted(per_class.items()):
        meshes = []
        for (x, y, zc, zh, r_) in lst:
            m = trimesh.creation.icosphere(subdivisions=1, radius=1.0)
            m.apply_scale([r_, r_, zh])
            m.apply_translation([x, y, zc])
            meshes.append(m)
        merged = trimesh.util.concatenate(meshes)
        fn = os.path.join(MEAS, f'crowns_measured_{variant}_r{rad:.1f}.ply')
        merged.export(fn)
        out[rad] = (fn, len(lst), len(merged.faces))
        total_faces += len(merged.faces)
        print(f"R={rad} m: {len(lst)} trees, {len(merged.faces)} faces -> {fn}", flush=True)
    print(f"total faces {total_faces}, trees meshed {sum(v[1] for v in out.values())}", flush=True)
    json.dump({str(k): v for k, v in out.items()},
              open(os.path.join(MEAS, f'meshes_measured_{variant}.json'), 'w'), indent=1)
    return out


def load_scene_measured(freq_ghz, variant):
    import mitsuba as mi
    mi.set_variant('llvm_ad_mono_polarized')
    import sionna.rt as rt
    from sionna.rt import RadioMaterial
    from sionna.rt.radio_materials.itu import itu_material
    import drjit as dr
    s = rt.load_scene(os.path.join(SCENE, 'scene.xml'), merge_shapes=True)
    for m in s.radio_materials.values():
        if type(m).__name__ != 'ITURadioMaterial':
            continue
        t = m.itu_type
        m.scattering_coefficient = 0.3
        if freq_ghz < 1.0 or freq_ghz > 10.0:
            m.frequency_update_callback = (
                lambda f, _t=t: itu_material(_t, dr.minimum(dr.maximum(f, 1e9), 1e12)))
    objs = []
    for fn in sorted(os.listdir(MEAS)):
        if fn.startswith(f'crowns_measured_{variant}_r') and fn.endswith('.ply'):
            rad = float(fn.split('_r')[1][:-4])
            mat = RadioMaterial(name=f"foliage_meas_{variant}_r{int(rad)}", thickness=float(rad),
                                relative_permittivity=1.2,
                                conductivity=_nv.SIGMA[freq_ghz],
                                scattering_coefficient=0.3)
            objs.append(rt.SceneObject(fname=os.path.join(MEAS, fn),
                                       name=f"crowns_meas_{variant}_r{int(rad)}",
                                       radio_material=mat))
    s.add(objs)
    s.frequency = freq_ghz * 1e9
    iso = rt.PlanarArray(num_rows=1, num_cols=1, pattern='iso', polarization='V')
    s.tx_array = iso
    s.rx_array = iso
    return s, rt


def solve_chunk_measured(pts, tx, freq_ghz, variant):
    s, rt = load_scene_measured(freq_ghz, variant)
    s.add(rt.Transmitter('txA', position=[tx[0], tx[1], tx[2]]))
    for i, (x, y, z) in enumerate(pts):
        s.add(rt.Receiver(f'r{i}', position=[float(x), float(y), float(z)]))
    t0 = time.time()
    p = rt.PathSolver()(s, max_depth=3, los=True, specular_reflection=True,
                        diffuse_reflection=True, refraction=True, diffraction=True,
                        edge_diffraction=True, samples_per_src=_nv.SAMPLES,
                        max_num_paths_per_src=_nv.SAMPLES)
    dt = time.time() - t0
    ar, ai = (np.asarray(a) for a in p.a)
    v = np.asarray(p.valid).astype(bool)
    pw = np.where(v, (ar[:, 0, :, 0, :] ** 2 + ai[:, 0, :, 0, :] ** 2), 0.0)
    th = np.asarray(p.theta_t)
    ph = np.asarray(p.phi_t)
    inter = np.asarray(p.interactions)
    is_los = (inter == 0).all(axis=0) & v
    dirpw = np.zeros((len(pts), len(TILTS), 3))
    for ti, tilt in enumerate(TILTS):
        for si, az in enumerate((90.0, 210.0, 330.0)):
            g = np.where(v, 10 ** (_nv.tr38901_gain_db(th, ph, tilt, az) / 10), 0.0)
            dirpw[:, ti, si] = (pw * g).sum(axis=2)[:, 0]
    iso = pw.sum(axis=2)[:, 0]
    return dict(dirpw=dirpw, iso=iso, los=is_los.any(axis=2)[:, 0],
                npath=v.sum(axis=2)[:, 0]), dt


def fname(freq_ghz, variant):
    return os.path.join(MEAS, f'results_native_measured_{variant}_f{int(freq_ghz*1000)}.npz')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--build-meshes', choices=['A', 'B'])
    ap.add_argument('--freq', type=float, choices=[3.6, 28.0])
    ap.add_argument('--variant', choices=['A', 'B'])
    ap.add_argument('--chunk', type=int)
    ap.add_argument('--post', action='store_true')
    a = ap.parse_args()
    if a.build_meshes:
        build_measured_meshes(a.build_meshes)
        return
    txs, xs, ys, pts, moved, indoor = build_rx_grid()
    tx = txs[0]
    n = len(pts)
    chunks = [(i, min(i + CHUNK, n)) for i in range(0, n, CHUNK)]
    out = fname(a.freq, a.variant)
    if a.post:
        d = dict(np.load(out, allow_pickle=True))
        assert len(d['done']) == len(chunks), f"chunks {sorted(d['done'])} of {len(chunks)}"
        t4 = TILTS.index(4.0)
        rsrp = np.where(d['dirpw'][:, t4, :] > 0,
                        P_COND_DBM + G_ARRAY_DB + 10 * np.log10(
                            np.maximum(d['dirpw'][:, t4, :], 1e-30)), np.nan)
        d['rsrp_tilt4'] = rsrp.astype(np.float32)
        d['rsrp_best'] = np.nanmax(rsrp, axis=1).astype(np.float32)
        np.savez_compressed(out, **d)
        r = d['rsrp_best']
        print(f"measured {a.variant} f{a.freq}: n={n} no-path {np.isnan(r).mean()*100:.1f}%  "
              f"LOS {d['los'].mean()*100:.1f}%  RSRP>=-90 {np.mean(r >= -90)*100:.1f}%  "
              f"median {np.nanmedian(r):.1f} dBm", flush=True)
        return
    if a.chunk is None:
        print(f'{len(chunks)} chunks; pass --chunk 0..{len(chunks)-1}; tower A {tx}')
        return
    i0, i1 = chunks[a.chunk]
    res, dt = solve_chunk_measured(pts[i0:i1], (tx[1], tx[2], tx[3]), a.freq, a.variant)
    if os.path.exists(out):
        d = dict(np.load(out, allow_pickle=True))
        done = set(d['done'].tolist())
    else:
        d = dict(dirpw=np.zeros((n, len(TILTS), 3)),
                 iso=np.zeros((n,)), los=np.zeros((n,), bool),
                 npath=np.zeros((n,), np.int32))
        done = set()
    for k, val in res.items():
        d[k][i0:i1] = val
    done.add(a.chunk)
    d.update(xs=xs, ys=ys, rx_xyz=pts, moved=moved, indoor=indoor,
             tilts=np.array(TILTS), sectors=np.array((90.0, 210.0, 330.0)),
             tx=np.array(tx, dtype=object), done=np.array(sorted(done)),
             meta=json.dumps(dict(freq_ghz=a.freq, variant=a.variant, rx='street',
                                  tx_agl_m=30.0, samples=_nv.SAMPLES, max_depth=3,
                                  eps_r=1.2, sigma=_nv.SIGMA[a.freq],
                                  scattering=0.3, thickness='crown radius',
                                  scene='Vexcel SF L20 + measured crown icospheres',
                                  version='measured-veg')))
    np.savez_compressed(out, **d)
    print(f"measured {a.variant} f{a.freq} chunk {a.chunk}/{len(chunks)-1}: "
          f"{i1-i0} pts in {dt:.0f}s; paths/RX median {np.median(res['npath']):.0f}",
          flush=True)


if __name__ == '__main__':
    main()
