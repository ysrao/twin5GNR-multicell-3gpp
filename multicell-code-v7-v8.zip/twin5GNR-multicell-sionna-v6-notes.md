# twin5GNR multicell — Sionna version at 10 m (v6) — build notes, 9–10 Nov 2026

## What was built
Artefact v6: same 3GPP/Sionna toggle and behaviour as v5, Sionna data now on a
100×100 grid at 10 m (10,000 cells) instead of 25×25 at 40 m (625 cells).
User chose "10 m for the whole tile, however long it takes" on 9 Nov 2026.

## Ray trace (Sionna 2.2.0, ~/workspace/cbrs-wisp-planner/venv/bin/python)
- Script: `rt_multicell_10m.py` (rt_multicell.py with STEP 10.0, grid
  −495…+495 m, 100×100; same towers, scene, materials, tilts, samples as v5).
  Output: `results_multicell_f3600_street_10m.npz` (10,000 pts × 3 TX × 6 tilts
  × 3 sectors). v5 40 m results NOT overwritten.
- Towers (ENU): A(−250,+250), B(+250,+250), C(0,−250), 30 m AGL, 3.6 GHz,
  tilt 4°, sectors 90°/210°/330°, EIRP 47 dBm, max depth 3, 1,000,000 samples.
- RX grid: 100×100 at 10 m, street level (ground + 1.5 m); points inside a
  building footprint nudged to the nearest open cell within 30 m (same rule
  as v5); 64.9% nudged, 0% still indoor. Note: the outer 10 m ring (±495 m)
  sits just outside the 194×194 @ 5 m height raster (±485 m), so its ground
  height is the clipped raster edge value — same open-air edge as v5's ±480 m.
- Runtime: 67 chunks, ~93–104 s solve each, ~110–123 s wall each; ~2 h 10 min
  of ray tracing in total. The run was interrupted twice by the runtime
  killing the driver process (SIGTERM, ~00:26Z and ~02:37Z); chunks are
  resumable and no work was lost — first kill after chunk 4, second kill
  after chunk 65 (66/67 done); chunk 66 + --post were run directly (~95 s).
- RSRP convention: total DL reference power at 47 dBm EIRP, as in v5.

## Results (3.6 GHz, street 1.5 m, tilt 4°) — comparison_10m.json
- 10 m Sionna (ray-traced/simulated, 10,000 cells): coverage RSRP ≥ −90 dBm
  81.8%, median best-server RSRP −72.1 dBm, no-path 9.5%, LOS to ≥1 tower
  23.4% (per TX 8.5 / 15.0 / 7.9%), HO region (<3 dB, sector level) 3.1%.
- 3GPP UMa on the same 10,000 points (modelled): coverage 100%, median
  −31.9 dBm, HO region 19.7%. Difference (Sionna − 3GPP): median −40.6 dB,
  mean −37.8 dB; 80.0% of cells >15 dB weaker in Sionna; 0% >10 dB stronger.
  Best-server agreement 73.0%.
- vs v5 at 40 m (625 cells): coverage 81.8% vs 80.5%, median −72.1 vs −72.7 dBm,
  no-path 9.5% vs 10.1%, LOS 23.4% vs 23.7%, HO region 3.1% vs 3.4% —
  the headline numbers barely move, but the map is genuinely different at
  street level: individual shadowed streets resolve separately instead of
  being averaged into a 40 m cell. Example: UE5 (800,700) was −83.8 dBm at
  40 m and is no-ray at 10 m; UE3 (600,500) was −48.2 dBm at 40 m, −75.7 dBm
  at 10 m. UE RSRPs at 10 m: −76.4 / −73.6 / −75.7 / −70.9 / no ray / −81.7 dBm.
- Sanity: 3GPP median on 10,000 points is −31.9 dBm (same as v5's 625-point
  value); per-TX medians and LOS shares match v5 within ~1 dB / ~1 pp.

## Artefact v6 (6g-ran-multicell-handoff-v6.html, 630,475 B, md5 e39b095c9426d2dfa2fe95643cc8a6c7)
- Built by build_v6.py from the v5 file + 10 m grids (100×100×3 TX×3 sectors,
  0.1 dB, null = no ray). Version stamped v6 inside the file. 3GPP mode is
  unchanged from v5. Comparison note updated with the 10 m numbers and the
  vs-v5 (40 m) deltas, labelled ray-traced/simulated, never measured.
- Bug found and fixed in testing: a no-ray UE showed "HO YES — Intra-tower
  sector HO" because best and 2nd RSRP were both −999 (diff 0 < threshold).
  The table HO flag now reads "No (no ray)" when the serving RSRP is −999
  (build_v6.py §4b). Verified in the Node smoke test (test_v6.js): both
  modes render, 6 UE rows each; Sionna UE RSRPs match compare_10m.py exactly.
- Sionna data are 3.6 GHz only; one material (ITU concrete); no vegetation,
  vehicles, or indoor loss — stated in the artefact note.

## Files in this folder (new for v6)
- rt_multicell_10m.py, run_10m.sh, run_10m.log,
  results_multicell_f3600_street_10m.npz, compare_10m.py, comparison_10m.json,
  build_v6.py, test_v6.js, 6g-ran-multicell-handoff-v6.html,
  twin5GNR-multicell-sionna-v6-notes.md
- v5 files untouched (40 m npz, comparison.json, v5 html md5
  6da604277c10c1f983c872e0e6aac328).

## Publish status
- NOT PUBLISHED. v6 supersedes v5 — do NOT publish v5. The separate browser
  task to publish v5 via the GitHub website was still pending on GitHub 2FA
  when v6 was built; publishing v6 should replace that task (same repo
  ysrao/twin5GNR-multicell-3gpp, replace index.html with the v6 file), then
  verify live in a real browser (Run re-renders, toggle switches maps).
  Hub card needs no change (same repo/link). Do NOT send the link to anyone.
