# twin5GNR multicell handoff artefact — v7 (Sionna + trees), 10 Nov 2026

v7 = v5 (Sionna 2.2.0, 3 towers, 3.6 GHz, tilt 4°, 25×25 grid at 40 m, street
1.5 m) PLUS a vegetation mode. Artefact file:
`6g-ran-multicell-handoff-v7.html` — 97,004 B, md5
3f0df00aedb233349ea913b80cdddd90. NOT published, NOT sent (needs user's
GitHub 2FA; separate step). v5 file untouched (md5 6da604277c10c1f983c872e0e6aac328).

## Route taken: post-trace P.833, NOT a Sionna vegetation material
Sionna 2.2.0 in this workflow has no vegetation material, and the v5 npz
stores aggregated dirpw, not per-path data, so a vegetation material would
need a full re-run with a modified scene. Instead: P.833-10 Eq.(1) applied
per TX-RX pair on the straight line, using foliage depth along that path.
Same approach as v5.1 RB. Foliage loss A_ev = Am·(1−exp(−d·γ/Am)),
3.6 GHz (γ,Am) = (0.55, 38) INTERPOLATED/ASSUMED from P.833-10,
uncalibrated. φ-weighting (LOS share): φ=1 for LOS pairs, 0 for non-LOS —
SF single-tower run measured LOS median φ=0.968, so the LOS error is <0.2 dB;
NLOS foliage is NOT modelled, so the veg effect is a LOWER BOUND for
non-LOS cells. Sign bug found and fixed in build: veg_adj ≤ 0, so
rsrp_veg = rsrp + veg_adj (an earlier build subtracted and RAISED RSRP).

## Headline foliage layer: surveyed trees (not the LiDAR CHM)
OSM building footprints DID work from this VM (api.openstreetmap.org,
200, 5.9 MB, 1,475 building ways — Overpass still 406). Masking the
3DEP LiDAR canopy-height model (2 m CHM) with OSM footprints:
- Surveyed-tree match: 97.6% of the 1,919 DataSF trees have masked CHM ≥2 m
  in their exact 2 m cell, 99.7% within ~6 m. LiDAR independently confirms
  the survey. (Mesh mask only 65.5%/86.5% — 5 m cells eat sidewalk-pit
  trees; OSM mask is the right one.)
- BUT the masked CHM as a foliage-depth source FAILS validation: mean
  depth 43.5 m vs 4.07 m from surveyed crown discs (~10×). Reasons:
  no crown bottom (line under a crown at 8–12 m counts even though it
  passes under the foliage), clutter (cars, fences, low structures),
  buildings OSM misses (67.4% of CHM≥8 m cells are in mesh buildings,
  0% in OSM by construction). Roof-exclusion (|CHM − mesh height| < 3 m)
  + 6 m crown thickness only brings it to 19.2 m; a 4 m crown still 14.1 m.
  Canopy is spread across the whole tile (13–62% per 100 m block), not
  concentrated in parks — not credible as trees alone.
- So the headline layer is the SURVEYED trees (exact positions, crown
  discs radius 2–5 m, height 2–12 m from trunk diameter, v5.1 method).
  The LiDAR layers are reported as sensitivity only (see below).

## Measured numbers (3.6 GHz, street 1.5 m, 625 cells, comparison_veg.json)
- Coverage ≥ −90 dBm: 3GPP 100.0% | Sionna 80.5% | Sionna + trees 80.5%
- Median best-server RSRP: 3GPP −31.9 dBm | Sionna −72.7 dBm | +trees −72.7 dBm
- Trees (surveyed): median delta 0.0 dB, mean −0.18 dB, 4.0% of cells
  lose >1 dB, worst cell −11.7 dB, best server changes on 0.2% of cells.
  Handoff region: 3GPP 20.5% | Sionna 3.4% | +trees 3.5%.
  UE3 (cyclist) −48.2 → −53.4 dBm (−5.2 dB); other 5 UEs unchanged.
- Hybrid sensitivity (surveyed + non-street LiDAR canopy ≥10 m from any
  surveyed tree, refined CHM, 6 m crown): mean depth 14.25 m, median delta
  0.0 dB, mean −0.60 dB, 10.1% of cells below −1 dB — still small at 3.6 GHz,
  and still an upper bound. NOT embedded in the artefact.
- Verdict: at 3.6 GHz trees are a tail effect, not a coverage effect —
  MEASURED here, confirming the 5 Nov verdict (the same trees cut 28 GHz
  throughput 15–33% at 100–500 m). All figures ray-traced/simulated,
  never measured.

## Files (all under twin5GNR-multicell-sionna/)
- `6g-ran-multicell-handoff-v7.html` (97,004 B, md5 above) — 3 radios:
  3GPP / Sionna / Sionna + trees; veg note + 3-way comparison note inside.
- `build_veg_layer2.py` — surveyed-tree depth + OSM/CHM masks + refined mask.
- `veg_layer_40m.npz` — depth_surveyed, chm (OSM-masked), a_ev, veg_adj.
- `veg_layer_40m_hybrid.npz` — depth_surveyed + depth_extra + depth_total.
- `compare_veg.py`, `comparison_veg.json`, `results_veg_40m.npz`
  (rsrp_veg_tilt4, rsrp_hybrid_tilt4).
- `build_v7.py`, `test_v7.js` — smoke test passed in all three modes
  (Node, stub DOM): UE3 −48.2 → −53.4 dBm, other UEs unchanged.
- `osm_tile.osm` — OSM tile (5.9 MB, 1,475 building ways).

## Not done / next
- 10 m + trees: the v6 10 m run was at chunk 16/66 at 01:00 UTC 10 Nov
  (~90 min left). Do NOT claim 10 m + trees until it is ray-traced; the
  veg layer builder is grid-agnostic (same code works on the 10 m npz).
- Not published to GitHub (needs user's 2FA), not sent to anyone.
- Sionna vegetation material / full re-run with trees in the scene: not
  attempted; post-trace P.833 is the documented route for this version.
