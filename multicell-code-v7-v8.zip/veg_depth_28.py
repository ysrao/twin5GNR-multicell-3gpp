#!/usr/bin/env python3
"""veg_depth_28.py - foliage depth per (RX, 16 small-cell TX) for the 28 GHz run.

Two layers, same methods as build_veg_layer2.py (v7):
  HEADLINE: surveyed-tree crown discs (1,919 DataSF trees, crown radius /
  height band from DBH allometry, ASSUMED, as in build_sf_veg_surveyed.py).
  SENSITIVITY: LiDAR masked CHM (veg_layer_40m.npz 'chm', 2 m ENU, OSM
  building-masked) -- v7 found this overstates depth ~10x vs surveyed
  discs (no crown bottom, clutter/unmapped buildings included), so it is
  reported as an upper-bound sensitivity only, never the headline.
Sampling: straight TX->RX line every 5 m, line height linear TX 8 m ->
RX 1.5 m; a sample counts if the crown disc / CHM covers it at that height.
P.833-10 Eq.(1) at 28 GHz: (gamma, Am) = (2.20, 50) INTERPOLATED/ASSUMED
from P.833-10, uncalibrated -- never present as measured. phi = 1 for
LOS pairs, 0 for non-LOS (needs the RT los_tx, so phi is applied in
compare_28.py, not here; here we store depths + A_ev only).
Output: veg_depth_28ghz.npz (depth_surveyed, depth_chm, a_ev_surveyed,
a_ev_chm, xs, ys).
"""
import json, math
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
TREES = '/home/hatch/workspace/twin5gnr-work/twin5GNR-SF-veg-surveyed/sf_trees_tile.json'
LAT0, LON0 = 37.801105, -122.404175
R = 6378137.0
COS = math.cos(math.radians(LAT0))
CX0 = R * math.radians(LON0)
CY0 = R * math.log(math.tan(math.pi / 4 + math.radians(LAT0) / 2))
STEP_M = 5.0
GAMMA, AM = 2.20, 50.0   # 28 GHz, INTERPOLATED/ASSUMED from P.833-10
TX_AGL, RX_H = 8.0, 1.5
CELL, N = 2.0, 500       # 2 m ENU grid over [-500, 500]^2
GRID_POS = (-375.0, -125.0, 125.0, 375.0)
TOWERS = [(f'S{r}{c}', x, y) for r, y in enumerate(GRID_POS) for c, x in enumerate(GRID_POS)]


def merc_enu(lat, lon):
    return ((R * math.radians(lon) - CX0) * COS,
            (R * math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) - CY0) * COS)


def crown_for(tt):
    try:
        v = float(tt.get('mapdbh'))
    except (TypeError, ValueError):
        v = None
    if v is None:
        r = {'1': 2.0, '2': 3.0, '3': 4.0, '4': 5.0}.get(str(tt.get('dbhrange')), 3.0)
        z = {'1': (3.0, 6.0), '2': (2.0, 8.0), '3': (2.0, 10.0), '4': (2.0, 12.0)}.get(
            str(tt.get('dbhrange')), (2.0, 8.0))
        return r, z[0], z[1]
    if v <= 10: return 2.0, 3.0, 6.0
    if v <= 20: return 3.0, 2.0, 8.0
    if v < 40: return 4.0, 2.0, 10.0
    return 5.0, 2.0, 12.0


def main():
    V = dict(np.load(f'{ROOT}/veg_layer_40m.npz', allow_pickle=True))
    chm = V['chm']  # (500,500) 2 m ENU, OSM-masked, max HAG
    D = dict(np.load(f'{ROOT}/results_multicell_f3600_street.npz', allow_pickle=True))
    xs, ys, pts = D['xs'], D['ys'], D['rx_xyz']  # same 25x25 grid as v5
    trees = json.load(open(TREES))
    s_tx, s_ty, s_tr, s_z0, s_z1 = [], [], [], [], []
    for tt in trees:
        try:
            a, b = merc_enu(float(tt['latitude']), float(tt['longitude']))
        except (KeyError, TypeError, ValueError):
            continue
        rr_, z0, z1 = crown_for(tt)
        s_tx.append(a); s_ty.append(b); s_tr.append(rr_); s_z0.append(z0); s_z1.append(z1)
    s_tx = np.array(s_tx); s_ty = np.array(s_ty); s_tr = np.array(s_tr)
    s_z0 = np.array(s_z0); s_z1 = np.array(s_z1)
    print(f'surveyed trees in tile: {len(s_tx)}')

    depth_srv = np.zeros((625, 16), dtype=np.float32)
    depth_chm = np.zeros((625, 16), dtype=np.float32)
    for ti, (nm, tx_, ty_) in enumerate(TOWERS):
        for i in range(625):
            rx, ry = pts[i, 0], pts[i, 1]
            L = math.hypot(rx - tx_, ry - ty_)
            n = max(2, int(L / STEP_M))
            tt_ = (np.arange(n) + 0.5) / n
            px = tx_ + (rx - tx_) * tt_; py = ty_ + (ry - ty_) * tt_
            hag_line = TX_AGL + (RX_H - TX_AGL) * tt_
            cx = ((px + 500) // CELL).astype(int); cy = ((py + 500) // CELL).astype(int)
            okc = (cx >= 0) & (cx < N) & (cy >= 0) & (cy < N)
            hit = np.zeros(n, dtype=bool)
            hit[okc] = (chm[cy[okc], cx[okc]] >= hag_line[okc]) & (chm[cy[okc], cx[okc]] >= 2.0)
            depth_chm[i, ti] = hit.sum() * (L / n)
            dx = px[:, None] - s_tx[None, :]
            dy = py[:, None] - s_ty[None, :]
            inside = (dx * dx + dy * dy) <= (s_tr[None, :] ** 2)
            inside &= (hag_line[:, None] >= s_z0[None, :]) & (hag_line[:, None] <= s_z1[None, :])
            depth_srv[i, ti] = inside.any(axis=1).sum() * (L / n)
    a_srv = np.where(depth_srv > 0, AM * (1.0 - np.exp(-depth_srv * GAMMA / AM)), 0.0)
    a_chm = np.where(depth_chm > 0, AM * (1.0 - np.exp(-depth_chm * GAMMA / AM)), 0.0)
    print(f'depth surveyed (16 TX): mean {depth_srv.mean():.2f} m median {np.median(depth_srv):.2f} '
          f'p90 {np.percentile(depth_srv, 90):.2f} max {depth_srv.max():.2f} pairs>0 {(depth_srv > 0).mean() * 100:.1f}%')
    print(f'depth LiDAR CHM (16 TX): mean {depth_chm.mean():.2f} m median {np.median(depth_chm):.2f} '
          f'p90 {np.percentile(depth_chm, 90):.2f} max {depth_chm.max():.2f} pairs>0 {(depth_chm > 0).mean() * 100:.1f}%')
    print(f'P.833 A_ev @28 GHz (gamma,Am)=(2.20,50) ASSUMED: surveyed mean {a_srv.mean():.2f} dB '
          f'max {a_srv.max():.2f} dB | CHM mean {a_chm.mean():.2f} dB max {a_chm.max():.2f} dB')
    np.savez_compressed(f'{ROOT}/veg_depth_28ghz.npz',
                        depth_surveyed=depth_srv, depth_chm=depth_chm,
                        a_ev_surveyed=a_srv.astype(np.float32), a_ev_chm=a_chm.astype(np.float32),
                        xs=xs, ys=ys,
                        meta=json.dumps(dict(
                            source='surveyed: 1919 DataSF trees, crown-disc allometry ASSUMED; '
                                   'CHM: veg_layer_40m.npz masked CHM (USGS 3DEP B23, OSM mask) -- '
                                   'upper bound, clutter included; P.833-10 Eq.(1) 28 GHz '
                                   '(gamma,Am)=(2.20,50) INTERPOLATED/ASSUMED, uncalibrated; '
                                   'line sampled every 5 m, TX 8 m -> RX 1.5 m',
                            grid='25x25, 40 m, street 1.5 m', freq_ghz=28.0,
                            tx='16 small cells, 4x4, 250 m, 8 m AGL')))
    print('wrote veg_depth_28ghz.npz')


if __name__ == '__main__':
    main()
