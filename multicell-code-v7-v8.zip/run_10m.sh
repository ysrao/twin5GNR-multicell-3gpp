#!/bin/bash
# Sequential chunked 10 m run: 10,000 pts, CHUNK=150 -> 67 chunks (0..66).
# Resumable: rt_multicell_10m.py tracks done chunks in the .npz.
# Log per chunk; retry a failed chunk once, then stop so the failure is visible.
cd /home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna
PY=/home/hatch/workspace/cbrs-wisp-planner/venv/bin/python
echo "10m run started $(date -u +%FT%TZ)  chunks 0..66"
for i in $(seq 0 66); do
  t0=$(date +%s)
  $PY rt_multicell_10m.py --chunk $i >> run_10m.log 2>&1
  rc=$?
  t1=$(date +%s)
  echo "chunk $i rc=$rc $((t1-t0))s $(date -u +%FT%TZ)" >> run_10m.log
  if [ $rc -ne 0 ]; then
    echo "chunk $i FAILED rc=$rc, retrying once" >> run_10m.log
    $PY rt_multicell_10m.py --chunk $i >> run_10m.log 2>&1
    rc=$?
    echo "chunk $i retry rc=$rc $(date -u +%FT%TZ)" >> run_10m.log
    if [ $rc -ne 0 ]; then echo "ABORT at chunk $i $(date -u +%FT%TZ)" >> run_10m.log; exit 1; fi
  fi
done
echo "all chunks done, running --post" >> run_10m.log
$PY rt_multicell_10m.py --post >> run_10m.log 2>&1
echo "post rc=$? $(date -u +%FT%TZ)" >> run_10m.log
