// Smoke-test v7 artefact JS: stub a minimal DOM, run draw() in 3GPP, Sionna
// and Sionna+trees modes, and print the UE table + status.
const fs = require('fs');
const html = fs.readFileSync('6g-ran-multicell-handoff-v7.html', 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
if (scripts.length < 2) { console.error('expected 2 script blocks, got', scripts.length); process.exit(1); }
function makeEl(id) {
  const el = { id, value: '3.5', textContent: '', innerHTML: '', style: {},
    disabled: false, checked: false,
    addEventListener: () => {}, getContext: () => ctxStub,
    querySelector: () => null, appendChild: () => {} };
  return el;
}
const ctxStub = new Proxy({}, { get: (t, k) => (k === 'canvas' ? {} : (() => {})),
  set: () => true });
const els = {};
['freq','morph','mimo','eirp','bw','houe','ax','ay','bx','by','cx','cy',
 'runBtn','animBtn','status','map','sionnaNote','vegNote'].forEach(id => els[id] = makeEl(id));
els.freq.value='3.5'; els.morph.value='UMa'; els.mimo.value='4'; els.eirp.value='47';
els.bw.value='100'; els.houe.value='all';
els.ax.value='250'; els.ay.value='250'; els.bx.value='750'; els.by.value='250';
els.cx.value='500'; els.cy.value='750'; els.map.width=600; els.map.height=600;
let modelVal = '3gpp';
const tbody = { innerHTML: '', children: [], appendChild(c){ this.children.push(c); } };
const rows = [];
global.document = {
  getElementById: id => els[id] || makeEl(id),
  querySelector: sel => {
    if (sel === 'input[name="model"]:checked') return { value: modelVal };
    if (sel === '#uetable tbody') return tbody;
    return null;
  },
  querySelectorAll: sel => sel === 'input[name="model"]' ? [{addEventListener:()=>{}},{addEventListener:()=>{}},{addEventListener:()=>{}}] : [],
  createElement: tag => ({ tag, innerHTML: '', children: [], appendChild(){}, set innerHTML(v){ this._h=v; rows.push(v); }, get innerHTML(){ return this._h||''; } }),
};
global.requestAnimationFrame = () => {};
global.window = global;
function runWith(m) {
  rows.length = 0; modelVal = m;
  new Function(scripts.join('\n'))();
  const last = rows.slice(-6).map(r => [...r.matchAll(/<td>(.*?)<\/td>/g)].map(x => x[1]));
  console.log('---', m, '--- status:', els.status.textContent);
  last.forEach(tds => console.log(' ', tds[0], '| serving', tds[3], '| RSRP', tds[4], '| HO', tds[6]));
  return last.map(tds => parseFloat(tds[4]));
}
const g = runWith('3gpp');
const s = runWith('sionna');
const v = runWith('sionna_veg');
console.log('UE3 (should be -48.2 Sionna, -53.4 +trees):', s[2], v[2]);
console.log('UE1/2/4/5/6 veg==no-veg:', [0,1,3,4,5].every(i => s[i] === v[i]));
console.log('SMOKE TEST OK');
