#!/usr/bin/env node
// Smoke-test v6 artefact JS: stub a minimal DOM, run draw() in 3GPP and
// Sionna modes, and print the UE table + status. Catches syntax/runtime errors.
const fs = require('fs');
const html = fs.readFileSync('6g-ran-multicell-handoff-v6.html', 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
if (scripts.length < 2) { console.error('expected 2 script blocks, got', scripts.length); process.exit(1); }

function makeEl(id) {
  const el = { id, value: '3.5', textContent: '', innerHTML: '', style: {},
    disabled: false, checked: false,
    addEventListener: () => {}, getContext: () => ctxStub,
    querySelector: () => null, appendChild: () => {} };
  return el;
}
const ctxStub = new Proxy({}, { get: (t, k) => (k === 'canvas' ? {} : (() => {})),
  set: () => true });
const els = {};
['freq','morph','mimo','eirp','bw','houe','ax','ay','bx','by','cx','cy',
 'runBtn','animBtn','status','map','sionnaNote'].forEach(id => els[id] = makeEl(id));
els.freq.value='3.5'; els.morph.value='UMa'; els.mimo.value='4'; els.eirp.value='47';
els.bw.value='100'; els.houe.value='all';
els.ax.value='250'; els.ay.value='250'; els.bx.value='750'; els.by.value='250';
els.cx.value='500'; els.cy.value='750'; els.map.width=600; els.map.height=600;
let modelVal = '3gpp';
const tbody = { innerHTML: '', children: [], appendChild(c){ this.children.push(c); } };
const rows = [];
global.document = {
  getElementById: id => els[id] || makeEl(id),
  querySelector: sel => {
    if (sel === 'input[name="model"]:checked') return { value: modelVal };
    if (sel === '#uetable tbody') return tbody;
    return null;
  },
  querySelectorAll: sel => sel === 'input[name="model"]' ? [{addEventListener:()=>{}},{addEventListener:()=>{}}] : [],
  createElement: tag => ({ tag, innerHTML: '', children: [], appendChild(){}, set innerHTML(v){ this._h=v; rows.push(v); }, get innerHTML(){ return this._h||''; } }),
};
global.requestAnimationFrame = () => {};
global.window = global;

// run both script blocks in ONE scope (as a browser does across <script> tags)
new Function(scripts.join('\n'))();
// after load, draw() ran once (3GPP). Capture table rows, then switch to Sionna.
function tableSummary(label) {
  console.log('---', label, '---');
  console.log('status:', els.status.textContent);
  console.log('rows:', rows.length);
  rows.slice(-6).forEach(r => {
    const tds = [...r.matchAll(/<td>(.*?)<\/td>/g)].map(m => m[1]);
    console.log(' ', tds[0], '| serving', tds[3], '| RSRP', tds[4], '| 2nd/diff', tds[5], '| HO', tds[6]);
  });
}
tableSummary('3GPP default');
// switch to Sionna: re-run the model-change handler by calling draw() via the
// exposed scope is not possible (Function scope) -- instead re-eval with modelVal changed
rows.length = 0;
modelVal = 'sionna';
// The script's functions live inside the Function scope; re-run whole script
// with Sionna selected so initial draw() uses Sionna.
new Function(scripts.join('\n'))();
tableSummary('Sionna (reloaded with radio=Sionna)');
// sanity: Sionna RSRPs must differ from 3GPP and include 'no ray' or weaker values
const sionnaRows = rows.slice(-6).map(r => [...r.matchAll(/<td>(.*?)<\/td>/g)].map(m => m[1])[4]);
console.log('Sionna RSRPs:', sionnaRows.join(', '));
console.log('SMOKE TEST OK');
