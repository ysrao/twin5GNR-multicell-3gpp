#!/usr/bin/env python3
"""compare_28.py - 28 GHz small cells: 3GPP (modelled) vs Sionna ray-traced
no-veg vs Sionna + trees (P.833, surveyed) vs Sionna + trees (LiDAR CHM
sensitivity, upper bound).

Reads results_28ghz_smallcell_street.npz (post-processed: rsrp_tilt4,
(625,16,3), tilt 4 deg) and veg_depth_28ghz.npz.
Foliage: P.833-10 Eq.(1) at 28 GHz (gamma,Am)=(2.20,50) INTERPOLATED/
ASSUMED, uncalibrated; phi=1 LOS / 0 non-LOS (as in v7 compare_veg.py).
Headline veg = surveyed-tree crown discs; LiDAR CHM = sensitivity only
(v7: CHM overstates depth ~10x, saturates A_ev at 28 GHz -- see notes).
3GPP: UMi LOS (correct 3GPP model for street-level small cells)
  32.4 + 21*log10(d) + 20*log10(28), EIRP 40 dBm, sector gain
  15 - min(12*(diff/65)^2, 25) dBi, sectors 0/120/240 deg in artefact
  grid coords, d>=10 m. UMa LOS shown as a second modelled baseline
  for continuity with v5. Both are LOS-only upper bounds (no shadowing).
Grid mapping (artefact, north-up): gx = enu_x + 500, gy = 500 - enu_y.
Outputs comparison_28ghz.json + results_28ghz_veg.npz.
Provenance: Sionna = ray-traced/simulated on Vexcel mesh; 3GPP = modelled;
veg = P.833 modelled, never measured.
"""
import json, math
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
D = dict(np.load(f'{ROOT}/results_28ghz_smallcell_street.npz', allow_pickle=True))
xs, ys = D['xs'], D['ys']
rsrp = D['rsrp_tilt4']            # (625,16,3)
los = D['los_tx']                 # (625,16)
pts = D['rx_xyz']
moved = D['moved']
V = dict(np.load(f'{ROOT}/veg_depth_28ghz.npz', allow_pickle=True))
GAMMA, AM = 2.20, 50.0
phi = np.where(los, 1.0, 0.0)

def apply_veg(a_ev):
    adj = np.where(a_ev > 0, 10 * np.log10(1 - phi + phi * 10 ** (-a_ev / 10)), 0.0)
    return np.where(np.isnan(rsrp), np.nan, (rsrp + adj[:, :, None]).astype(np.float32)), adj

rsrp_srv, adj_srv = apply_veg(V['a_ev_surveyed'])
rsrp_chm, adj_chm = apply_veg(V['a_ev_chm'])

# --- 3GPP on the same points, artefact grid coords ---
gx = pts[:, 0] + 500.0; gy = 500.0 - pts[:, 1]
GRID_POS = (125., 375., 625., 875.)
TOWERS = [(f'S{r}{c}', x, y) for r, y in enumerate((875., 625., 375., 125.))
          for c, x in enumerate(GRID_POS)]
# note: grid y = 500 - enu_y, so enu_y -375 -> gy 875, etc. Order matches
# TOWERS in rt_28ghz_smallcell.py (row-major over enu_y ascending).
def sector_gain(az_deg, x, y, tx, ty):
    ang = math.degrees(math.atan2(y - ty, x - tx))
    diff = abs((ang - az_deg + 180) % 360 - 180)
    return 15 - min(12 * (diff / 65.0) ** 2, 25)

def pl_umi(d):
    return 32.4 + 21 * math.log10(max(d, 10.0)) + 20 * math.log10(28.0)
def pl_uma(d):
    return 28.0 + 22 * math.log10(max(d, 10.0)) + 20 * math.log10(28.0)

g_umi = np.zeros((625, 16, 3)); g_uma = np.zeros((625, 16, 3))
for ti, (nm, tx, ty) in enumerate(TOWERS):
    for si, az in enumerate((0, 120, 240)):
        for i in range(625):
            d = math.hypot(gx[i] - tx, gy[i] - ty)
            g_umi[i, ti, si] = 40 + sector_gain(az, gx[i], gy[i], tx, ty) - pl_umi(d)
            g_uma[i, ti, si] = 40 + sector_gain(az, gx[i], gy[i], tx, ty) - pl_uma(d)

def ho_frac(r):
    # HO region: cells where the best and 2nd-best sectors are <3 dB apart.
    # NaN-aware: only cells with >=2 valid sector values can be in the HO
    # region. (Earlier version sorted with NaNs last, so any cell with a
    # NaN sector could never count -- it returned 0.0% for Sionna here.)
    flat = r.reshape(625, -1)
    nvalid = np.sum(~np.isnan(flat), axis=1)
    srt = np.sort(np.where(np.isnan(flat), -np.inf, flat), axis=1)
    return float(np.mean((nvalid >= 2) & ((srt[:, -1] - srt[:, -2]) < 3.0)) * 100)

def stats(name, r):
    best = np.nanmax(np.nanmax(r, axis=2), axis=1)
    best_tx = np.nanmax(r, axis=2)
    idx = np.where(np.isnan(best_tx).all(axis=1), -1,
                   np.nanargmax(np.where(np.isnan(best_tx), -np.inf, best_tx), axis=1))
    print(f"{name}: coverage {np.mean(best >= -90) * 100:.1f}%  median {np.nanmedian(best):.1f} dBm  "
          f"p10 {np.nanpercentile(best, 10):.1f}  p90 {np.nanpercentile(best, 90):.1f}  HO {ho_frac(r):.1f}%  "
          f"no-path {np.isnan(best).mean() * 100:.1f}%")
    return best, idx

print("=== 28 GHz, 16 small cells (250 m, 8 m AGL, EIRP 40 dBm), street 1.5 m, tilt 4 deg, 625 cells at 40 m ===")
b_umi, i_umi = stats('3GPP UMi LOS modelled      ', g_umi)
b_uma, i_uma = stats('3GPP UMa LOS modelled      ', g_uma)
b_s, i_s = stats('Sionna no-veg ray-traced ', rsrp)
b_v, i_v = stats('Sionna + trees (surveyed)', rsrp_srv)
b_h, i_h = stats('Sionna + trees (CHM sens.)', rsrp_chm)
print(f"LOS to >=1 small cell (Sionna): {los.any(axis=1).mean() * 100:.1f}%  "
      f"per-TX LOS median {np.median(los.mean(axis=0)) * 100:.1f}%  "
      f"moved (nudged out of building): {np.mean(moved == 1) * 100:.1f}%")
print(f"veg effect (surveyed): median delta {np.nanmedian(b_v - b_s):+.1f} dB  mean {np.nanmean(b_v - b_s):+.2f} dB  "
      f"cells with delta < -1 dB: {np.mean((b_v - b_s) < -1) * 100:.1f}%  max loss {np.nanmin(b_v - b_s):.1f} dB")
print(f"veg effect (CHM sens.): median delta {np.nanmedian(b_h - b_s):+.1f} dB  mean {np.nanmean(b_h - b_s):+.2f} dB  "
      f"cells with delta < -1 dB: {np.mean((b_h - b_s) < -1) * 100:.1f}%  max loss {np.nanmin(b_h - b_s):.1f} dB")
print(f"best-server agreement: Sionna+veg vs Sionna no-veg {(i_v == i_s).mean() * 100:.1f}%  "
      f"Sionna vs 3GPP UMi {(i_s == i_umi).mean() * 100:.1f}%")
print(f"depth surveyed: mean {V['depth_surveyed'].mean():.2f} m  pairs>0 {(V['depth_surveyed'] > 0).mean() * 100:.1f}%  "
      f"A_ev mean {V['a_ev_surveyed'].mean():.2f} dB  max {V['a_ev_surveyed'].max():.2f} dB")
print(f"depth CHM: mean {V['depth_chm'].mean():.2f} m  pairs>0 {(V['depth_chm'] > 0).mean() * 100:.1f}%  "
      f"A_ev mean {V['a_ev_chm'].mean():.2f} dB  max {V['a_ev_chm'].max():.2f} dB")
print("=== per-TX coverage (Sionna, best sector) ===")
for ti in range(16):
    bt = np.nanmax(rsrp[:, ti, :], axis=1)
    print(f"  TX {TOWERS[ti][0]}: cov {np.mean(bt >= -90) * 100:.1f}%  median {np.nanmedian(bt):.1f} dBm  LOS {los[:, ti].mean() * 100:.1f}%")
print("=== UEs (nearest grid cell; v4 defaults) ===")
UES = [(300, 400), (200, 600), (600, 500), (400, 200), (800, 700), (100, 100)]
for ui, (ux, uy) in enumerate(UES):
    enu_x, enu_y = ux - 500, 500 - uy
    ci = int(np.argmin(np.abs(xs - enu_x))); ri = int(np.argmin(np.abs(ys - enu_y)))
    idx = ri * 25 + ci
    print(f"  UE{ui+1} ({ux},{uy}): UMi {np.nanmax(g_umi[idx]):.1f}  Sionna {np.nanmax(rsrp[idx]):.1f}  "
          f"+trees {np.nanmax(rsrp_srv[idx]):.1f} (delta {np.nanmax(rsrp_srv[idx]) - np.nanmax(rsrp[idx]):+.1f})  "
          f"CHM {np.nanmax(rsrp_chm[idx]):.1f}  LOS {los[idx].any()}")

def _s(best, idx, r):
    return dict(coverage_ge_minus90_pct=round(float(np.mean(best >= -90) * 100), 1),
                median_rsrp_dbm=round(float(np.nanmedian(best)), 1),
                ho_region_pct=round(ho_frac(r), 1),
                no_path_pct=round(float(np.isnan(best).mean() * 100), 1))
out = dict(
    n_cells=625, grid='25x25, 40 m, street 1.5 m', freq_ghz=28.0, tilt_deg=4,
    tx='16 small cells, 4x4, 250 m spacing, 8 m AGL, EIRP 40 dBm',
    gpp_umi=_s(b_umi, i_umi, g_umi),
    gpp_uma=_s(b_uma, i_uma, g_uma),
    sionna=dict(**_s(b_s, i_s, rsrp),
                los_any_tx_pct=round(float(los.any(axis=1).mean() * 100), 1)),
    sionna_veg=dict(**_s(b_v, i_v, rsrp_srv),
                    median_delta_db=round(float(np.nanmedian(b_v - b_s)), 1),
                    mean_delta_db=round(float(np.nanmean(b_v - b_s)), 2),
                    cells_below_minus1db_pct=round(float(np.mean((b_v - b_s) < -1) * 100), 1),
                    max_loss_db=round(float(np.nanmin(b_v - b_s)), 1),
                    depth_mean_m=round(float(V['depth_surveyed'].mean()), 2),
                    depth_pairs_gt0_pct=round(float((V['depth_surveyed'] > 0).mean() * 100), 1),
                    a_ev_mean_db=round(float(V['a_ev_surveyed'].mean()), 2)),
    sionna_chm=dict(**_s(b_h, i_h, rsrp_chm),
                    median_delta_db=round(float(np.nanmedian(b_h - b_s)), 1),
                    mean_delta_db=round(float(np.nanmean(b_h - b_s)), 2),
                    cells_below_minus1db_pct=round(float(np.mean((b_h - b_s) < -1) * 100), 1),
                    max_loss_db=round(float(np.nanmin(b_h - b_s)), 1),
                    depth_mean_m=round(float(V['depth_chm'].mean()), 2),
                    a_ev_mean_db=round(float(V['a_ev_chm'].mean()), 2)),
    diff_median_db=round(float(np.nanmedian(b_s - b_umi)), 1),
    best_server_agreement_sionna_vs_umi_pct=round(float((i_s == i_umi).mean() * 100), 1),
    veg_server_agreement_pct=round(float((i_v == i_s).mean() * 100), 1),
)
json.dump(out, open(f'{ROOT}/comparison_28ghz.json', 'w'), indent=1)
np.savez_compressed(f'{ROOT}/results_28ghz_veg.npz', rsrp_veg_tilt4=rsrp_srv, rsrp_chm_tilt4=rsrp_chm,
                    depth_surveyed=V['depth_surveyed'], depth_chm=V['depth_chm'],
                    a_ev_surveyed=V['a_ev_surveyed'], a_ev_chm=V['a_ev_chm'], xs=xs, ys=ys)
np.savez_compressed(f'{ROOT}/results_28ghz_gpp.npz', gpp_umi_tilt4=g_umi, gpp_uma_tilt4=g_uma, xs=xs, ys=ys)
print(json.dumps(out, indent=1))
