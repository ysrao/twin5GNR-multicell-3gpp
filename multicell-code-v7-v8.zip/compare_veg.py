#!/usr/bin/env python3
"""compare_veg.py - 3GPP vs Sionna no-veg vs Sionna + trees (surveyed) vs hybrid sensitivity.
Reads results_multicell_f3600_street.npz (v5, rsrp_tilt4) and
veg_layer_40m.npz (depth_surveyed) + veg_layer_40m_hybrid.npz (depth_total).
Foliage: P.833-10 Eq.(1) 3.6 GHz (gamma,Am)=(0.55,38) INTERPOLATED/ASSUMED;
phi=1 LOS / 0 non-LOS (SF single-tower: LOS median phi 0.968).
Headline veg layer = SURVEYED trees (exact positions, crown discs, v5.1
method). LiDAR CHM layers are sensitivity only: the OSM-masked CHM
overstates depth ~10x vs surveyed discs (43.5 m vs 4.07 m mean) because
it has no crown bottom and counts clutter/unmapped buildings — see notes.
Outputs comparison_veg.json + prints numbers for the v7 note.
"""
import json, math
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
D = dict(np.load(f'{ROOT}/results_multicell_f3600_street.npz', allow_pickle=True))
xs, ys = D['xs'], D['ys']
rsrp = D['rsrp_tilt4']            # (625,3,3)
los = D['los_tx']
pts = D['rx_xyz']
V = dict(np.load(f'{ROOT}/veg_layer_40m.npz', allow_pickle=True))
H = dict(np.load(f'{ROOT}/veg_layer_40m_hybrid.npz', allow_pickle=True))
GAMMA, AM = 0.55, 38.0
phi = np.where(los, 1.0, 0.0)

def apply_veg(depth):
    a = np.where(depth > 0, AM * (1 - np.exp(-depth * GAMMA / AM)), 0.0)
    adj = np.where(a > 0, 10 * np.log10(1 - phi + phi * 10 ** (-a / 10)), 0.0)
    return np.where(np.isnan(rsrp), np.nan, (rsrp + adj[:, :, None]).astype(np.float32)), a, adj

rsrp_srv, a_srv, adj_srv = apply_veg(V['depth_surveyed'])
rsrp_hyb, a_hyb, adj_hyb = apply_veg(H['depth_total'])

# 3GPP on same points (same formula as compare.py)
gx = pts[:, 0] + 500.0; gy = 500.0 - pts[:, 1]
TOWERS = {'A': (250., 250.), 'B': (750., 250.), 'C': (500., 750.)}
def sector_gain(az_deg, x, y, tx, ty):
    ang = math.degrees(math.atan2(y - ty, x - tx))
    diff = abs((ang - az_deg + 180) % 360 - 180)
    return 15 - min(12 * (diff / 65.0) ** 2, 25)
def pl_uma(d):
    return 28.0 + 22 * math.log10(max(d, 10.0)) + 20 * math.log10(3.6)
g3 = np.zeros((625, 3, 3))
for ti, (nm, (tx, ty)) in enumerate(TOWERS.items()):
    for si, az in enumerate((0, 120, 240)):
        for i in range(625):
            d = math.hypot(gx[i] - tx, gy[i] - ty)
            g3[i, ti, si] = 47 + sector_gain(az, gx[i], gy[i], tx, ty) - pl_uma(d)

def ho_frac(r):
    flat = np.sort(r.reshape(625, -1), axis=1)
    return float(np.mean((flat[:, -1] - flat[:, -2]) < 3.0) * 100)

def stats(name, r):
    best = np.nanmax(np.nanmax(r, axis=2), axis=1)
    best_tx = np.nanmax(r, axis=2)
    idx = np.where(np.isnan(best_tx).all(axis=1), -1,
                   np.nanargmax(np.where(np.isnan(best_tx), -np.inf, best_tx), axis=1))
    print(f"{name}: coverage {np.mean(best >= -90) * 100:.1f}%  median {np.nanmedian(best):.1f} dBm  "
          f"p10 {np.nanpercentile(best, 10):.1f}  HO {ho_frac(r):.1f}%")
    return best, idx

print("=== 3.6 GHz, street 1.5 m, tilt 4 deg, 625 cells at 40 m ===")
b_g, i_g = stats('3GPP UMa modelled        ', g3)
b_s, i_s = stats('Sionna no-veg ray-traced ', rsrp)
b_v, i_v = stats('Sionna + trees (surveyed)', rsrp_srv)
b_h, i_h = stats('Sionna + hybrid (sens.)  ', rsrp_hyb)
print(f"veg effect (surveyed): median delta {np.nanmedian(b_v - b_s):+.1f} dB  mean {np.nanmean(b_v - b_s):+.2f} dB  "
      f"cells with delta < -1 dB: {np.mean((b_v - b_s) < -1) * 100:.1f}%  max loss {np.nanmin(b_v - b_s):.1f} dB")
print(f"veg effect (hybrid sens.): median delta {np.nanmedian(b_h - b_s):+.1f} dB  mean {np.nanmean(b_h - b_s):+.2f} dB  "
      f"cells with delta < -1 dB: {np.mean((b_h - b_s) < -1) * 100:.1f}%")
print(f"best-server agreement: Sionna+veg vs Sionna no-veg {(i_v == i_s).mean() * 100:.1f}%  "
      f"Sionna+veg vs 3GPP {(i_v == i_g).mean() * 100:.1f}%")
print(f"depth surveyed: mean {V['depth_surveyed'].mean():.2f} m  pairs>0 {(V['depth_surveyed'] > 0).mean() * 100:.1f}%  "
      f"A_ev mean {a_srv.mean():.2f} dB  max {a_srv.max():.2f} dB")
print(f"depth hybrid: mean {H['depth_total'].mean():.2f} m  pairs>0 {(H['depth_total'] > 0).mean() * 100:.1f}%  "
      f"A_ev mean {a_hyb.mean():.2f} dB  max {a_hyb.max():.2f} dB")
print("=== UEs (nearest grid cell) ===")
UES = [(300, 400), (200, 600), (600, 500), (400, 200), (800, 700), (100, 100)]
for ui, (ux, uy) in enumerate(UES):
    enu_x, enu_y = ux - 500, 500 - uy
    ci = int(np.argmin(np.abs(xs - enu_x))); ri = int(np.argmin(np.abs(ys - enu_y)))
    idx = ri * 25 + ci
    print(f"  UE{ui+1}: 3GPP {np.nanmax(g3[idx]):.1f}  Sionna {np.nanmax(rsrp[idx]):.1f}  "
          f"+trees {np.nanmax(rsrp_srv[idx]):.1f} (delta {np.nanmax(rsrp_srv[idx]) - np.nanmax(rsrp[idx]):+.1f})  "
          f"hybrid {np.nanmax(rsrp_hyb[idx]):.1f}")
out = dict(
    n_cells=625, grid='25x25, 40 m, street 1.5 m', freq_ghz=3.6, tilt_deg=4,
    gpp=dict(coverage_ge_minus90_pct=round(float(np.mean(b_g >= -90) * 100), 1),
             median_rsrp_dbm=round(float(np.nanmedian(b_g)), 1), ho_region_pct=round(ho_frac(g3), 1)),
    sionna=dict(coverage_ge_minus90_pct=round(float(np.mean(b_s >= -90) * 100), 1),
                median_rsrp_dbm=round(float(np.nanmedian(b_s)), 1), ho_region_pct=round(ho_frac(rsrp), 1),
                no_path_pct=round(float(np.isnan(b_s).mean() * 100), 1),
                los_any_tx_pct=round(float(los.any(axis=1).mean() * 100), 1)),
    sionna_veg=dict(coverage_ge_minus90_pct=round(float(np.mean(b_v >= -90) * 100), 1),
                    median_rsrp_dbm=round(float(np.nanmedian(b_v)), 1), ho_region_pct=round(ho_frac(rsrp_srv), 1),
                    median_delta_db=round(float(np.nanmedian(b_v - b_s)), 1),
                    mean_delta_db=round(float(np.nanmean(b_v - b_s)), 2),
                    cells_below_minus1db_pct=round(float(np.mean((b_v - b_s) < -1) * 100), 1),
                    max_loss_db=round(float(np.nanmin(b_v - b_s)), 1),
                    depth_mean_m=round(float(V['depth_surveyed'].mean()), 2),
                    depth_pairs_gt0_pct=round(float((V['depth_surveyed'] > 0).mean() * 100), 1),
                    a_ev_mean_db=round(float(a_srv.mean()), 2)),
    sionna_hybrid=dict(coverage_ge_minus90_pct=round(float(np.mean(b_h >= -90) * 100), 1),
                       median_rsrp_dbm=round(float(np.nanmedian(b_h)), 1), ho_region_pct=round(ho_frac(rsrp_hyb), 1),
                       median_delta_db=round(float(np.nanmedian(b_h - b_s)), 1),
                       mean_delta_db=round(float(np.nanmean(b_h - b_s)), 2),
                       cells_below_minus1db_pct=round(float(np.mean((b_h - b_s) < -1) * 100), 1),
                       depth_mean_m=round(float(H['depth_total'].mean()), 2)),
    diff_median_db=round(float(np.nanmedian(b_s - b_g)), 1),
    best_server_agreement_pct=round(float((i_s == i_g).mean() * 100), 1),
    veg_server_agreement_pct=round(float((i_v == i_s).mean() * 100), 1),
)
json.dump(out, open(f'{ROOT}/comparison_veg.json', 'w'), indent=1)
np.savez_compressed(f'{ROOT}/results_veg_40m.npz', rsrp_veg_tilt4=rsrp_srv, rsrp_hybrid_tilt4=rsrp_hyb,
                    depth_surveyed=V['depth_surveyed'], depth_total=H['depth_total'],
                    a_ev_surveyed=a_srv, a_ev_hybrid=a_hyb, xs=xs, ys=ys)
print(json.dumps(out, indent=1))
