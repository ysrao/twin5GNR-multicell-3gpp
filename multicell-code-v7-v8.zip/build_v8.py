#!/usr/bin/env python3
"""build_v8.py - build the v8 handoff artefact HTML (28 GHz small cells) from v7.

Reads:
  6g-ran-multicell-handoff-v7.html (base; v5/v7 macro artefact)
  results_28ghz_smallcell_street.npz (rsrp_tilt4, (625,16,3), Sionna no-veg)
  results_28ghz_veg.npz (rsrp_veg_tilt4 surveyed P.833, rsrp_chm_tilt4)
  results_28ghz_gpp.npz (gpp_umi_tilt4, gpp_uma_tilt4)
  comparison_28ghz.json (stats for the comparison note)
Writes:
  6g-ran-multicell-handoff-v8.html (self-contained; 28 GHz small cells)
Modes (all data-driven, 16 small cells x 3 sectors, fixed positions):
  gpp28      3GPP UMi LOS, modelled, 28 GHz
  sionna28   Sionna ray-traced, simulated, 28 GHz, no vegetation
  sionna28v  Sionna + trees (surveyed trees, P.833), simulated, 28 GHz
The v4/v5/v7 macro modes are NOT in v8: v8 is the small-cell artefact.
The LiDAR-CHM sensitivity is reported in the note only, not embedded.
"""
import json, math, re
import numpy as np

ROOT = '/home/hatch/workspace/twin5gnr-work/twin5GNR-multicell-sionna'
S = dict(np.load(f'{ROOT}/results_28ghz_smallcell_street.npz', allow_pickle=True))
V = dict(np.load(f'{ROOT}/results_28ghz_veg.npz', allow_pickle=True))
G = dict(np.load(f'{ROOT}/results_28ghz_gpp.npz', allow_pickle=True))
CMP = json.load(open(f'{ROOT}/comparison_28ghz.json'))
xs, ys = [float(v) for v in S['xs']], [float(v) for v in S['ys']]
NTX = 16

def r(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(v) else round(v, 1)

def pack(arr):
    return {'xs': xs, 'ys': ys,
            'rsrp': [[[r(arr[i, t, s]) for s in range(3)] for t in range(NTX)] for i in range(625)]}

gpp_json = json.dumps(pack(G['gpp_umi_tilt4']), separators=(',', ':'))
s28_json = json.dumps(pack(S['rsrp_tilt4']), separators=(',', ':'))
veg_json = json.dumps(pack(V['rsrp_veg_tilt4']), separators=(',', ':'))

html = open(f'{ROOT}/6g-ran-multicell-handoff-v7.html').read()

# --- 1. title / header / version stamp ---
html = html.replace('<title>6G RAN Multi-Cell Handoff Artefact v7 — 3GPP + Sionna + trees</title>',
                    '<title>6G RAN Multi-Cell Handoff Artefact v8 — 28 GHz small cells</title>')
html = html.replace('<h1>6G RAN Multi-Cell Handoff Artefact v7 — 10 Nov 2026</h1>',
                    '<h1>6G RAN Multi-Cell Handoff Artefact v8 — 28 GHz small cells — 10 Nov 2026</h1>')
html = html.replace('Version inside the file: v7.', 'Version inside the file: v8.')

# --- 2. model radios: replace the macro radios with the three 28 GHz small-cell modes ---
m = re.search(r'<b>Model:</b>.*?(?= —\s*toggle to compare)', html, flags=re.S)
assert m, 'model radio block not found'
html = html[:m.start()] + ('<b>Model:</b> '
    '<label><input type="radio" name="model" value="gpp28" checked> 3GPP UMi 28 GHz (modelled)</label> '
    '<label><input type="radio" name="model" value="sionna28"> Sionna ray-traced 28 GHz (simulated)</label> '
    '<label><input type="radio" name="model" value="sionna28v"> Sionna + trees 28 GHz (simulated, surveyed trees + ITU-R P.833)</label>') + html[m.end():]
html = html.replace('toggle to compare the same 3 towers on the real 3D city mesh versus the 3GPP formula, with and without vegetation.',
                    'toggle to compare 16 small cells (250 m, 8 m lamppost height) on the real 3D city mesh versus the 3GPP formula, with and without vegetation.')
html = html.replace('<b>Map:</b> San Francisco 1 km × 1 km, downtown tile (centre 37.801105, −122.404175), 3 towers × 3 sectors.',
                    '<b>Map:</b> San Francisco 1 km × 1 km, downtown tile (centre 37.801105, −122.404175), 16 small cells × 3 sectors (250 m spacing, 8 m AGL, EIRP 40 dBm).')
html = html.replace('Frequency, morphology and MIMO selectors apply to the 3GPP model only — the Sionna data are 3.6 GHz.',
                    'Frequency and morphology selectors do not apply in v8 — all three modes are 28 GHz data for the same 16 small cells. MIMO and bandwidth still feed the capacity table.')
html = html.replace('ray-traced RSRP on the Vexcel SF 3D mesh (Sionna 2.2.0, max depth 3, '
                    'LOS + specular + diffuse + diffraction, ITU concrete, scattering 0.3, tilt 4°, 25×25 grid at 40 m, street level 1.5 m, '
                    'EIRP 47 dBm).',
                    'ray-traced RSRP on the Vexcel SF 3D mesh (Sionna 2.2.0, max depth 3, '
                    'LOS + specular + diffuse + diffraction, ITU concrete, scattering 0.3, tilt 4°, 25×25 grid at 40 m, street level 1.5 m, '
                    'EIRP 40 dBm, 16 small cells at 8 m AGL).')
html = html.replace('Cell locations are fixed in Sionna mode (they are the ray-traced tower positions).',
                    'Cell locations are fixed in v8 (the 16 ray-traced small-cell positions).')
html = html.replace('<b>Sionna + trees mode:</b> same ray-traced RSRP as Sionna mode, '
                    'with ITU-R P.833-10 foliage loss applied per tower–receiver path from the 1,919 surveyed DataSF street trees '
                    '(exact positions; crown size assumed from trunk diameter, P.833 (gamma, Am) = (0.55, 38) at 3.6 GHz interpolated/assumed, '
                    'uncalibrated).',
                    '<b>Sionna + trees mode:</b> same ray-traced RSRP as Sionna mode, '
                    'with ITU-R P.833-10 foliage loss applied per small-cell–receiver path from the 1,919 surveyed DataSF street trees '
                    '(exact positions; crown size assumed from trunk diameter, P.833 (gamma, Am) = (2.20, 50) at 28 GHz interpolated/assumed, '
                    'uncalibrated).')
html = html.replace('At 3.6 GHz the effect is small — see the comparison note — because P.833 loss at 3.6 GHz saturates low; '
                    'the same trees matter far more at 28 GHz.',
                    'At 28 GHz the effect is large — see the comparison note — because the low 8 m cells put the ray inside the crown band for most of its path.')

# --- 3. footer ---
old_footer = re.search(r'<p>6G RAN Multi-Cell Handoff Artefact v7.*?</p>', html, flags=re.S).group(0)
new_footer = (
    '<p>6G RAN Multi-Cell Handoff Artefact v8 — 10 Nov 2026 — 28 GHz small-cell version (draft), '
    'published at https://ysrao.github.io/twin5GNR-multicell-3gpp/. v8: 16 small cells (250 m spacing, 8 m AGL, EIRP 40 dBm) '
    'ray-traced at 28 GHz on the Vexcel SF 3D mesh (Sionna 2.2.0, 25×25 grid at 40 m, street 1.5 m), with and without surveyed-tree '
    'P.833 foliage, against a 3GPP UMi 28 GHz model. v7: Sionna + trees at 3.6 GHz (macro). v6: 10 m Sionna grid (separate run). '
    'v5: Sionna 2.2.0 ray tracing on the Vexcel SF 3D mesh (3 macro towers at 30 m AGL, 3.6 GHz), with a 3GPP / Sionna toggle. '
    'v4: ICI degradation added, DL and UL separate. v3: 3 towers × 3 sectors = 9 sectors.</p>')
html = html.replace(old_footer, new_footer, 1)

# --- 4. comparison note: replace the v7 note div ---
c = CMP['sionna']; g = CMP['gpp_umi']; v = CMP['sionna_veg']; h = CMP['sionna_chm']
note = f'''<div class="note"><b>3GPP UMi vs Sionna vs Sionna + trees — 28 GHz small cells (ray-traced / simulated, 28 GHz, street 1.5 m, 625 cells at 40 m, 16 cells at 8 m AGL, EIRP 40 dBm):</b>
<ul>
<li><b>Coverage (RSRP ≥ −90 dBm):</b> 3GPP UMi {g['coverage_ge_minus90_pct']}% vs Sionna {c['coverage_ge_minus90_pct']}% vs Sionna + trees {v['coverage_ge_minus90_pct']}%.</li>
<li><b>Median best-server RSRP:</b> 3GPP UMi {g['median_rsrp_dbm']} dBm vs Sionna {c['median_rsrp_dbm']} dBm vs Sionna + trees {v['median_rsrp_dbm']} dBm (Sionna − 3GPP UMi median {CMP['diff_median_db']} dB). LOS to at least one small cell: {c['los_any_tx_pct']}% of cells; no ray at all: {c['no_path_pct']}%.</li>
<li><b>Where trees bite at 28 GHz:</b> median change {v['median_delta_db']:+.1f} dB, mean {v['mean_delta_db']:+.2f} dB; {v['cells_below_minus1db_pct']}% of cells lose more than 1 dB to foliage; worst cell loses {v['max_loss_db']:.1f} dB. Best server changes on {(100 - CMP['veg_server_agreement_pct']):.1f}% of cells. Handoff region (&lt;3 dB, sector level): 3GPP UMi {g['ho_region_pct']}% vs Sionna {c['ho_region_pct']}% vs Sionna + trees {v['ho_region_pct']}%.</li>
<li><b>Why trees matter here and not at 3.6 GHz:</b> the 8 m cells put the ray inside the tree-crown band (2–12 m) for most of its 250 m path, so mean foliage depth is {v['depth_mean_m']:.2f} m (vs 4.07 m for the 30 m macros at 3.6 GHz), and P.833 at 28 GHz has (gamma, Am) = (2.20, 50), so the mean foliage loss is {v['a_ev_mean_db']:.2f} dB. This matches the Nov 5 surveyed-tree verdict: vegetation matters at 28 GHz, street level, 100–500 m.</li>
<li><b>LiDAR sensitivity (not in the toggle):</b> the free USGS 3DEP canopy-height layer gives mean foliage depth {h['depth_mean_m']:.2f} m (mean P.833 loss {h['a_ev_mean_db']:.2f} dB, saturating at 50 dB) — an upper bound, because it has no crown bottom and counts clutter and unmapped buildings. Its median RSRP change is {h['median_delta_db']:+.1f} dB, mean {h['mean_delta_db']:+.2f} dB. The toggle uses the surveyed trees only; the LiDAR layer is reported here, not embedded.</li>
</ul>
Assumptions, stated: 16 small cells on a 4×4 grid, 250 m spacing, 8 m AGL (lamppost assumption); 3 sectors per cell (90°/210°/330° in ENU, as in v5 — real lamppost cells are often omni); 4×4 array (real 28 GHz arrays are often 8×8); EIRP 40 dBm; Sionna sectors as in v5; 3GPP sectors 0°/120°/240° in artefact grid coordinates. Foliage: P.833-10 Eq.(1), (gamma, Am) = (2.20, 50) at 28 GHz interpolated/assumed and uncalibrated; crown size assumed from trunk diameter; phi-weighted (LOS share 1 for LOS pairs, 0 for non-LOS). Sionna is a simulation on a 1 m-facet mesh with one material (ITU concrete) — it is not a measurement, and it does not include vehicles or indoor loss. The 3GPP UMi baseline is LOS-only (no shadowing), so it is an upper bound; UMa LOS is also computed in the comparison file.</div>'''
m = re.search(r'<div class="note"><b>3GPP vs Sionna vs Sionna \+ trees — what the toggle shows.*?</div>\n<table id="uetable">',
              html, flags=re.S)
assert m, 'v7 comparison note not found'
html = html[:m.start()] + note + '\n<table id="uetable">' + html[m.end():]

# --- 5. embed the three 28 GHz grids (replace the v5/v7 SIONNA consts) ---
m = re.search(r'const SIONNA=\{.*?\};', html, flags=re.S)
assert m, 'SIONNA const not found'
html = html[:m.start()] + 'const GPP28=' + gpp_json + ';\nconst SIONNA28=' + s28_json + ';\nconst SIONNA28V=' + veg_json + ';' + html[m.end():]
# drop the v7 veg const (superseded by SIONNA28V); the old rsrps() below
# still references SIONNA_VEG, so the full-name assert is at the end.
m = re.search(r'\nconst SIONNA_VEG=\{.*?\};', html, flags=re.S)
if m:
    html = html[:m.start()] + html[m.end():]
assert 'const SIONNA_VEG' not in html

# --- 6. JS: 16-tower list + data-driven rsrps() in all modes ---
PALETTE = ['#2f7fe0', '#e07f2f', '#7f2fe0', '#2fe07f', '#e02f7f', '#7f7f2f', '#2f7f7f', '#e02f2f']
GRID_POS = (125, 375, 625, 875)
TWS = []
for r, gy in enumerate((875, 625, 375, 125)):
    for c, gx in enumerate(GRID_POS):
        TWS.append("{name:'S%d%d',x:%d,y:%d,color:'%s'}" % (r, c, gx, gy, PALETTE[(r * 4 + c) % 8]))
TWS_JS = '[' + ','.join(TWS) + ']'

old_cell = '''function sionnaCell(x,y,grid){
 // artefact grid (north-up) -> ENU -> nearest 40 m grid point
 const ex=x-500, ey=500-y;
 let ci=0,ri=0,bd=1e9;
 for(let i=0;i<grid.xs.length;i++){ const d=Math.abs(grid.xs[i]-ex); if(d<bd){bd=d;ci=i;} }
 bd=1e9;
 for(let i=0;i<grid.ys.length;i++){ const d=Math.abs(grid.ys[i]-ey); if(d<bd){bd=d;ri=i;} }
 return grid.rsrp[ri*25+ci];
}
function isSionna(){ return model()==='sionna'||model()==='sionna_veg'; }'''
new_cell = '''function gridCell(x,y,grid){
 // artefact grid (north-up) -> ENU -> nearest 40 m grid point
 const ex=x-500, ey=500-y;
 let ci=0,ri=0,bd=1e9;
 for(let i=0;i<grid.xs.length;i++){ const d=Math.abs(grid.xs[i]-ex); if(d<bd){bd=d;ci=i;} }
 bd=1e9;
 for(let i=0;i<grid.ys.length;i++){ const d=Math.abs(grid.ys[i]-ey); if(d<bd){bd=d;ri=i;} }
 return grid.rsrp[ri*25+ci];
}
function isData28(){ return true; }
const TWS28=''' + TWS_JS + ''';'''
assert old_cell in html
html = html.replace(old_cell, new_cell, 1)

old_rsrps = re.search(r"function rsrps\(x,y\)\{.*?return out\.sort\(\(a,b\)=>b\.rsrp-a\.rsrp\);\n \}\n const f=\+document\.getElementById\('freq'\)\.value.*?\n\}\n", html, flags=re.S)
assert old_rsrps, 'rsrps() not found'
new_rsrps = '''function rsrps(x,y){
 const grid=(model()==='sionna28v')?SIONNA28V:(model()==='sionna28')?SIONNA28:GPP28;
 const cell=grid.rsrp ? gridCell(x,y,grid) : null;
 const out=[];
 TWS28.forEach((tw,ti)=>{
  [0,1,2].forEach(si=>{
   const v=cell?cell[ti][si]:null;
   out.push({cell:{name:tw.name+(si+1),tower:tw.name,az:[90,210,330][si],x:tw.x,y:tw.y,color:tw.color},rsrp:((v===null)||isNaN(v)?-999:v),d:Math.hypot(x-tw.x,y-tw.y)});
  });
 });
 return out.sort((a,b)=>b.rsrp-a.rsrp);
}
'''
html = html[:old_rsrps.start()] + new_rsrps + html[old_rsrps.end():]

# draw(): hatch + tower triangles use the 16-tower list; isSionna -> isData28
html = html.replace("if(isSionna() && r[0].rsrp<=-999){", "if(r[0].rsrp<=-999){", 1)
html = html.replace(" [...new Map(cells().map(c=>[c.tower,c])).values()].forEach(c=>{",
                    " TWS28.forEach(c=>{", 1)
html = html.replace("const fEff=isSionna()?3.6:f;", "const fEff=28;", 1)
html = html.replace("const ulRsrp = isSionna() ? (r[0].rsrp - 47 + 23) : (23 + sectorGain(r[0].cell, u.x, u.y) - plServ);",
                    "const ulRsrp = (r[0].rsrp - 40 + 23);", 1)
html = html.replace("(model()==='sionna'?'Sionna ray-traced 3.6 GHz':model()==='sionna_veg'?'Sionna + trees 3.6 GHz':'3GPP '+f+' GHz')",
                    "(model()==='sionna28'?'Sionna ray-traced 28 GHz':model()==='sionna28v'?'Sionna + trees 28 GHz':'3GPP UMi 28 GHz')", 1)
old_list = """ document.getElementById('sionnaNote').style.display=isSionna()?'block':'none';
 document.getElementById('vegNote').style.display=(model()==='sionna_veg')?'block':'none';
 ['ax','ay','bx','by','cx','cy'].forEach(id=>document.getElementById(id).disabled=isSionna());"""
new_list = """ document.getElementById('sionnaNote').style.display=(model()==='sionna28')?'block':'none';
 document.getElementById('vegNote').style.display=(model()==='sionna28v')?'block':'none';
 ['ax','ay','bx','by','cx','cy'].forEach(id=>document.getElementById(id).disabled=true);"""
assert old_list in html
html = html.replace(old_list, new_list, 1)
# cell location inputs disabled from the start (fixed small-cell positions)
html = html.replace("['ax','ay','bx','by','cx','cy'].forEach(id=>document.getElementById(id).addEventListener('input',markStale));",
                    "['ax','ay','bx','by','cx','cy'].forEach(id=>{document.getElementById(id).disabled=true;document.getElementById(id).addEventListener('input',markStale);});", 1)
# veg note id/text: it is shown only in sionna28v mode via the listener above
assert 'Version inside the file: v8.' in html
assert 'SIONNA28' in html and 'GPP28' in html
assert 'Version inside the file: v7.' not in html
assert 'SIONNA_VEG' not in html, 'stale SIONNA_VEG reference survives'
assert 'SIONNA=' not in html, 'stale v7 SIONNA const survives'
open(f'{ROOT}/6g-ran-multicell-handoff-v8.html', 'w').write(html)
print('wrote 6g-ran-multicell-handoff-v8.html', len(html), 'bytes; grids',
      len(gpp_json), len(s28_json), len(veg_json), 'bytes')
