#!/usr/bin/env python3
"""build_v6.py - build the v6 handoff artefact HTML from v5 + 10 m Sionna grids.

Reads:
  6g-ran-multicell-handoff-v5.html  (v5 source, 40 m Sionna data)
  results_multicell_f3600_street_10m.npz  (rsrp_tilt4, (10000,3,3))
  comparison_10m.json + comparison.json (v5 40 m stats, for the vs-v5 line)
Writes:
  6g-ran-multicell-handoff-v6.html  (self-contained, Sionna grids embedded)
Sionna data embedded as SIONNA = {xs, ys, rsrp: [cell][tx][sector]} rounded
to 0.1 dB, null = no ray. Grid: 100x100, 10 m, ENU, street 1.5 m.
Artefact mapping (north-up): gx = enu_x + 500, gy = 500 - enu_y.
"""
import json, math, re
import numpy as np

D = dict(np.load('results_multicell_f3600_street_10m.npz', allow_pickle=True))
CMP = json.load(open('comparison_10m.json'))
CMP5 = json.load(open('comparison.json'))
rsrp = D['rsrp_tilt4']  # (10000,3,3)
xs, ys = [float(v) for v in D['xs']], [float(v) for v in D['ys']]
assert len(xs) == 100 and len(ys) == 100 and rsrp.shape == (10000, 3, 3)

def r(x):
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(v) else round(v, 1)

sionna = {'xs': xs, 'ys': ys,
          'rsrp': [[[r(rsrp[i, t, s]) for s in range(3)] for t in range(3)] for i in range(10000)]}
sionna_json = json.dumps(sionna, separators=(',', ':'))

html = open('6g-ran-multicell-handoff-v5.html').read()

# --- 1. replace embedded Sionna data (index-based: const ... ; before </script>) ---
i0 = html.find('const SIONNA=')
assert i0 > 0
i1 = html.find('</script>', i0)
assert i1 > i0
html = html[:i0] + 'const SIONNA=' + sionna_json + ';\n' + html[i1:]

# --- 2. JS grid index: 25 -> 100 (sionnaCell) ---
assert 'ri*25+ci' in html
html = html.replace('ri*25+ci', 'ri*100+ci')
assert 'nearest 40 m grid point' in html
html = html.replace('nearest 40 m grid point', 'nearest 10 m grid point')

# --- 3. title / header / version stamp ---
html = html.replace('<title>6G RAN Multi-Cell Handoff Artefact v5 — 3GPP + Sionna</title>',
                    '<title>6G RAN Multi-Cell Handoff Artefact v6 — 3GPP + Sionna 10 m</title>')
html = html.replace('<h1>6G RAN Multi-Cell Handoff Artefact v5 — 9 Nov 2026</h1>',
                    '<h1>6G RAN Multi-Cell Handoff Artefact v6 — 9 Nov 2026</h1>')
assert 'Version inside the file: v5.' in html
html = html.replace('Version inside the file: v5.', 'Version inside the file: v6.')
assert '25×25 grid at 40 m, street level 1.5 m' in html
html = html.replace('25×25 grid at 40 m, street level 1.5 m',
                    '100×100 grid at 10 m, street level 1.5 m')

# --- 4. footer ---
old_footer = re.search(r'<p>6G RAN Multi-Cell Handoff Artefact v5.*?</p>', html, flags=re.S).group(0)
new_footer = (
    '<p>6G RAN Multi-Cell Handoff Artefact v6 — 9 Nov 2026 — 3GPP-model version plus Sionna ray-traced version, '
    'published at https://ysrao.github.io/twin5GNR-multicell-3gpp/. v6: Sionna 2.2.0 ray tracing on the Vexcel SF 3D mesh '
    '(downtown SF, 1 km², 3 towers at 30 m AGL, 3.6 GHz, 100×100 grid at 10 m, street 1.5 m), with a 3GPP / Sionna toggle. '
    'v5: same ray trace at 40 m (25×25 grid). '
    'v4: ICI degradation added, DL and UL separate. v3: 3 towers × 3 sectors = 9 sectors. '
    'HO is marked both between sectors on the same tower (intra-tower) and between different towers (inter-tower). '
    'v2 used 3 towers × 1 sector = 3 cells.</p>')
html = html.replace(old_footer, new_footer)

# --- 4b. table HO flag: a no-ray UE must not be flagged as handing over ---
old_ho = """  const diff=r[0].rsrp-r[1].rsrp; const thr=hoThreshold(u.speed);
  const hoType = diff<thr ? (r[0].cell.tower===r[1].cell.tower ? 'YES — Intra-tower sector HO' : 'YES — Inter-tower HO') : 'No';"""
new_ho = """  const diff=r[0].rsrp-r[1].rsrp; const thr=hoThreshold(u.speed);
  const hoType = (r[0].rsrp<=-999) ? 'No (no ray)' : (diff<thr ? (r[0].cell.tower===r[1].cell.tower ? 'YES — Intra-tower sector HO' : 'YES — Inter-tower HO') : 'No');"""
assert old_ho in html
html = html.replace(old_ho, new_ho, 1)

# --- 5. comparison note: replace the whole v5 note div ---
c = CMP['sionna']; g = CMP['gpp']; c5 = CMP5['sionna']
note = f'''<div class="note"><b>3GPP vs Sionna — what the toggle shows (ray-traced / simulated, 3.6 GHz, street 1.5 m, 10,000 cells at 10 m):</b>
<ul>
<li><b>Coverage (RSRP ≥ −90 dBm):</b> Sionna {c['coverage_ge_minus90_pct']}% of cells vs 3GPP UMa {g['coverage_ge_minus90_pct']}% — the ray-traced map covers less, because buildings shadow whole street blocks that the formula treats as open. (At 40 m in v5 it was Sionna {c5['coverage_ge_minus90_pct']}%, so the finer grid finds slightly more coverage.)</li>
<li><b>Median best-server RSRP:</b> Sionna {c['median_rsrp_dbm']} dBm vs 3GPP {g['median_rsrp_dbm']} dBm (median difference Sionna − 3GPP {CMP['diff_median_db']} dB; v5 at 40 m: {c5['median_rsrp_dbm']} dBm, difference {CMP5['diff_median_db']} dB).</li>
<li><b>Building shadow:</b> {CMP['shadow_gt15db_pct']}% of cells are &gt;15 dB weaker in Sionna than in 3GPP; {c['no_path_pct']}% of cells receive no ray at all from any tower (hatched; v5: {c5['no_path_pct']}%). LOS to at least one tower: {c['los_any_tx_pct']}% of cells (v5: {c5['los_any_tx_pct']}%).</li>
<li><b>Best server:</b> the two models pick the same serving tower on {CMP['best_server_agreement_pct']}% of cells — where they disagree is mostly at tower boundaries and in shadowed streets.</li>
<li><b>Handoff region (&lt;3 dB, sector level):</b> Sionna {c['ho_region_pct']}% of cells vs 3GPP {g['ho_region_pct']}% — the ray-traced handoff region is patchier: it follows street canyons instead of smooth circles, so a moving UE can cross several handoff boundaries where the 3GPP map shows one. (v5 at 40 m: Sionna {c5['ho_region_pct']}%.)</li>
<li><b>Why 10 m matters:</b> at 40 m, one grid cell averaged over whole street blocks — a UE could sit in a good 40 m cell while its actual street was shadowed. At 10 m, individual shadowed streets and sunlit corners resolve separately; e.g. UE5 now shows no ray at its exact spot where the 40 m map gave −83.8 dBm.</li>
</ul>
Assumptions, stated: Sionna sectors 90°/210°/330° in ENU (as in the SF single-tower run); 3GPP sectors 0°/120°/240° in artefact grid coordinates. Best-server comparison is per tower, not per sector. Sionna is a simulation on a 1 m-facet mesh with one material (ITU concrete) for the whole city — it is not a measurement, and it does not include vegetation, vehicles, or indoor loss.</div>'''
m = re.search(r'<div class="note"><b>3GPP vs Sionna — what the toggle shows.*?</div>',
              html, flags=re.S)
assert m, 'v5 comparison note not found'
html = html[:m.start()] + note + html[m.end():]

assert 'Version inside the file: v6.' in html
assert 'ri*25+ci' not in html
assert '25×25 grid at 40 m' not in html
open('6g-ran-multicell-handoff-v6.html', 'w').write(html)
print('wrote 6g-ran-multicell-handoff-v6.html', len(html), 'bytes; Sionna JSON', len(sionna_json), 'bytes')
