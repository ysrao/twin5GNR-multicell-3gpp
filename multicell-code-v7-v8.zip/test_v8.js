#!/usr/bin/env node
// Smoke-test v8 artefact JS: stub a minimal DOM, run draw() in each of the
// three 28 GHz small-cell modes, and print the UE table + status.
// Catches syntax/runtime errors. Modes are all data-driven (16 TX x 3 sectors).
const fs = require('fs');
const html = fs.readFileSync('6g-ran-multicell-handoff-v8.html', 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
if (scripts.length < 2) { console.error('expected >=2 script blocks, got', scripts.length); process.exit(1); }

function makeEl(id) {
  const el = { id, value: '28', textContent: '', innerHTML: '', style: {},
    disabled: false, checked: false,
    addEventListener: () => {}, getContext: () => ctxStub,
    querySelector: () => null, appendChild: () => {} };
  return el;
}
const ctxStub = new Proxy({}, { get: (t, k) => (k === 'canvas' ? {} : (() => {})),
  set: () => true });
const els = {};
['freq','morph','mimo','eirp','bw','houe','ax','ay','bx','by','cx','cy',
 'runBtn','animBtn','status','map','sionnaNote','vegNote'].forEach(id => els[id] = makeEl(id));
els.freq.value='28'; els.morph.value='UMa'; els.mimo.value='4'; els.eirp.value='40';
els.bw.value='100'; els.houe.value='all';
els.ax.value='125'; els.ay.value='875'; els.bx.value='375'; els.by.value='875';
els.cx.value='625'; els.cy.value='875'; els.map.width=600; els.map.height=600;
let modelVal = 'gpp28';
const tbody = { innerHTML: '', children: [], appendChild(c){ this.children.push(c); } };
const rows = [];
global.document = {
  getElementById: id => els[id] || makeEl(id),
  querySelector: sel => {
    if (sel === 'input[name="model"]:checked') return { value: modelVal };
    if (sel === '#uetable tbody') return tbody;
    return null;
  },
  querySelectorAll: sel => sel === 'input[name="model"]' ? [{addEventListener:()=>{}},{addEventListener:()=>{}},{addEventListener:()=>{}}] : [],
  createElement: tag => ({ tag, innerHTML: '', children: [], appendChild(){}, set innerHTML(v){ this._h=v; rows.push(v); }, get innerHTML(){ return this._h||''; } }),
};
global.requestAnimationFrame = () => {};
global.window = global;

function runMode(mode) {
  rows.length = 0;
  modelVal = mode;
  new Function(scripts.join('\n'))();
  console.log('---', mode, '---');
  console.log('status:', els.status.textContent);
  console.log('rows:', rows.length);
  const last = rows.slice(-6).map(r => [...r.matchAll(/<td>(.*?)<\/td>/g)].map(m => m[1]));
  last.forEach(tds => console.log(' ', tds[0], '| serving', tds[3], '| RSRP', tds[4], '| 2nd/diff', tds[5], '| HO', tds[6]));
  return last.map(t => t[4]);
}
const g = runMode('gpp28');
const s = runMode('sionna28');
const v = runMode('sionna28v');
console.log('GPP28 RSRPs:', g.join(', '));
console.log('Sionna28 RSRPs:', s.join(', '));
console.log('Sionna28+veg RSRPs:', v.join(', '));
if (JSON.stringify(g) === JSON.stringify(s)) { console.error('FAIL: GPP and Sionna UE RSRPs identical'); process.exit(1); }
console.log('SMOKE TEST OK');
