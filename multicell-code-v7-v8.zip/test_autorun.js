#!/usr/bin/env node
// Verification for the Run-button fix (auto-rerun + green/white pending state +
// sticky Run bar + greyed-out selectors in Sionna mode), v5-v8.
// Stub DOM records addEventListener handlers so a menu 'change' can be
// simulated; the real setTimeout in scheduleDraw is allowed to run.
const fs = require('fs');
const sleep = ms => new Promise(r => setTimeout(r, ms));

function load(file, modelVal, defaults) {
  const html = fs.readFileSync(file, 'utf8');
  const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
  if (scripts.length < 2) throw new Error(file + ': expected >=2 script blocks');
  const ctxStub = new Proxy({}, { get: (t, k) => (k === 'canvas' ? {} : (() => {})), set: () => true });
  const els = {};
  const rows = [];
  const modelHandlers = [];
  function makeEl(id) {
    return { id, value: defaults[id] || '', textContent: '', innerHTML: '', style: {},
      disabled: false, checked: false, _h: {},
      addEventListener(ev, fn) { (this._h[ev] = this._h[ev] || []).push(fn); },
      getContext: () => ctxStub, querySelector: () => null, appendChild: () => {} };
  }
  ['freq','morph','mimo','eirp','bw','houe','ax','ay','bx','by','cx','cy',
   'runBtn','animBtn','status','map','sionnaNote','vegNote','fixedNote','runBar'
  ].forEach(id => els[id] = makeEl(id));
  Object.assign(els.freq, { value: defaults.freq });
  Object.assign(els.morph, { value: defaults.morph });
  Object.assign(els.mimo, { value: defaults.mimo });
  Object.assign(els.eirp, { value: defaults.eirp });
  Object.assign(els.bw, { value: defaults.bw });
  Object.assign(els.houe, { value: defaults.houe });
  ['ax','ay','bx','by','cx','cy'].forEach(id => els[id].value = defaults[id]);
  const tbody = { innerHTML: '', children: [], appendChild(c) { this.children.push(c); } };
  let model = modelVal;
  const radios = [0,1,2].map(() => ({ addEventListener(ev, fn) { modelHandlers.push(fn); } }));
  const g = { document: {
    getElementById: id => els[id] || makeEl(id),
    querySelector: sel => {
      if (sel === 'input[name="model"]:checked') return { value: model };
      if (sel === '#uetable tbody') return tbody;
      return null;
    },
    querySelectorAll: sel => sel === 'input[name="model"]' ? radios : [],
    createElement: () => ({ tag: '', children: [], appendChild() {},
      set innerHTML(v) { this._h = v; rows.push(v); }, get innerHTML() { return this._h || ''; } }),
  }, requestAnimationFrame: () => {}, window: {} };
  g.window = g;
  const fn = new Function('document', 'window', 'requestAnimationFrame', scripts.join('\n'));
  fn(g.document, g, g.requestAnimationFrame);
  const ue1 = () => {
    const last = rows.slice(-6).map(r => [...r.matchAll(/<td>(.*?)<\/td>/g)].map(x => x[1]));
    return last.length ? last[0][4] : null;
  };
  return { els, rows, modelHandlers,
    setModel(m) { model = m; },
    fire(id, ev) { (els[id]._h[ev] || []).forEach(f => f()); },
    fireModel() { modelHandlers.forEach(f => f()); },
    ue1, status: () => els.status.textContent };
}

const sleepMs = 450;
async function check(cfg) {
  const { file, gpp, sionna, defaults, changeId, changeVal, expectUE1After } = cfg;
  console.log('---', file, '---');
  const t = load(file, gpp, defaults);
  const assert = (cond, msg) => { console.log((cond ? 'PASS' : 'FAIL') + ' ' + msg); if (!cond) process.exitCode = 1; };
  // static markup checks
  const html = fs.readFileSync(file, 'utf8');
  assert(html.includes('class="runbar"') && html.includes('position:sticky'), 'sticky Run bar present');
  assert(html.includes('id="fixedNote"'), 'fixedNote present');
  assert(html.includes("backgroundColor='#2e9e44'") && html.includes("backgroundColor='#fff'"), 'green/white pending-state code present');
  // initial state: up to date, white Run
  assert(t.els.runBtn.textContent === 'Run', 'initial Run label is Run (got ' + t.els.runBtn.textContent + ')');
  assert(t.els.runBtn.style.backgroundColor === '#fff', 'initial Run is white (got ' + t.els.runBtn.style.backgroundColor + ')');
  console.log('  initial status:', t.status(), '| UE1:', t.ue1());
  if (cfg.file.includes('v8')) {
    assert(t.els.freq.disabled === true, 'v8: freq disabled in 3GPP mode too');
  } else {
    assert(t.els.freq.disabled === false, 'freq enabled in 3GPP mode');
  }
  // change a menu item: green immediately, then white after auto-rerun
  const rowsBefore = t.rows.length;
  const ue1Before = t.ue1();
  t.els[changeId].value = changeVal;
  t.fire(changeId, 'change');
  assert(t.els.runBtn.style.backgroundColor === '#2e9e44', 'Run GREEN immediately after menu change (got ' + t.els.runBtn.style.backgroundColor + ')');
  assert(t.els.runBtn.textContent === 'Run — settings changed', 'Run label is "Run — settings changed" while pending');
  await sleep(sleepMs);
  assert(t.els.runBtn.style.backgroundColor === '#fff', 'Run back to WHITE after auto-rerun (got ' + t.els.runBtn.style.backgroundColor + ')');
  assert(t.els.runBtn.textContent === 'Run', 'Run label back to Run after auto-rerun');
  assert(t.rows.length === rowsBefore + 6, 'auto-rerun redrew UE table (+6 rows: ' + rowsBefore + ' -> ' + t.rows.length + ')');
  console.log('  after change status:', t.status(), '| UE1:', ue1Before, '->', t.ue1());
  if (expectUE1After) assert(t.ue1() === expectUE1After, 'UE1 RSRP updated to ' + expectUE1After + ' (got ' + t.ue1() + ')');
  // switch to Sionna: selectors greyed out, fixed note shown
  t.setModel(sionna);
  t.fireModel();
  await sleep(sleepMs);
  assert(t.els.freq.disabled === true && t.els.morph.disabled === true && t.els.mimo.disabled === true,
    'Sionna mode: freq/morph/mimo disabled (freq=' + t.els.freq.disabled + ' morph=' + t.els.morph.disabled + ' mimo=' + t.els.mimo.disabled + ')');
  assert(t.els.fixedNote.style.display === 'block', 'Sionna mode: fixedNote shown');
  console.log('  Sionna status:', t.status(), '| UE1:', t.ue1());
  // back to 3GPP: selectors re-enabled (freq stays disabled in v8)
  t.setModel(gpp);
  t.fireModel();
  await sleep(sleepMs);
  if (cfg.file.includes('v8')) {
    assert(t.els.freq.disabled === true && t.els.morph.disabled === false && t.els.mimo.disabled === false,
      'v8 back to 3GPP: freq still disabled, morph/mimo re-enabled');
  } else {
    assert(t.els.freq.disabled === false && t.els.morph.disabled === false && t.els.mimo.disabled === false,
      'back to 3GPP: freq/morph/mimo re-enabled');
    assert(t.els.fixedNote.style.display === 'none', 'back to 3GPP: fixedNote hidden');
  }
}

(async () => {
  const base = { freq: '3.5', morph: 'UMa', mimo: '4', eirp: '47', bw: '100', houe: 'all',
    ax: '250', ay: '250', bx: '750', by: '250', cx: '500', cy: '750' };
  await check({ file: '6g-ran-multicell-handoff-v5.html', gpp: '3gpp', sionna: 'sionna',
    defaults: base, changeId: 'freq', changeVal: '28', expectUE1After: '-50.0' });
  await check({ file: '6g-ran-multicell-handoff-v6.html', gpp: '3gpp', sionna: 'sionna',
    defaults: base, changeId: 'freq', changeVal: '28', expectUE1After: '-50.0' });
  await check({ file: '6g-ran-multicell-handoff-v7.html', gpp: '3gpp', sionna: 'sionna_veg',
    defaults: base, changeId: 'freq', changeVal: '28', expectUE1After: '-50.0' });
  await check({ file: '6g-ran-multicell-handoff-v8.html', gpp: 'gpp28', sionna: 'sionna28',
    defaults: { ...base, freq: '28', eirp: '40', ax: '125', ay: '875', bx: '375', by: '875', cx: '625', cy: '875' }, changeId: 'bw', changeVal: '200', expectUE1After: null });
  console.log(process.exitCode ? 'AUTORUN CHECKS FAILED' : 'AUTORUN CHECKS OK');
})();
